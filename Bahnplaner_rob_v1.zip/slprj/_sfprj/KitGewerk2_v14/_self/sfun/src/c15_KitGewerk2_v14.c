/* Include files */

#include <stddef.h>
#include "blas.h"
#include "KitGewerk2_v14_sfun.h"
#include "c15_KitGewerk2_v14.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "KitGewerk2_v14_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)
#define c15_IN_NO_ACTIVE_CHILD         ((uint8_T)0U)
#define c15_IN_A_stern_fahrt           ((uint8_T)1U)
#define c15_IN_Auftrag_empfangen       ((uint8_T)2U)
#define c15_IN_Auftrag_empfangen1      ((uint8_T)3U)
#define c15_IN_Eintrittspunkt_erreicht ((uint8_T)4U)
#define c15_IN_Fahrt_in_nav_2          ((uint8_T)5U)
#define c15_IN_Fahrt_zum_Warteplatz    ((uint8_T)6U)
#define c15_IN_Init                    ((uint8_T)7U)
#define c15_IN_Nav2_abfrage            ((uint8_T)8U)
#define c15_IN_Routinen_Ladestationen  ((uint8_T)9U)
#define c15_IN_Routinen_Stationen      ((uint8_T)10U)
#define c15_IN_Routinen_Warteplaetze   ((uint8_T)11U)
#define c15_IN_Station_aendern         ((uint8_T)12U)
#define c15_IN_Stationsentscheider     ((uint8_T)13U)
#define c15_IN_Warten_auf_Auftrag      ((uint8_T)14U)
#define c15_IN_Warten_auf_neuen_Auftrag ((uint8_T)15U)
#define c15_IN_Wegpunktliste_erstellen_state ((uint8_T)1U)
#define c15_IN_Werkstueck_ablegen      ((uint8_T)2U)
#define c15_IN_Werkstueck_aufnehmen    ((uint8_T)3U)
#define c15_IN_Fahrt_zu_Platz1         ((uint8_T)1U)
#define c15_IN_Greifer_schlie          ((uint8_T)2U)
#define c15_IN_RFID_lesen_2            ((uint8_T)3U)
#define c15_IN_Routine_fertig          ((uint8_T)4U)
#define c15_IN_WP_weiterschalten_3     ((uint8_T)5U)
#define c15_IN_Weiterfahren_zu_RFID    ((uint8_T)6U)
#define c15_IN_Auftrag_fertig          ((uint8_T)1U)
#define c15_IN_Fahrt_zu_Ablage         ((uint8_T)2U)
#define c15_IN_Fahrt_zu_RFID           ((uint8_T)3U)
#define c15_IN_Greifer_Oeffnen         ((uint8_T)4U)
#define c15_IN_RFID_lesen              ((uint8_T)5U)
#define c15_IN_WP_weiterschalten       ((uint8_T)6U)
#define c15_IN_WP_weiterschalten2      ((uint8_T)7U)
#define c15_IN_A_stern                 ((uint8_T)1U)
#define c15_IN_Kollisionserkennung     ((uint8_T)2U)
#define c15_IN_Fahrt_an_rand_nav1      ((uint8_T)1U)
#define c15_IN_Kontakt_fehler          ((uint8_T)2U)
#define c15_IN_Laden_beenden           ((uint8_T)3U)
#define c15_IN_Laden_beginnen          ((uint8_T)4U)
#define c15_IN_Warten_auf_Ereignis     ((uint8_T)5U)
#define c15_IN_Wegpunkte               ((uint8_T)6U)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static const char * c15_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_b_debug_family_names[15] = { "offset_Station",
  "links_rechts", "hinten_vorne", "Platz_1", "Platz_2", "Platz_3", "Platz_4",
  "RFID_L", "RFID_R", "Anz_WP", "nargin", "nargout", "Auftragsnummer",
  "Is_Endstation", "Wegpunktliste" };

static const char * c15_c_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_d_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_e_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_f_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_g_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_h_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_i_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_j_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_k_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_l_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_m_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_n_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_o_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_p_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_q_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_r_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_s_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_t_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_u_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_v_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_w_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_x_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_y_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ab_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_bb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_cb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_db_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_eb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_fb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_gb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_hb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ib_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_jb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_kb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_lb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_mb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_nb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ob_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_pb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_qb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_rb_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_sb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_tb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ub_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_vb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_wb_debug_family_names[2] = { "nargin", "nargout" };

static const char * c15_xb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_yb_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ac_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_bc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_cc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_dc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ec_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_fc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_gc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_hc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_ic_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_jc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_kc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_lc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_mc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_nc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_oc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_pc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_qc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_rc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_sc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_tc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_uc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_vc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_wc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_xc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c15_yc_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static boolean_T c15_dataWrittenToVector[14];

/* Function Declarations */
static void initialize_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void initialize_params_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance);
static void enable_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void disable_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_update_debugger_state_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance);
static void ext_mode_exec_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance);
static const mxArray *get_sim_state_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance);
static void set_sim_state_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance, const mxArray *c15_st);
static void c15_set_sim_state_side_effects_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance);
static void finalize_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void sf_gateway_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_chartstep_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance);
static void initSimStructsc15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance);
static void c15_Werkstueck_aufnehmen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_Werkstueck_ablegen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_Fahrt_in_nav_2(SFc15_KitGewerk2_v14InstanceStruct *chartInstance);
static void c15_Eintrittspunkt_erreicht(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_A_stern_fahrt(SFc15_KitGewerk2_v14InstanceStruct *chartInstance);
static void c15_Auftrag_empfangen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_Routinen_Ladestationen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void c15_Auftrag_empfangen1(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c15_machineNumber, uint32_T
  c15_chartNumber, uint32_T c15_instanceNumber);
static const mxArray *c15_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static real_T c15_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId);
static void c15_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static const mxArray *c15_b_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static void c15_b_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_Wegpunktliste, const char_T *c15_identifier,
  real_T c15_y[200]);
static void c15_c_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId,
  real_T c15_y[200]);
static void c15_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static const mxArray *c15_c_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static uint8_T c15_d_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_Is_Endstation, const char_T *c15_identifier);
static uint8_T c15_e_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId);
static void c15_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static const mxArray *c15_d_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static void c15_f_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId,
  real_T c15_y[12]);
static void c15_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static const mxArray *c15_e_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static boolean_T c15_g_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_sf_internal_predicateOutput, const char_T
  *c15_identifier);
static boolean_T c15_h_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId);
static void c15_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static void c15_info_helper(const mxArray **c15_info);
static const mxArray *c15_emlrt_marshallOut(const char * c15_u);
static const mxArray *c15_b_emlrt_marshallOut(const uint32_T c15_u);
static void c15_Wegpunktliste_erstellen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, uint8_T c15_Auftragsnummer, uint8_T c15_Is_Endstation, real_T
  c15_Wegpunktliste[200]);
static const mxArray *c15_f_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static int32_T c15_i_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId);
static void c15_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static const mxArray *c15_g_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData);
static void c15_j_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_A_stern_test, const char_T *c15_identifier,
  real_T c15_y[200]);
static void c15_k_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId,
  real_T c15_y[200]);
static void c15_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData);
static const mxArray *c15_l_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance, const mxArray *c15_b_setSimStateSideEffectsInfo, const char_T
  *c15_identifier);
static const mxArray *c15_m_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId);
static void c15_updateDataWrittenToVector(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, uint32_T c15_vectorIndex);
static void c15_errorIfDataNotWrittenToFcn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, uint32_T c15_vectorIndex, uint32_T c15_dataNumber);
static void init_dsm_address_info(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  int32_T *c15_sfEvent;
  uint8_T *c15_is_A_stern_fahrt;
  uint8_T *c15_is_Routinen_Ladestationen;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  uint8_T *c15_is_active_c15_KitGewerk2_v14;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_temporalCounter_i1;
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_is_Routinen_Ladestationen = (uint8_T *)ssGetDWork(chartInstance->S, 8);
  c15_is_A_stern_fahrt = (uint8_T *)ssGetDWork(chartInstance->S, 7);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_is_active_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 2);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  *c15_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c15_doSetSimStateSideEffects = 0U;
  chartInstance->c15_setSimStateSideEffectsInfo = NULL;
  *c15_is_A_stern_fahrt = c15_IN_NO_ACTIVE_CHILD;
  *c15_is_Routinen_Ladestationen = c15_IN_NO_ACTIVE_CHILD;
  *c15_is_Routinen_Stationen = c15_IN_NO_ACTIVE_CHILD;
  *c15_is_Werkstueck_ablegen = c15_IN_NO_ACTIVE_CHILD;
  *c15_temporalCounter_i1 = 0U;
  *c15_is_Werkstueck_aufnehmen = c15_IN_NO_ACTIVE_CHILD;
  *c15_temporalCounter_i1 = 0U;
  *c15_is_active_c15_KitGewerk2_v14 = 0U;
  *c15_is_c15_KitGewerk2_v14 = c15_IN_NO_ACTIVE_CHILD;
}

static void initialize_params_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint8_T *c15_is_c15_KitGewerk2_v14;
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  _sfTime_ = sf_get_time(chartInstance->S);
  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Fahrt_zum_Warteplatz) {
    sf_call_output_fcn_enable(chartInstance->S, 0, "simfcn", 0);
  }
}

static void disable_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint8_T *c15_is_c15_KitGewerk2_v14;
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  _sfTime_ = sf_get_time(chartInstance->S);
  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Fahrt_zum_Warteplatz) {
    sf_call_output_fcn_disable(chartInstance->S, 0, "simfcn", 0);
  }
}

static void c15_update_debugger_state_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance)
{
  uint32_T c15_prevAniVal;
  uint8_T *c15_is_active_c15_KitGewerk2_v14;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_A_stern_fahrt;
  uint8_T *c15_is_Routinen_Ladestationen;
  int32_T *c15_sfEvent;
  c15_is_Routinen_Ladestationen = (uint8_T *)ssGetDWork(chartInstance->S, 8);
  c15_is_A_stern_fahrt = (uint8_T *)ssGetDWork(chartInstance->S, 7);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_is_active_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 2);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  c15_prevAniVal = _SFD_GET_ANIMATION();
  _SFD_SET_ANIMATION(0U);
  _SFD_SET_HONOR_BREAKPOINTS(0U);
  if (*c15_is_active_c15_KitGewerk2_v14 == 1U) {
    _SFD_CC_CALL(CHART_ACTIVE_TAG, 14U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Routinen_Stationen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 18U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 18U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Stationen == c15_IN_Wegpunktliste_erstellen_state) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 19U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 19U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Stationen == c15_IN_Werkstueck_aufnehmen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 29U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 29U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_aufnehmen == c15_IN_Fahrt_zu_Platz1) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 30U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 30U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_aufnehmen == c15_IN_Greifer_schlie) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 31U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 31U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_aufnehmen == c15_IN_Weiterfahren_zu_RFID) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 35U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 35U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_aufnehmen == c15_IN_RFID_lesen_2) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 32U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 32U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_aufnehmen == c15_IN_WP_weiterschalten_3) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 34U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 34U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_aufnehmen == c15_IN_Routine_fertig) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 33U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 33U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Stationen == c15_IN_Werkstueck_ablegen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 21U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 21U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_Fahrt_zu_RFID) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 24U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 24U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_RFID_lesen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 26U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 26U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_WP_weiterschalten) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 27U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 27U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_Fahrt_zu_Ablage) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 23U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 23U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_Greifer_Oeffnen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 25U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 25U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_WP_weiterschalten2) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 28U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 28U, *c15_sfEvent);
  }

  if (*c15_is_Werkstueck_ablegen == c15_IN_Auftrag_fertig) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 22U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 22U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Station_aendern) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 38U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 38U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Fahrt_in_nav_2) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 6U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 6U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Nav2_abfrage) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 10U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 10U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Eintrittspunkt_erreicht) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_A_stern_fahrt) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, *c15_sfEvent);
  }

  if (*c15_is_A_stern_fahrt == c15_IN_A_stern) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, *c15_sfEvent);
  }

  if (*c15_is_A_stern_fahrt == c15_IN_Kollisionserkennung) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 2U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Stationsentscheider) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 39U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 39U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Fahrt_zum_Warteplatz) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 7U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 7U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Auftrag_empfangen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Init) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 9U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 9U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Warten_auf_Auftrag) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 40U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 40U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Warten_auf_neuen_Auftrag) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 41U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 41U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Routinen_Warteplaetze) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 36U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 36U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Routinen_Ladestationen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 11U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 11U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Ladestationen == c15_IN_Warten_auf_Ereignis) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 16U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 16U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Ladestationen == c15_IN_Laden_beenden) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 14U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 14U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Ladestationen == c15_IN_Laden_beginnen) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 15U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 15U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Ladestationen == c15_IN_Fahrt_an_rand_nav1) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 12U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 12U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Ladestationen == c15_IN_Wegpunkte) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 17U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 17U, *c15_sfEvent);
  }

  if (*c15_is_Routinen_Ladestationen == c15_IN_Kontakt_fehler) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 13U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 13U, *c15_sfEvent);
  }

  if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Auftrag_empfangen1) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, *c15_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, *c15_sfEvent);
  }

  _SFD_SET_ANIMATION(c15_prevAniVal);
  _SFD_SET_HONOR_BREAKPOINTS(1U);
  _SFD_ANIMATE();
}

static void ext_mode_exec_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance)
{
  c15_update_debugger_state_c15_KitGewerk2_v14(chartInstance);
}

static const mxArray *get_sim_state_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance)
{
  const mxArray *c15_st;
  const mxArray *c15_y = NULL;
  int32_T c15_i0;
  real_T c15_u[200];
  const mxArray *c15_b_y = NULL;
  int32_T c15_i1;
  real_T c15_b_u[200];
  const mxArray *c15_c_y = NULL;
  boolean_T c15_hoistedGlobal;
  boolean_T c15_c_u;
  const mxArray *c15_d_y = NULL;
  boolean_T c15_b_hoistedGlobal;
  boolean_T c15_d_u;
  const mxArray *c15_e_y = NULL;
  boolean_T c15_c_hoistedGlobal;
  boolean_T c15_e_u;
  const mxArray *c15_f_y = NULL;
  boolean_T c15_d_hoistedGlobal;
  boolean_T c15_f_u;
  const mxArray *c15_g_y = NULL;
  uint8_T c15_e_hoistedGlobal;
  uint8_T c15_g_u;
  const mxArray *c15_h_y = NULL;
  boolean_T c15_f_hoistedGlobal;
  boolean_T c15_h_u;
  const mxArray *c15_i_y = NULL;
  uint8_T c15_g_hoistedGlobal;
  uint8_T c15_i_u;
  const mxArray *c15_j_y = NULL;
  uint8_T c15_h_hoistedGlobal;
  uint8_T c15_j_u;
  const mxArray *c15_k_y = NULL;
  uint8_T c15_i_hoistedGlobal;
  uint8_T c15_k_u;
  const mxArray *c15_l_y = NULL;
  uint8_T c15_j_hoistedGlobal;
  uint8_T c15_l_u;
  const mxArray *c15_m_y = NULL;
  uint8_T c15_k_hoistedGlobal;
  uint8_T c15_m_u;
  const mxArray *c15_n_y = NULL;
  uint8_T c15_l_hoistedGlobal;
  uint8_T c15_n_u;
  const mxArray *c15_o_y = NULL;
  uint8_T c15_m_hoistedGlobal;
  uint8_T c15_o_u;
  const mxArray *c15_p_y = NULL;
  uint8_T c15_n_hoistedGlobal;
  uint8_T c15_p_u;
  const mxArray *c15_q_y = NULL;
  uint8_T c15_o_hoistedGlobal;
  uint8_T c15_q_u;
  const mxArray *c15_r_y = NULL;
  uint8_T c15_p_hoistedGlobal;
  uint8_T c15_r_u;
  const mxArray *c15_s_y = NULL;
  uint8_T c15_q_hoistedGlobal;
  uint8_T c15_s_u;
  const mxArray *c15_t_y = NULL;
  boolean_T *c15_B_Greifer;
  boolean_T *c15_B_Stop;
  boolean_T *c15_B_WPL_cnt_reset;
  boolean_T *c15_B_WP_weiter;
  uint8_T *c15_UI_to_GW1;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  uint8_T *c15_UI_Endstation;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_is_active_c15_KitGewerk2_v14;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_is_Routinen_Ladestationen;
  uint8_T *c15_is_A_stern_fahrt;
  uint8_T *c15_temporalCounter_i1;
  real_T (*c15_A_stern_test)[200];
  real_T (*c15_A_WPL)[200];
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_A_stern_test = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 7);
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_B_WPL_cnt_reset = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c15_B_Greifer = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c15_B_WP_weiter = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c15_B_Stop = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c15_A_WPL = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 1);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_Routinen_Ladestationen = (uint8_T *)ssGetDWork(chartInstance->S, 8);
  c15_is_A_stern_fahrt = (uint8_T *)ssGetDWork(chartInstance->S, 7);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_is_active_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 2);
  c15_st = NULL;
  c15_st = NULL;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_createcellmatrix(19, 1), false);
  for (c15_i0 = 0; c15_i0 < 200; c15_i0++) {
    c15_u[c15_i0] = (*c15_A_WPL)[c15_i0];
  }

  c15_b_y = NULL;
  sf_mex_assign(&c15_b_y, sf_mex_create("y", c15_u, 0, 0U, 1U, 0U, 2, 50, 4),
                false);
  sf_mex_setcell(c15_y, 0, c15_b_y);
  for (c15_i1 = 0; c15_i1 < 200; c15_i1++) {
    c15_b_u[c15_i1] = (*c15_A_stern_test)[c15_i1];
  }

  c15_c_y = NULL;
  sf_mex_assign(&c15_c_y, sf_mex_create("y", c15_b_u, 0, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_setcell(c15_y, 1, c15_c_y);
  c15_hoistedGlobal = *c15_B_Greifer;
  c15_c_u = c15_hoistedGlobal;
  c15_d_y = NULL;
  sf_mex_assign(&c15_d_y, sf_mex_create("y", &c15_c_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 2, c15_d_y);
  c15_b_hoistedGlobal = *c15_B_Stop;
  c15_d_u = c15_b_hoistedGlobal;
  c15_e_y = NULL;
  sf_mex_assign(&c15_e_y, sf_mex_create("y", &c15_d_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 3, c15_e_y);
  c15_c_hoistedGlobal = *c15_B_WPL_cnt_reset;
  c15_e_u = c15_c_hoistedGlobal;
  c15_f_y = NULL;
  sf_mex_assign(&c15_f_y, sf_mex_create("y", &c15_e_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 4, c15_f_y);
  c15_d_hoistedGlobal = *c15_B_WP_weiter;
  c15_f_u = c15_d_hoistedGlobal;
  c15_g_y = NULL;
  sf_mex_assign(&c15_g_y, sf_mex_create("y", &c15_f_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 5, c15_g_y);
  c15_e_hoistedGlobal = *c15_UI_to_GW1;
  c15_g_u = c15_e_hoistedGlobal;
  c15_h_y = NULL;
  sf_mex_assign(&c15_h_y, sf_mex_create("y", &c15_g_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 6, c15_h_y);
  c15_f_hoistedGlobal = *c15_B_Endst;
  c15_h_u = c15_f_hoistedGlobal;
  c15_i_y = NULL;
  sf_mex_assign(&c15_i_y, sf_mex_create("y", &c15_h_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 7, c15_i_y);
  c15_g_hoistedGlobal = *c15_UI_Auftrnr;
  c15_i_u = c15_g_hoistedGlobal;
  c15_j_y = NULL;
  sf_mex_assign(&c15_j_y, sf_mex_create("y", &c15_i_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 8, c15_j_y);
  c15_h_hoistedGlobal = *c15_UI_Endstation;
  c15_j_u = c15_h_hoistedGlobal;
  c15_k_y = NULL;
  sf_mex_assign(&c15_k_y, sf_mex_create("y", &c15_j_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 9, c15_k_y);
  c15_i_hoistedGlobal = *c15_UI_Startstation;
  c15_k_u = c15_i_hoistedGlobal;
  c15_l_y = NULL;
  sf_mex_assign(&c15_l_y, sf_mex_create("y", &c15_k_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 10, c15_l_y);
  c15_j_hoistedGlobal = *c15_is_active_c15_KitGewerk2_v14;
  c15_l_u = c15_j_hoistedGlobal;
  c15_m_y = NULL;
  sf_mex_assign(&c15_m_y, sf_mex_create("y", &c15_l_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 11, c15_m_y);
  c15_k_hoistedGlobal = *c15_is_c15_KitGewerk2_v14;
  c15_m_u = c15_k_hoistedGlobal;
  c15_n_y = NULL;
  sf_mex_assign(&c15_n_y, sf_mex_create("y", &c15_m_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 12, c15_n_y);
  c15_l_hoistedGlobal = *c15_is_Werkstueck_ablegen;
  c15_n_u = c15_l_hoistedGlobal;
  c15_o_y = NULL;
  sf_mex_assign(&c15_o_y, sf_mex_create("y", &c15_n_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 13, c15_o_y);
  c15_m_hoistedGlobal = *c15_is_Werkstueck_aufnehmen;
  c15_o_u = c15_m_hoistedGlobal;
  c15_p_y = NULL;
  sf_mex_assign(&c15_p_y, sf_mex_create("y", &c15_o_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 14, c15_p_y);
  c15_n_hoistedGlobal = *c15_is_Routinen_Stationen;
  c15_p_u = c15_n_hoistedGlobal;
  c15_q_y = NULL;
  sf_mex_assign(&c15_q_y, sf_mex_create("y", &c15_p_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 15, c15_q_y);
  c15_o_hoistedGlobal = *c15_is_Routinen_Ladestationen;
  c15_q_u = c15_o_hoistedGlobal;
  c15_r_y = NULL;
  sf_mex_assign(&c15_r_y, sf_mex_create("y", &c15_q_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 16, c15_r_y);
  c15_p_hoistedGlobal = *c15_is_A_stern_fahrt;
  c15_r_u = c15_p_hoistedGlobal;
  c15_s_y = NULL;
  sf_mex_assign(&c15_s_y, sf_mex_create("y", &c15_r_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 17, c15_s_y);
  c15_q_hoistedGlobal = *c15_temporalCounter_i1;
  c15_s_u = c15_q_hoistedGlobal;
  c15_t_y = NULL;
  sf_mex_assign(&c15_t_y, sf_mex_create("y", &c15_s_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c15_y, 18, c15_t_y);
  sf_mex_assign(&c15_st, c15_y, false);
  return c15_st;
}

static void set_sim_state_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance, const mxArray *c15_st)
{
  const mxArray *c15_u;
  real_T c15_dv0[200];
  int32_T c15_i2;
  real_T c15_dv1[200];
  int32_T c15_i3;
  boolean_T *c15_B_Greifer;
  boolean_T *c15_B_Stop;
  boolean_T *c15_B_WPL_cnt_reset;
  boolean_T *c15_B_WP_weiter;
  uint8_T *c15_UI_to_GW1;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  uint8_T *c15_UI_Endstation;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_is_active_c15_KitGewerk2_v14;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_is_Routinen_Ladestationen;
  uint8_T *c15_is_A_stern_fahrt;
  uint8_T *c15_temporalCounter_i1;
  real_T (*c15_A_WPL)[200];
  real_T (*c15_A_stern_test)[200];
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_A_stern_test = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 7);
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_B_WPL_cnt_reset = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c15_B_Greifer = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c15_B_WP_weiter = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c15_B_Stop = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c15_A_WPL = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 1);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_Routinen_Ladestationen = (uint8_T *)ssGetDWork(chartInstance->S, 8);
  c15_is_A_stern_fahrt = (uint8_T *)ssGetDWork(chartInstance->S, 7);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_is_active_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 2);
  c15_u = sf_mex_dup(c15_st);
  c15_b_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c15_u, 0)),
    "A_WPL", c15_dv0);
  for (c15_i2 = 0; c15_i2 < 200; c15_i2++) {
    (*c15_A_WPL)[c15_i2] = c15_dv0[c15_i2];
  }

  c15_j_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c15_u, 1)),
    "A_stern_test", c15_dv1);
  for (c15_i3 = 0; c15_i3 < 200; c15_i3++) {
    (*c15_A_stern_test)[c15_i3] = c15_dv1[c15_i3];
  }

  *c15_B_Greifer = c15_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 2)), "B_Greifer");
  *c15_B_Stop = c15_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c15_u, 3)), "B_Stop");
  *c15_B_WPL_cnt_reset = c15_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 4)), "B_WPL_cnt_reset");
  *c15_B_WP_weiter = c15_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 5)), "B_WP_weiter");
  *c15_UI_to_GW1 = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 6)), "UI_to_GW1");
  *c15_B_Endst = c15_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c15_u, 7)), "B_Endst");
  *c15_UI_Auftrnr = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 8)), "UI_Auftrnr");
  *c15_UI_Endstation = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 9)), "UI_Endstation");
  *c15_UI_Startstation = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 10)), "UI_Startstation");
  *c15_is_active_c15_KitGewerk2_v14 = c15_d_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c15_u, 11)), "is_active_c15_KitGewerk2_v14");
  *c15_is_c15_KitGewerk2_v14 = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 12)), "is_c15_KitGewerk2_v14");
  *c15_is_Werkstueck_ablegen = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 13)), "is_Werkstueck_ablegen");
  *c15_is_Werkstueck_aufnehmen = c15_d_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c15_u, 14)), "is_Werkstueck_aufnehmen");
  *c15_is_Routinen_Stationen = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 15)), "is_Routinen_Stationen");
  *c15_is_Routinen_Ladestationen = c15_d_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c15_u, 16)), "is_Routinen_Ladestationen");
  *c15_is_A_stern_fahrt = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 17)), "is_A_stern_fahrt");
  *c15_temporalCounter_i1 = c15_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c15_u, 18)), "temporalCounter_i1");
  sf_mex_assign(&chartInstance->c15_setSimStateSideEffectsInfo,
                c15_l_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c15_u, 19)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c15_u);
  chartInstance->c15_doSetSimStateSideEffects = 1U;
  c15_update_debugger_state_c15_KitGewerk2_v14(chartInstance);
  sf_mex_destroy(&c15_st);
}

static void c15_set_sim_state_side_effects_c15_KitGewerk2_v14
  (SFc15_KitGewerk2_v14InstanceStruct *chartInstance)
{
  uint8_T *c15_temporalCounter_i1;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  if (chartInstance->c15_doSetSimStateSideEffects != 0) {
    if (*c15_is_c15_KitGewerk2_v14 == c15_IN_Fahrt_zum_Warteplatz) {
      if (sf_mex_sub(chartInstance->c15_setSimStateSideEffectsInfo,
                     "setSimStateSideEffectsInfo", 1, 9) == 0.0) {
        sf_call_output_fcn_enable(chartInstance->S, 0, "simfcn", 0);
      }
    } else {
      if (sf_mex_sub(chartInstance->c15_setSimStateSideEffectsInfo,
                     "setSimStateSideEffectsInfo", 1, 9) > 0.0) {
        sf_call_output_fcn_disable(chartInstance->S, 0, "simfcn", 0);
      }
    }

    if (*c15_is_Werkstueck_ablegen == c15_IN_Greifer_Oeffnen) {
      if (sf_mex_sub(chartInstance->c15_setSimStateSideEffectsInfo,
                     "setSimStateSideEffectsInfo", 1, 25) == 0.0) {
        *c15_temporalCounter_i1 = 0U;
      }
    }

    if (*c15_is_Werkstueck_aufnehmen == c15_IN_Greifer_schlie) {
      if (sf_mex_sub(chartInstance->c15_setSimStateSideEffectsInfo,
                     "setSimStateSideEffectsInfo", 1, 31) == 0.0) {
        *c15_temporalCounter_i1 = 0U;
      }
    }

    chartInstance->c15_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  sf_mex_destroy(&chartInstance->c15_setSimStateSideEffectsInfo);
}

static void sf_gateway_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  int32_T c15_i4;
  int32_T c15_i5;
  int32_T *c15_sfEvent;
  uint8_T *c15_temporalCounter_i1;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  boolean_T *c15_B_Schieber;
  uint8_T *c15_UI_from_GW1;
  boolean_T *c15_B_Stop;
  boolean_T *c15_B_WP_weiter;
  boolean_T *c15_B_Greifer;
  boolean_T *c15_B_Lichtschranke;
  boolean_T *c15_B_WPL_cnt_reset;
  uint8_T *c15_UI_to_GW1;
  boolean_T *c15_B_last_WP;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_UI_Endstation;
  boolean_T *c15_B_da;
  uint8_T *c15_UI_Robi_ID;
  uint8_T *c15_WP_cnt;
  uint8_T *c15_UI_Endstation_in;
  uint8_T *c15_UI_Startstation_in;
  real_T (*c15_A_stern_test)[200];
  real_T (*c15_A_WPL)[200];
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_A_stern_test = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 7);
  c15_UI_Startstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c15_UI_Endstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c15_WP_cnt = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c15_UI_Robi_ID = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c15_B_da = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_B_last_WP = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_B_WPL_cnt_reset = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c15_B_Lichtschranke = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c15_B_Greifer = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c15_B_WP_weiter = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c15_B_Stop = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c15_UI_from_GW1 = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c15_B_Schieber = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 0);
  c15_A_WPL = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 1);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  c15_set_sim_state_side_effects_c15_KitGewerk2_v14(chartInstance);
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  if (*c15_temporalCounter_i1 < 127U) {
    (*c15_temporalCounter_i1)++;
  }

  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 14U, *c15_sfEvent);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Endst, 0U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
  for (c15_i4 = 0; c15_i4 < 200; c15_i4++) {
    _SFD_DATA_RANGE_CHECK((*c15_A_WPL)[c15_i4], 2U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Schieber, 3U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_from_GW1, 4U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Greifer, 7U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Lichtschranke, 8U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WPL_cnt_reset, 9U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_last_WP, 11U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Startstation, 12U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Endstation, 13U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_B_da, 14U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Robi_ID, 15U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_WP_cnt, 16U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Endstation_in, 17U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Startstation_in, 18U);
  for (c15_i5 = 0; c15_i5 < 200; c15_i5++) {
    _SFD_DATA_RANGE_CHECK((*c15_A_stern_test)[c15_i5], 19U);
  }

  *c15_sfEvent = CALL_EVENT;
  c15_chartstep_c15_KitGewerk2_v14(chartInstance);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_KitGewerk2_v14MachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c15_chartstep_c15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance)
{
  uint32_T c15_debug_family_var_map[2];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 0.0;
  boolean_T c15_hoistedGlobal;
  boolean_T c15_u;
  const mxArray *c15_y = NULL;
  uint32_T c15_b_debug_family_var_map[3];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 1.0;
  boolean_T c15_out;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 0.0;
  real_T c15_Out1[200];
  int32_T c15_i6;
  int32_T c15_i7;
  int32_T c15_i8;
  int32_T c15_i9;
  int32_T c15_i10;
  real_T c15_b_u[200];
  const mxArray *c15_b_y = NULL;
  real_T c15_d_nargin = 0.0;
  real_T c15_d_nargout = 1.0;
  boolean_T c15_b_out;
  real_T c15_e_nargin = 0.0;
  real_T c15_e_nargout = 0.0;
  boolean_T c15_b_hoistedGlobal;
  boolean_T c15_c_u;
  const mxArray *c15_c_y = NULL;
  real_T c15_f_nargin = 0.0;
  real_T c15_f_nargout = 1.0;
  boolean_T c15_c_out;
  real_T c15_g_nargin = 0.0;
  real_T c15_g_nargout = 0.0;
  boolean_T c15_c_hoistedGlobal;
  boolean_T c15_d_u;
  const mxArray *c15_d_y = NULL;
  real_T c15_h_nargin = 0.0;
  real_T c15_h_nargout = 0.0;
  real_T c15_dv2[200];
  int32_T c15_i11;
  int32_T c15_i12;
  int32_T c15_i13;
  real_T c15_e_u[200];
  const mxArray *c15_e_y = NULL;
  boolean_T c15_d_hoistedGlobal;
  boolean_T c15_f_u;
  const mxArray *c15_f_y = NULL;
  real_T c15_i_nargin = 0.0;
  real_T c15_i_nargout = 1.0;
  boolean_T c15_d_out;
  real_T c15_j_nargin = 0.0;
  real_T c15_j_nargout = 0.0;
  uint8_T c15_e_hoistedGlobal;
  uint8_T c15_g_u;
  const mxArray *c15_g_y = NULL;
  real_T c15_k_nargin = 0.0;
  real_T c15_k_nargout = 1.0;
  boolean_T c15_e_out;
  real_T c15_l_nargin = 0.0;
  real_T c15_l_nargout = 0.0;
  uint8_T c15_f_hoistedGlobal;
  uint8_T c15_h_u;
  const mxArray *c15_h_y = NULL;
  uint8_T *c15_is_active_c15_KitGewerk2_v14;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  boolean_T *c15_B_last_WP;
  boolean_T *c15_B_da;
  uint8_T *c15_is_A_stern_fahrt;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  boolean_T *c15_B_Endst;
  boolean_T *c15_B_WPL_cnt_reset;
  uint8_T *c15_UI_Auftrnr;
  uint8_T *c15_UI_Startstation_in;
  uint8_T *c15_UI_Endstation_in;
  uint8_T *c15_UI_to_GW1;
  real_T (*c15_A_stern_test)[200];
  real_T (*c15_A_WPL)[200];
  real_T (*c15_b_Out1)[200];
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  c15_b_Out1 = (real_T (*)[200])ssGetInputPortSignal(chartInstance->S, 9);
  c15_A_stern_test = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 7);
  c15_UI_Startstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c15_UI_Endstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c15_B_da = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c15_B_last_WP = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_B_WPL_cnt_reset = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c15_A_WPL = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 1);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_A_stern_fahrt = (uint8_T *)ssGetDWork(chartInstance->S, 7);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_is_active_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 2);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 14U, *c15_sfEvent);
  if (*c15_is_active_c15_KitGewerk2_v14 == 0U) {
    _SFD_CC_CALL(CHART_ENTER_ENTRY_FUNCTION_TAG, 14U, *c15_sfEvent);
    *c15_is_active_c15_KitGewerk2_v14 = 1U;
    _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 14U, *c15_sfEvent);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 20U, *c15_sfEvent);
    *c15_is_c15_KitGewerk2_v14 = c15_IN_Init;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 9U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_w_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_B_Endst = false;
    c15_updateDataWrittenToVector(chartInstance, 0U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Endst, 0U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
    sf_mex_printf("%s =\\n", "B_Endst");
    c15_hoistedGlobal = *c15_B_Endst;
    c15_u = c15_hoistedGlobal;
    c15_y = NULL;
    sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 11, 0U, 0U, 0U, 0), false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
    _SFD_SYMBOL_SCOPE_POP();
  } else {
    switch (*c15_is_c15_KitGewerk2_v14) {
     case c15_IN_A_stern_fahrt:
      CV_CHART_EVAL(14, 0, 1);
      c15_A_stern_fahrt(chartInstance);
      break;

     case c15_IN_Auftrag_empfangen:
      CV_CHART_EVAL(14, 0, 2);
      c15_Auftrag_empfangen(chartInstance);
      break;

     case c15_IN_Auftrag_empfangen1:
      CV_CHART_EVAL(14, 0, 3);
      c15_Auftrag_empfangen1(chartInstance);
      break;

     case c15_IN_Eintrittspunkt_erreicht:
      CV_CHART_EVAL(14, 0, 4);
      c15_Eintrittspunkt_erreicht(chartInstance);
      break;

     case c15_IN_Fahrt_in_nav_2:
      CV_CHART_EVAL(14, 0, 5);
      c15_Fahrt_in_nav_2(chartInstance);
      break;

     case c15_IN_Fahrt_zum_Warteplatz:
      CV_CHART_EVAL(14, 0, 6);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 33U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_tb_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
        c15_e_sf_marshallIn);
      guard4 = false;
      if (CV_EML_COND(33, 0, 0, *c15_B_last_WP)) {
        if (CV_EML_COND(33, 0, 1, *c15_B_da)) {
          CV_EML_MCDC(33, 0, 0, true);
          CV_EML_IF(33, 0, 0, true);
          c15_out = true;
        } else {
          guard4 = true;
        }
      } else {
        guard4 = true;
      }

      if (guard4 == true) {
        CV_EML_MCDC(33, 0, 0, false);
        CV_EML_IF(33, 0, 0, false);
        c15_out = false;
      }

      _SFD_SYMBOL_SCOPE_POP();
      if (c15_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 33U, *c15_sfEvent);
        _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 7U, *c15_sfEvent);
        sf_call_output_fcn_disable(chartInstance->S, 0, "simfcn", 0);
        _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 7U, *c15_sfEvent);
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 7U, *c15_sfEvent);
        *c15_is_c15_KitGewerk2_v14 = c15_IN_Warten_auf_Auftrag;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 40U, *c15_sfEvent);
      } else {
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 7U, *c15_sfEvent);
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 7U, *c15_sfEvent);
      break;

     case c15_IN_Init:
      CV_CHART_EVAL(14, 0, 7);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 24U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 9U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Fahrt_zum_Warteplatz;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 7U, *c15_sfEvent);
      sf_call_output_fcn_enable(chartInstance->S, 0, "simfcn", 0);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_u_debug_family_names,
        c15_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      _SFD_SET_DATA_VALUE_PTR(23U, c15_Out1);
      _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 8U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH(1U, 0U);
      _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("Out1", c15_Out1, c15_g_sf_marshallOut,
        c15_g_sf_marshallIn);
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 8U, *c15_sfEvent);
      sf_call_output_fcn_call(chartInstance->S, 0, "simfcn", 0);
      for (c15_i6 = 0; c15_i6 < 200; c15_i6++) {
        c15_Out1[c15_i6] = (*c15_b_Out1)[c15_i6];
      }

      c15_updateDataWrittenToVector(chartInstance, 12U);
      for (c15_i7 = 0; c15_i7 < 200; c15_i7++) {
        _SFD_DATA_RANGE_CHECK(c15_Out1[c15_i7], 23U);
      }

      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 8U, *c15_sfEvent);
      _SFD_UNSET_DATA_VALUE_PTR(23U);
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 8U, *c15_sfEvent);
      for (c15_i8 = 0; c15_i8 < 200; c15_i8++) {
        (*c15_A_stern_test)[c15_i8] = c15_Out1[c15_i8];
      }

      c15_updateDataWrittenToVector(chartInstance, 10U);
      for (c15_i9 = 0; c15_i9 < 200; c15_i9++) {
        _SFD_DATA_RANGE_CHECK((*c15_A_stern_test)[c15_i9], 19U);
      }

      c15_errorIfDataNotWrittenToFcn(chartInstance, 10U, 19U);
      sf_mex_printf("%s =\\n", "A_stern_test");
      for (c15_i10 = 0; c15_i10 < 200; c15_i10++) {
        c15_b_u[c15_i10] = (*c15_A_stern_test)[c15_i10];
      }

      c15_b_y = NULL;
      sf_mex_assign(&c15_b_y, sf_mex_create("y", c15_b_u, 0, 0U, 1U, 0U, 1, 200),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 9U, *c15_sfEvent);
      break;

     case c15_IN_Nav2_abfrage:
      CV_CHART_EVAL(14, 0, 8);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 23U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 10U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_A_stern_fahrt;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, *c15_sfEvent);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 36U, *c15_sfEvent);
      *c15_is_A_stern_fahrt = c15_IN_A_stern;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, *c15_sfEvent);
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 10U, *c15_sfEvent);
      break;

     case c15_IN_Routinen_Ladestationen:
      CV_CHART_EVAL(14, 0, 9);
      c15_Routinen_Ladestationen(chartInstance);
      break;

     case c15_IN_Routinen_Stationen:
      CV_CHART_EVAL(14, 0, 10);
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 18U, *c15_sfEvent);
      guard3 = false;
      switch (*c15_is_Routinen_Stationen) {
       case c15_IN_Wegpunktliste_erstellen_state:
        CV_STATE_EVAL(18, 0, 1);
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 11U, *c15_sfEvent);
        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_ib_debug_family_names,
          c15_b_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargin, 0U,
          c15_sf_marshallOut, c15_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargout, 1U,
          c15_sf_marshallOut, c15_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_out, 2U,
          c15_e_sf_marshallOut, c15_e_sf_marshallIn);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
        c15_b_out = CV_EML_IF(11, 0, 0, *c15_B_Endst);
        _SFD_SYMBOL_SCOPE_POP();
        if (c15_b_out) {
          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 11U, *c15_sfEvent);
          _SFD_CS_CALL(STATE_INACTIVE_TAG, 19U, *c15_sfEvent);
          *c15_is_Routinen_Stationen = c15_IN_Werkstueck_ablegen;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 21U, *c15_sfEvent);
          *c15_is_Werkstueck_ablegen = c15_IN_Fahrt_zu_RFID;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 24U, *c15_sfEvent);
          _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_j_debug_family_names,
            c15_debug_family_var_map);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_nargin, 0U,
            c15_sf_marshallOut, c15_sf_marshallIn);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_nargout, 1U,
            c15_sf_marshallOut, c15_sf_marshallIn);
          *c15_B_WPL_cnt_reset = false;
          c15_updateDataWrittenToVector(chartInstance, 6U);
          _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WPL_cnt_reset, 9U);
          c15_errorIfDataNotWrittenToFcn(chartInstance, 6U, 9U);
          sf_mex_printf("%s =\\n", "B_WPL_cnt_reset");
          c15_b_hoistedGlobal = *c15_B_WPL_cnt_reset;
          c15_c_u = c15_b_hoistedGlobal;
          c15_c_y = NULL;
          sf_mex_assign(&c15_c_y, sf_mex_create("y", &c15_c_u, 11, 0U, 0U, 0U, 0),
                        false);
          sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14,
                            c15_c_y);
          _SFD_SYMBOL_SCOPE_POP();
        } else {
          _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 13U, *c15_sfEvent);
          _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_jb_debug_family_names,
            c15_b_debug_family_var_map);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_f_nargin, 0U,
            c15_sf_marshallOut, c15_sf_marshallIn);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_f_nargout, 1U,
            c15_sf_marshallOut, c15_sf_marshallIn);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_out, 2U,
            c15_e_sf_marshallOut, c15_e_sf_marshallIn);
          c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
          c15_c_out = CV_EML_IF(13, 0, 0, !*c15_B_Endst);
          _SFD_SYMBOL_SCOPE_POP();
          if (c15_c_out) {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 13U, *c15_sfEvent);
            _SFD_CS_CALL(STATE_INACTIVE_TAG, 19U, *c15_sfEvent);
            *c15_is_Routinen_Stationen = c15_IN_Werkstueck_aufnehmen;
            _SFD_CS_CALL(STATE_ACTIVE_TAG, 29U, *c15_sfEvent);
            *c15_is_Werkstueck_aufnehmen = c15_IN_Fahrt_zu_Platz1;
            _SFD_CS_CALL(STATE_ACTIVE_TAG, 30U, *c15_sfEvent);
            _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_c_debug_family_names,
              c15_debug_family_var_map);
            _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_g_nargin, 0U,
              c15_sf_marshallOut, c15_sf_marshallIn);
            _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_g_nargout, 1U,
              c15_sf_marshallOut, c15_sf_marshallIn);
            *c15_B_WPL_cnt_reset = false;
            c15_updateDataWrittenToVector(chartInstance, 6U);
            _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WPL_cnt_reset, 9U);
            c15_errorIfDataNotWrittenToFcn(chartInstance, 6U, 9U);
            sf_mex_printf("%s =\\n", "B_WPL_cnt_reset");
            c15_c_hoistedGlobal = *c15_B_WPL_cnt_reset;
            c15_d_u = c15_c_hoistedGlobal;
            c15_d_y = NULL;
            sf_mex_assign(&c15_d_y, sf_mex_create("y", &c15_d_u, 11, 0U, 0U, 0U,
              0), false);
            sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14,
                              c15_d_y);
            _SFD_SYMBOL_SCOPE_POP();
          } else {
            _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 19U, *c15_sfEvent);
          }
        }

        _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 19U, *c15_sfEvent);
        guard3 = true;
        break;

       case c15_IN_Werkstueck_ablegen:
        CV_STATE_EVAL(18, 0, 2);
        c15_Werkstueck_ablegen(chartInstance);
        if (*c15_is_c15_KitGewerk2_v14 != c15_IN_Routinen_Stationen) {
        } else {
          guard3 = true;
        }
        break;

       case c15_IN_Werkstueck_aufnehmen:
        CV_STATE_EVAL(18, 0, 3);
        c15_Werkstueck_aufnehmen(chartInstance);
        if (*c15_is_c15_KitGewerk2_v14 != c15_IN_Routinen_Stationen) {
        } else {
          guard3 = true;
        }
        break;

       default:
        CV_STATE_EVAL(18, 0, 0);
        *c15_is_Routinen_Stationen = c15_IN_NO_ACTIVE_CHILD;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 19U, *c15_sfEvent);
        guard3 = true;
        break;
      }

      if (guard3 == true) {
        _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 18U, *c15_sfEvent);
      }
      break;

     case c15_IN_Routinen_Warteplaetze:
      CV_CHART_EVAL(14, 0, 11);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 18U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 36U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Warten_auf_neuen_Auftrag;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 41U, *c15_sfEvent);
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 36U, *c15_sfEvent);
      break;

     case c15_IN_Station_aendern:
      CV_CHART_EVAL(14, 0, 12);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 42U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 38U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Routinen_Stationen;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 18U, *c15_sfEvent);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 14U, *c15_sfEvent);
      *c15_is_Routinen_Stationen = c15_IN_Wegpunktliste_erstellen_state;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 19U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_debug_family_names,
        c15_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_h_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_h_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
      c15_Wegpunktliste_erstellen(chartInstance, *c15_UI_Auftrnr, (uint8_T)
        *c15_B_Endst, c15_dv2);
      for (c15_i11 = 0; c15_i11 < 200; c15_i11++) {
        (*c15_A_WPL)[c15_i11] = c15_dv2[c15_i11];
      }

      c15_updateDataWrittenToVector(chartInstance, 2U);
      for (c15_i12 = 0; c15_i12 < 200; c15_i12++) {
        _SFD_DATA_RANGE_CHECK((*c15_A_WPL)[c15_i12], 2U);
      }

      c15_errorIfDataNotWrittenToFcn(chartInstance, 2U, 2U);
      sf_mex_printf("%s =\\n", "A_WPL");
      for (c15_i13 = 0; c15_i13 < 200; c15_i13++) {
        c15_e_u[c15_i13] = (*c15_A_WPL)[c15_i13];
      }

      c15_e_y = NULL;
      sf_mex_assign(&c15_e_y, sf_mex_create("y", c15_e_u, 0, 0U, 1U, 0U, 2, 50,
        4), false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_e_y);
      *c15_B_WPL_cnt_reset = true;
      c15_updateDataWrittenToVector(chartInstance, 6U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WPL_cnt_reset, 9U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 6U, 9U);
      sf_mex_printf("%s =\\n", "B_WPL_cnt_reset");
      c15_d_hoistedGlobal = *c15_B_WPL_cnt_reset;
      c15_f_u = c15_d_hoistedGlobal;
      c15_f_y = NULL;
      sf_mex_assign(&c15_f_y, sf_mex_create("y", &c15_f_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_f_y);
      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 38U, *c15_sfEvent);
      break;

     case c15_IN_Stationsentscheider:
      CV_CHART_EVAL(14, 0, 13);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 19U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 39U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_A_stern_fahrt;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, *c15_sfEvent);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 36U, *c15_sfEvent);
      *c15_is_A_stern_fahrt = c15_IN_A_stern;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, *c15_sfEvent);
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 39U, *c15_sfEvent);
      break;

     case c15_IN_Warten_auf_Auftrag:
      CV_CHART_EVAL(14, 0, 14);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 34U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_qb_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_i_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_i_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_out, 2U, c15_e_sf_marshallOut,
        c15_e_sf_marshallIn);
      guard2 = false;
      if (CV_EML_COND(34, 0, 0, (real_T)*c15_UI_Startstation_in == 200.0)) {
        if (CV_EML_COND(34, 0, 1, (real_T)*c15_UI_Endstation_in == 200.0)) {
          CV_EML_MCDC(34, 0, 0, true);
          CV_EML_IF(34, 0, 0, true);
          c15_d_out = true;
        } else {
          guard2 = true;
        }
      } else {
        guard2 = true;
      }

      if (guard2 == true) {
        CV_EML_MCDC(34, 0, 0, false);
        CV_EML_IF(34, 0, 0, false);
        c15_d_out = false;
      }

      _SFD_SYMBOL_SCOPE_POP();
      if (c15_d_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 34U, *c15_sfEvent);
        *c15_is_c15_KitGewerk2_v14 = c15_IN_NO_ACTIVE_CHILD;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 40U, *c15_sfEvent);
        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_rb_debug_family_names,
          c15_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_j_nargin, 0U,
          c15_sf_marshallOut, c15_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_j_nargout, 1U,
          c15_sf_marshallOut, c15_sf_marshallIn);
        *c15_UI_to_GW1 = 200U;
        c15_updateDataWrittenToVector(chartInstance, 7U);
        _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
        sf_mex_printf("%s =\\n", "UI_to_GW1");
        c15_e_hoistedGlobal = *c15_UI_to_GW1;
        c15_g_u = c15_e_hoistedGlobal;
        c15_g_y = NULL;
        sf_mex_assign(&c15_g_y, sf_mex_create("y", &c15_g_u, 3, 0U, 0U, 0U, 0),
                      false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14,
                          c15_g_y);
        _SFD_SYMBOL_SCOPE_POP();
        *c15_is_c15_KitGewerk2_v14 = c15_IN_Auftrag_empfangen;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, *c15_sfEvent);
      } else {
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 40U, *c15_sfEvent);
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 40U, *c15_sfEvent);
      break;

     case c15_IN_Warten_auf_neuen_Auftrag:
      CV_CHART_EVAL(14, 0, 15);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 32U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_vb_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_k_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_k_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_out, 2U, c15_e_sf_marshallOut,
        c15_e_sf_marshallIn);
      guard1 = false;
      if (CV_EML_COND(32, 0, 0, (real_T)*c15_UI_Startstation_in == 200.0)) {
        if (CV_EML_COND(32, 0, 1, (real_T)*c15_UI_Endstation_in == 200.0)) {
          CV_EML_MCDC(32, 0, 0, true);
          CV_EML_IF(32, 0, 0, true);
          c15_e_out = true;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1 == true) {
        CV_EML_MCDC(32, 0, 0, false);
        CV_EML_IF(32, 0, 0, false);
        c15_e_out = false;
      }

      _SFD_SYMBOL_SCOPE_POP();
      if (c15_e_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 32U, *c15_sfEvent);
        *c15_is_c15_KitGewerk2_v14 = c15_IN_NO_ACTIVE_CHILD;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 41U, *c15_sfEvent);
        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_wb_debug_family_names,
          c15_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_l_nargin, 0U,
          c15_sf_marshallOut, c15_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_l_nargout, 1U,
          c15_sf_marshallOut, c15_sf_marshallIn);
        *c15_UI_to_GW1 = 200U;
        c15_updateDataWrittenToVector(chartInstance, 7U);
        _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
        sf_mex_printf("%s =\\n", "UI_to_GW1");
        c15_f_hoistedGlobal = *c15_UI_to_GW1;
        c15_h_u = c15_f_hoistedGlobal;
        c15_h_y = NULL;
        sf_mex_assign(&c15_h_y, sf_mex_create("y", &c15_h_u, 3, 0U, 0U, 0U, 0),
                      false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14,
                          c15_h_y);
        _SFD_SYMBOL_SCOPE_POP();
        *c15_is_c15_KitGewerk2_v14 = c15_IN_Auftrag_empfangen1;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, *c15_sfEvent);
      } else {
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 41U, *c15_sfEvent);
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 41U, *c15_sfEvent);
      break;

     default:
      CV_CHART_EVAL(14, 0, 0);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, *c15_sfEvent);
      break;
    }
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 14U, *c15_sfEvent);
}

static void initSimStructsc15_KitGewerk2_v14(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance)
{
  (void)chartInstance;
}

static void c15_Werkstueck_aufnehmen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  boolean_T c15_hoistedGlobal;
  boolean_T c15_u;
  const mxArray *c15_y = NULL;
  boolean_T c15_b_hoistedGlobal;
  boolean_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  boolean_T c15_c_hoistedGlobal;
  boolean_T c15_c_u;
  const mxArray *c15_c_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 1.0;
  boolean_T c15_b_out;
  real_T c15_d_nargin = 0.0;
  real_T c15_d_nargout = 0.0;
  boolean_T c15_d_hoistedGlobal;
  boolean_T c15_d_u;
  const mxArray *c15_d_y = NULL;
  real_T c15_e_nargin = 0.0;
  real_T c15_e_nargout = 0.0;
  boolean_T c15_e_hoistedGlobal;
  boolean_T c15_e_u;
  const mxArray *c15_e_y = NULL;
  real_T c15_f_nargin = 0.0;
  real_T c15_f_nargout = 1.0;
  boolean_T c15_c_out;
  real_T c15_g_nargin = 0.0;
  real_T c15_g_nargout = 0.0;
  boolean_T c15_f_hoistedGlobal;
  boolean_T c15_f_u;
  const mxArray *c15_f_y = NULL;
  boolean_T c15_g_hoistedGlobal;
  boolean_T c15_g_u;
  const mxArray *c15_g_y = NULL;
  real_T c15_h_nargin = 0.0;
  real_T c15_h_nargout = 0.0;
  uint8_T c15_h_hoistedGlobal;
  uint8_T c15_h_u;
  const mxArray *c15_h_y = NULL;
  boolean_T c15_i_hoistedGlobal;
  boolean_T c15_i_u;
  const mxArray *c15_i_y = NULL;
  real_T c15_i_nargin = 0.0;
  real_T c15_i_nargout = 0.0;
  boolean_T c15_j_hoistedGlobal;
  boolean_T c15_j_u;
  const mxArray *c15_j_y = NULL;
  real_T c15_j_nargin = 0.0;
  real_T c15_j_nargout = 0.0;
  boolean_T c15_k_hoistedGlobal;
  boolean_T c15_k_u;
  const mxArray *c15_k_y = NULL;
  real_T c15_k_nargin = 0.0;
  real_T c15_k_nargout = 1.0;
  boolean_T c15_d_out;
  uint8_T *c15_is_Werkstueck_aufnehmen;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_temporalCounter_i1;
  boolean_T *c15_B_Schieber;
  boolean_T *c15_B_Lichtschranke;
  boolean_T *c15_B_WP_weiter;
  boolean_T *c15_B_Greifer;
  boolean_T *c15_B_Stop;
  uint8_T *c15_UI_from_GW1;
  uint8_T *c15_UI_to_GW1;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  boolean_T *c15_B_Endst;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_B_Lichtschranke = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c15_B_Greifer = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c15_B_WP_weiter = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c15_B_Stop = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c15_UI_from_GW1 = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c15_B_Schieber = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 0);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_Werkstueck_aufnehmen = (uint8_T *)ssGetDWork(chartInstance->S, 5);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 29U, *c15_sfEvent);
  guard1 = false;
  switch (*c15_is_Werkstueck_aufnehmen) {
   case c15_IN_Fahrt_zu_Platz1:
    CV_STATE_EVAL(29, 0, 1);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 4U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_y_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    guard2 = false;
    if (CV_EML_COND(4, 0, 0, *c15_B_Schieber)) {
      if (CV_EML_COND(4, 0, 1, *c15_B_Lichtschranke)) {
        CV_EML_MCDC(4, 0, 0, true);
        CV_EML_IF(4, 0, 0, true);
        c15_out = true;
      } else {
        guard2 = true;
      }
    } else {
      guard2 = true;
    }

    if (guard2 == true) {
      CV_EML_MCDC(4, 0, 0, false);
      CV_EML_IF(4, 0, 0, false);
      c15_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 4U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 30U, *c15_sfEvent);
      *c15_is_Werkstueck_aufnehmen = c15_IN_Greifer_schlie;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 31U, *c15_sfEvent);
      *c15_temporalCounter_i1 = 0U;
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_d_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_WP_weiter = true;
      c15_updateDataWrittenToVector(chartInstance, 4U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
      sf_mex_printf("%s =\\n", "B_WP_weiter");
      c15_hoistedGlobal = *c15_B_WP_weiter;
      c15_u = c15_hoistedGlobal;
      c15_y = NULL;
      sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 11, 0U, 0U, 0U, 0), false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
      *c15_B_Greifer = true;
      c15_updateDataWrittenToVector(chartInstance, 5U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Greifer, 7U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 5U, 7U);
      sf_mex_printf("%s =\\n", "B_Greifer");
      c15_b_hoistedGlobal = *c15_B_Greifer;
      c15_b_u = c15_b_hoistedGlobal;
      c15_b_y = NULL;
      sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
      *c15_B_Stop = true;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_c_hoistedGlobal = *c15_B_Stop;
      c15_c_u = c15_c_hoistedGlobal;
      c15_c_y = NULL;
      sf_mex_assign(&c15_c_y, sf_mex_create("y", &c15_c_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_c_y);
      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 30U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 30U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Greifer_schlie:
    CV_STATE_EVAL(29, 0, 2);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 7U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_ab_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_b_out = CV_EML_IF(7, 0, 0, *c15_temporalCounter_i1 >= 100);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_b_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 7U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 31U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_e_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_Stop = false;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_d_hoistedGlobal = *c15_B_Stop;
      c15_d_u = c15_d_hoistedGlobal;
      c15_d_y = NULL;
      sf_mex_assign(&c15_d_y, sf_mex_create("y", &c15_d_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_d_y);
      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 31U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 31U, *c15_sfEvent);
      *c15_is_Werkstueck_aufnehmen = c15_IN_Weiterfahren_zu_RFID;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 35U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_f_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_WP_weiter = false;
      c15_updateDataWrittenToVector(chartInstance, 4U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
      sf_mex_printf("%s =\\n", "B_WP_weiter");
      c15_e_hoistedGlobal = *c15_B_WP_weiter;
      c15_e_u = c15_e_hoistedGlobal;
      c15_e_y = NULL;
      sf_mex_assign(&c15_e_y, sf_mex_create("y", &c15_e_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_e_y);
      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 31U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 31U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_RFID_lesen_2:
    CV_STATE_EVAL(29, 0, 3);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 9U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_cb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_f_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_f_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_c_out = CV_EML_IF(9, 0, 0, (real_T)*c15_UI_from_GW1 == 2.0);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_c_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 9U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 32U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_h_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_g_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_g_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_Stop = false;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_f_hoistedGlobal = *c15_B_Stop;
      c15_f_u = c15_f_hoistedGlobal;
      c15_f_y = NULL;
      sf_mex_assign(&c15_f_y, sf_mex_create("y", &c15_f_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_f_y);
      *c15_B_WP_weiter = true;
      c15_updateDataWrittenToVector(chartInstance, 4U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
      sf_mex_printf("%s =\\n", "B_WP_weiter");
      c15_g_hoistedGlobal = *c15_B_WP_weiter;
      c15_g_u = c15_g_hoistedGlobal;
      c15_g_y = NULL;
      sf_mex_assign(&c15_g_y, sf_mex_create("y", &c15_g_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_g_y);
      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 32U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 32U, *c15_sfEvent);
      *c15_is_Werkstueck_aufnehmen = c15_IN_WP_weiterschalten_3;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 34U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 32U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_g_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_h_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_h_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_UI_to_GW1 = 2U;
      c15_updateDataWrittenToVector(chartInstance, 7U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
      sf_mex_printf("%s =\\n", "UI_to_GW1");
      c15_h_hoistedGlobal = *c15_UI_to_GW1;
      c15_h_u = c15_h_hoistedGlobal;
      c15_h_y = NULL;
      sf_mex_assign(&c15_h_y, sf_mex_create("y", &c15_h_u, 3, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_h_y);
      *c15_B_Stop = true;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_i_hoistedGlobal = *c15_B_Stop;
      c15_i_u = c15_i_hoistedGlobal;
      c15_i_y = NULL;
      sf_mex_assign(&c15_i_y, sf_mex_create("y", &c15_i_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_i_y);
      _SFD_SYMBOL_SCOPE_POP();
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 32U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Routine_fertig:
    CV_STATE_EVAL(29, 0, 4);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 21U, *c15_sfEvent);
    *c15_is_Werkstueck_aufnehmen = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 33U, *c15_sfEvent);
    *c15_is_Routinen_Stationen = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 29U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 18U, *c15_sfEvent);
    *c15_is_c15_KitGewerk2_v14 = c15_IN_Nav2_abfrage;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 10U, *c15_sfEvent);
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 33U, *c15_sfEvent);
    if (*c15_is_Routinen_Stationen != c15_IN_Werkstueck_aufnehmen) {
    } else {
      guard1 = true;
    }
    break;

   case c15_IN_WP_weiterschalten_3:
    CV_STATE_EVAL(29, 0, 5);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 10U, *c15_sfEvent);
    *c15_is_Werkstueck_aufnehmen = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 34U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_db_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_i_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_i_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_B_WP_weiter = false;
    c15_updateDataWrittenToVector(chartInstance, 4U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
    sf_mex_printf("%s =\\n", "B_WP_weiter");
    c15_j_hoistedGlobal = *c15_B_WP_weiter;
    c15_j_u = c15_j_hoistedGlobal;
    c15_j_y = NULL;
    sf_mex_assign(&c15_j_y, sf_mex_create("y", &c15_j_u, 11, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_j_y);
    _SFD_SYMBOL_SCOPE_POP();
    *c15_is_Werkstueck_aufnehmen = c15_IN_Routine_fertig;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 33U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_i_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_j_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_j_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_B_Endst = true;
    c15_updateDataWrittenToVector(chartInstance, 0U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Endst, 0U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
    sf_mex_printf("%s =\\n", "B_Endst");
    c15_k_hoistedGlobal = *c15_B_Endst;
    c15_k_u = c15_k_hoistedGlobal;
    c15_k_y = NULL;
    sf_mex_assign(&c15_k_y, sf_mex_create("y", &c15_k_u, 11, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_k_y);
    _SFD_SYMBOL_SCOPE_POP();
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 34U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Weiterfahren_zu_RFID:
    CV_STATE_EVAL(29, 0, 6);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 8U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_bb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_k_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_k_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_d_out = CV_EML_IF(8, 0, 0, *c15_B_Schieber);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_d_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 8U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 35U, *c15_sfEvent);
      *c15_is_Werkstueck_aufnehmen = c15_IN_RFID_lesen_2;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 32U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 35U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 35U, *c15_sfEvent);
    guard1 = true;
    break;

   default:
    CV_STATE_EVAL(29, 0, 0);
    *c15_is_Werkstueck_aufnehmen = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 30U, *c15_sfEvent);
    guard1 = true;
    break;
  }

  if (guard1 == true) {
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 29U, *c15_sfEvent);
  }
}

static void c15_Werkstueck_ablegen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  uint8_T c15_hoistedGlobal;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  boolean_T c15_b_hoistedGlobal;
  boolean_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 1.0;
  boolean_T c15_b_out;
  real_T c15_d_nargin = 0.0;
  real_T c15_d_nargout = 0.0;
  boolean_T c15_c_hoistedGlobal;
  boolean_T c15_c_u;
  const mxArray *c15_c_y = NULL;
  boolean_T c15_d_hoistedGlobal;
  boolean_T c15_d_u;
  const mxArray *c15_d_y = NULL;
  boolean_T c15_e_hoistedGlobal;
  boolean_T c15_e_u;
  const mxArray *c15_e_y = NULL;
  real_T c15_e_nargin = 0.0;
  real_T c15_e_nargout = 1.0;
  boolean_T c15_c_out;
  real_T c15_f_nargin = 0.0;
  real_T c15_f_nargout = 0.0;
  uint8_T c15_f_hoistedGlobal;
  uint8_T c15_f_u;
  const mxArray *c15_f_y = NULL;
  boolean_T c15_g_hoistedGlobal;
  boolean_T c15_g_u;
  const mxArray *c15_g_y = NULL;
  real_T c15_g_nargin = 0.0;
  real_T c15_g_nargout = 1.0;
  boolean_T c15_d_out;
  real_T c15_h_nargin = 0.0;
  real_T c15_h_nargout = 0.0;
  boolean_T c15_h_hoistedGlobal;
  boolean_T c15_h_u;
  const mxArray *c15_h_y = NULL;
  real_T c15_i_nargin = 0.0;
  real_T c15_i_nargout = 1.0;
  boolean_T c15_e_out;
  real_T c15_j_nargin = 0.0;
  real_T c15_j_nargout = 0.0;
  boolean_T c15_i_hoistedGlobal;
  boolean_T c15_i_u;
  const mxArray *c15_i_y = NULL;
  boolean_T c15_j_hoistedGlobal;
  boolean_T c15_j_u;
  const mxArray *c15_j_y = NULL;
  real_T c15_k_nargin = 0.0;
  real_T c15_k_nargout = 0.0;
  boolean_T c15_k_hoistedGlobal;
  boolean_T c15_k_u;
  const mxArray *c15_k_y = NULL;
  real_T c15_l_nargin = 0.0;
  real_T c15_l_nargout = 0.0;
  boolean_T c15_l_hoistedGlobal;
  boolean_T c15_l_u;
  const mxArray *c15_l_y = NULL;
  uint8_T *c15_is_Werkstueck_ablegen;
  uint8_T *c15_is_Routinen_Stationen;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  boolean_T *c15_B_last_WP;
  boolean_T *c15_B_da;
  uint8_T *c15_UI_to_GW1;
  boolean_T *c15_B_Endst;
  uint8_T *c15_temporalCounter_i1;
  boolean_T *c15_B_Schieber;
  boolean_T *c15_B_Stop;
  boolean_T *c15_B_Greifer;
  boolean_T *c15_B_WP_weiter;
  uint8_T *c15_UI_from_GW1;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  c15_temporalCounter_i1 = (uint8_T *)ssGetDWork(chartInstance->S, 13);
  c15_B_da = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c15_B_last_WP = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_B_Greifer = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c15_B_WP_weiter = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c15_B_Stop = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c15_UI_from_GW1 = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c15_B_Schieber = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 0);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_Werkstueck_ablegen = (uint8_T *)ssGetDWork(chartInstance->S, 6);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 21U, *c15_sfEvent);
  guard1 = false;
  switch (*c15_is_Werkstueck_ablegen) {
   case c15_IN_Auftrag_fertig:
    CV_STATE_EVAL(21, 0, 1);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 12U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_ac_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    guard2 = false;
    if (CV_EML_COND(12, 0, 0, *c15_B_last_WP)) {
      if (CV_EML_COND(12, 0, 1, *c15_B_da)) {
        CV_EML_MCDC(12, 0, 0, true);
        CV_EML_IF(12, 0, 0, true);
        c15_out = true;
      } else {
        guard2 = true;
      }
    } else {
      guard2 = true;
    }

    if (guard2 == true) {
      CV_EML_MCDC(12, 0, 0, false);
      CV_EML_IF(12, 0, 0, false);
      c15_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 12U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 22U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_q_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_UI_to_GW1 = 5U;
      c15_updateDataWrittenToVector(chartInstance, 7U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
      sf_mex_printf("%s =\\n", "UI_to_GW1");
      c15_hoistedGlobal = *c15_UI_to_GW1;
      c15_u = c15_hoistedGlobal;
      c15_y = NULL;
      sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0), false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
      *c15_B_Endst = false;
      c15_updateDataWrittenToVector(chartInstance, 0U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Endst, 0U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
      sf_mex_printf("%s =\\n", "B_Endst");
      c15_b_hoistedGlobal = *c15_B_Endst;
      c15_b_u = c15_b_hoistedGlobal;
      c15_b_y = NULL;
      sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 22U, *c15_sfEvent);
      *c15_is_Werkstueck_ablegen = c15_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 22U, *c15_sfEvent);
      *c15_is_Routinen_Stationen = c15_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 21U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 18U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Warten_auf_neuen_Auftrag;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 41U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 22U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 22U, *c15_sfEvent);
    if (*c15_is_Routinen_Stationen != c15_IN_Werkstueck_ablegen) {
    } else {
      guard1 = true;
    }
    break;

   case c15_IN_Fahrt_zu_Ablage:
    CV_STATE_EVAL(21, 0, 2);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 2U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_gb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_b_out = CV_EML_IF(2, 0, 0, *c15_B_Schieber);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_b_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 2U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 23U, *c15_sfEvent);
      *c15_is_Werkstueck_ablegen = c15_IN_Greifer_Oeffnen;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 25U, *c15_sfEvent);
      *c15_temporalCounter_i1 = 0U;
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_n_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_Stop = true;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_c_hoistedGlobal = *c15_B_Stop;
      c15_c_u = c15_c_hoistedGlobal;
      c15_c_y = NULL;
      sf_mex_assign(&c15_c_y, sf_mex_create("y", &c15_c_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_c_y);
      *c15_B_Greifer = false;
      c15_updateDataWrittenToVector(chartInstance, 5U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Greifer, 7U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 5U, 7U);
      sf_mex_printf("%s =\\n", "B_Greifer");
      c15_d_hoistedGlobal = *c15_B_Greifer;
      c15_d_u = c15_d_hoistedGlobal;
      c15_d_y = NULL;
      sf_mex_assign(&c15_d_y, sf_mex_create("y", &c15_d_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_d_y);
      *c15_B_WP_weiter = true;
      c15_updateDataWrittenToVector(chartInstance, 4U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
      sf_mex_printf("%s =\\n", "B_WP_weiter");
      c15_e_hoistedGlobal = *c15_B_WP_weiter;
      c15_e_u = c15_e_hoistedGlobal;
      c15_e_y = NULL;
      sf_mex_assign(&c15_e_y, sf_mex_create("y", &c15_e_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_e_y);
      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 23U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 23U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Fahrt_zu_RFID:
    CV_STATE_EVAL(21, 0, 3);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 3U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_eb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_c_out = CV_EML_IF(3, 0, 0, *c15_B_Schieber);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_c_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 3U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 24U, *c15_sfEvent);
      *c15_is_Werkstueck_ablegen = c15_IN_RFID_lesen;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 26U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_k_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_f_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_f_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_UI_to_GW1 = 4U;
      c15_updateDataWrittenToVector(chartInstance, 7U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
      sf_mex_printf("%s =\\n", "UI_to_GW1");
      c15_f_hoistedGlobal = *c15_UI_to_GW1;
      c15_f_u = c15_f_hoistedGlobal;
      c15_f_y = NULL;
      sf_mex_assign(&c15_f_y, sf_mex_create("y", &c15_f_u, 3, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_f_y);
      *c15_B_Stop = true;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_g_hoistedGlobal = *c15_B_Stop;
      c15_g_u = c15_g_hoistedGlobal;
      c15_g_y = NULL;
      sf_mex_assign(&c15_g_y, sf_mex_create("y", &c15_g_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_g_y);
      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 24U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 24U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Greifer_Oeffnen:
    CV_STATE_EVAL(21, 0, 4);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 5U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_hb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_g_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_g_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_d_out = CV_EML_IF(5, 0, 0, *c15_temporalCounter_i1 >= 100);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_d_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 5U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 25U, *c15_sfEvent);
      *c15_is_Werkstueck_ablegen = c15_IN_WP_weiterschalten2;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 28U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_o_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_h_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_h_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_Stop = false;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_h_hoistedGlobal = *c15_B_Stop;
      c15_h_u = c15_h_hoistedGlobal;
      c15_h_y = NULL;
      sf_mex_assign(&c15_h_y, sf_mex_create("y", &c15_h_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_h_y);
      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 25U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 25U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_RFID_lesen:
    CV_STATE_EVAL(21, 0, 5);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 0U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_fb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_i_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_i_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_e_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_e_out = CV_EML_IF(0, 0, 0, (real_T)*c15_UI_from_GW1 == 4.0);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_e_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 0U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 26U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_l_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_j_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_j_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      *c15_B_Stop = false;
      c15_updateDataWrittenToVector(chartInstance, 3U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_Stop, 5U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 3U, 5U);
      sf_mex_printf("%s =\\n", "B_Stop");
      c15_i_hoistedGlobal = *c15_B_Stop;
      c15_i_u = c15_i_hoistedGlobal;
      c15_i_y = NULL;
      sf_mex_assign(&c15_i_y, sf_mex_create("y", &c15_i_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_i_y);
      *c15_B_WP_weiter = true;
      c15_updateDataWrittenToVector(chartInstance, 4U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
      sf_mex_printf("%s =\\n", "B_WP_weiter");
      c15_j_hoistedGlobal = *c15_B_WP_weiter;
      c15_j_u = c15_j_hoistedGlobal;
      c15_j_y = NULL;
      sf_mex_assign(&c15_j_y, sf_mex_create("y", &c15_j_u, 11, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_j_y);
      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 26U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 26U, *c15_sfEvent);
      *c15_is_Werkstueck_ablegen = c15_IN_WP_weiterschalten;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 27U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 26U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 26U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_WP_weiterschalten:
    CV_STATE_EVAL(21, 0, 6);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 1U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 27U, *c15_sfEvent);
    *c15_is_Werkstueck_ablegen = c15_IN_Fahrt_zu_Ablage;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 23U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_m_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_k_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_k_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_B_WP_weiter = false;
    c15_updateDataWrittenToVector(chartInstance, 4U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
    sf_mex_printf("%s =\\n", "B_WP_weiter");
    c15_k_hoistedGlobal = *c15_B_WP_weiter;
    c15_k_u = c15_k_hoistedGlobal;
    c15_k_y = NULL;
    sf_mex_assign(&c15_k_y, sf_mex_create("y", &c15_k_u, 11, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_k_y);
    _SFD_SYMBOL_SCOPE_POP();
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 27U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_WP_weiterschalten2:
    CV_STATE_EVAL(21, 0, 7);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 6U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 28U, *c15_sfEvent);
    *c15_is_Werkstueck_ablegen = c15_IN_Auftrag_fertig;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 22U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_p_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_l_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_l_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_B_WP_weiter = false;
    c15_updateDataWrittenToVector(chartInstance, 4U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WP_weiter, 6U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 4U, 6U);
    sf_mex_printf("%s =\\n", "B_WP_weiter");
    c15_l_hoistedGlobal = *c15_B_WP_weiter;
    c15_l_u = c15_l_hoistedGlobal;
    c15_l_y = NULL;
    sf_mex_assign(&c15_l_y, sf_mex_create("y", &c15_l_u, 11, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_l_y);
    _SFD_SYMBOL_SCOPE_POP();
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 28U, *c15_sfEvent);
    guard1 = true;
    break;

   default:
    CV_STATE_EVAL(21, 0, 0);
    *c15_is_Werkstueck_ablegen = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 22U, *c15_sfEvent);
    guard1 = true;
    break;
  }

  if (guard1 == true) {
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 21U, *c15_sfEvent);
  }
}

static void c15_Fahrt_in_nav_2(SFc15_KitGewerk2_v14InstanceStruct *chartInstance)
{
  uint32_T c15_debug_family_var_map[2];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 0.0;
  uint8_T c15_hoistedGlobal;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  uint8_T c15_b_hoistedGlobal;
  uint8_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_UI_Endstation;
  int32_T *c15_sfEvent;
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 41U, *c15_sfEvent);
  _SFD_CS_CALL(STATE_INACTIVE_TAG, 6U, *c15_sfEvent);
  *c15_is_c15_KitGewerk2_v14 = c15_IN_Station_aendern;
  _SFD_CS_CALL(STATE_ACTIVE_TAG, 38U, *c15_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_r_debug_family_names,
    c15_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
  if (CV_EML_IF(38, 1, 0, !*c15_B_Endst)) {
    *c15_UI_Auftrnr = *c15_UI_Startstation;
    c15_updateDataWrittenToVector(chartInstance, 1U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
    sf_mex_printf("%s =\\n", "UI_Auftrnr");
    c15_hoistedGlobal = *c15_UI_Auftrnr;
    c15_u = c15_hoistedGlobal;
    c15_y = NULL;
    sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0), false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
  } else {
    c15_errorIfDataNotWrittenToFcn(chartInstance, 8U, 12U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 9U, 13U);
    *c15_UI_Auftrnr = *c15_UI_Endstation;
    c15_updateDataWrittenToVector(chartInstance, 1U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
    sf_mex_printf("%s =\\n", "UI_Auftrnr");
    c15_b_hoistedGlobal = *c15_UI_Auftrnr;
    c15_b_u = c15_b_hoistedGlobal;
    c15_b_y = NULL;
    sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 3, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
  }

  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 6U, *c15_sfEvent);
}

static void c15_Eintrittspunkt_erreicht(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  real_T c15_dv3[200];
  int32_T c15_i14;
  int32_T c15_i15;
  int32_T c15_i16;
  real_T c15_u[200];
  const mxArray *c15_y = NULL;
  boolean_T c15_hoistedGlobal;
  boolean_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 1.0;
  boolean_T c15_b_out;
  real_T c15_d_nargin = 0.0;
  real_T c15_d_nargout = 1.0;
  boolean_T c15_c_out;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_UI_Auftrnr;
  uint8_T *c15_is_Routinen_Ladestationen;
  uint8_T *c15_is_Routinen_Stationen;
  boolean_T *c15_B_Endst;
  boolean_T *c15_B_WPL_cnt_reset;
  real_T (*c15_A_WPL)[200];
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  c15_B_WPL_cnt_reset = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c15_A_WPL = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 1);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_Routinen_Ladestationen = (uint8_T *)ssGetDWork(chartInstance->S, 8);
  c15_is_Routinen_Stationen = (uint8_T *)ssGetDWork(chartInstance->S, 4);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 15U, *c15_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_pb_debug_family_names,
    c15_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
    c15_e_sf_marshallIn);
  c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
  c15_out = CV_EML_IF(15, 0, 0, (real_T)*c15_UI_Auftrnr <= 16.0);
  _SFD_SYMBOL_SCOPE_POP();
  if (c15_out) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 15U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, *c15_sfEvent);
    *c15_is_c15_KitGewerk2_v14 = c15_IN_Routinen_Stationen;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 18U, *c15_sfEvent);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 14U, *c15_sfEvent);
    *c15_is_Routinen_Stationen = c15_IN_Wegpunktliste_erstellen_state;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 19U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
    c15_Wegpunktliste_erstellen(chartInstance, *c15_UI_Auftrnr, (uint8_T)
      *c15_B_Endst, c15_dv3);
    for (c15_i14 = 0; c15_i14 < 200; c15_i14++) {
      (*c15_A_WPL)[c15_i14] = c15_dv3[c15_i14];
    }

    c15_updateDataWrittenToVector(chartInstance, 2U);
    for (c15_i15 = 0; c15_i15 < 200; c15_i15++) {
      _SFD_DATA_RANGE_CHECK((*c15_A_WPL)[c15_i15], 2U);
    }

    c15_errorIfDataNotWrittenToFcn(chartInstance, 2U, 2U);
    sf_mex_printf("%s =\\n", "A_WPL");
    for (c15_i16 = 0; c15_i16 < 200; c15_i16++) {
      c15_u[c15_i16] = (*c15_A_WPL)[c15_i16];
    }

    c15_y = NULL;
    sf_mex_assign(&c15_y, sf_mex_create("y", c15_u, 0, 0U, 1U, 0U, 2, 50, 4),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
    *c15_B_WPL_cnt_reset = true;
    c15_updateDataWrittenToVector(chartInstance, 6U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_B_WPL_cnt_reset, 9U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 6U, 9U);
    sf_mex_printf("%s =\\n", "B_WPL_cnt_reset");
    c15_hoistedGlobal = *c15_B_WPL_cnt_reset;
    c15_b_u = c15_hoistedGlobal;
    c15_b_y = NULL;
    sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 11, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
    _SFD_SYMBOL_SCOPE_POP();
  } else {
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 16U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_ub_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
    guard1 = false;
    if (CV_EML_COND(16, 0, 0, (real_T)*c15_UI_Auftrnr > 16.0)) {
      if (CV_EML_COND(16, 0, 1, (real_T)*c15_UI_Auftrnr <= 20.0)) {
        CV_EML_MCDC(16, 0, 0, true);
        CV_EML_IF(16, 0, 0, true);
        c15_b_out = true;
      } else {
        guard1 = true;
      }
    } else {
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      guard1 = true;
    }

    if (guard1 == true) {
      CV_EML_MCDC(16, 0, 0, false);
      CV_EML_IF(16, 0, 0, false);
      c15_b_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_b_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 16U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Routinen_Warteplaetze;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 36U, *c15_sfEvent);
    } else {
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 17U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_xb_debug_family_names,
        c15_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_out, 2U, c15_e_sf_marshallOut,
        c15_e_sf_marshallIn);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      c15_c_out = CV_EML_IF(17, 0, 0, (real_T)*c15_UI_Auftrnr > 20.0);
      _SFD_SYMBOL_SCOPE_POP();
      if (c15_c_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 17U, *c15_sfEvent);
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, *c15_sfEvent);
        *c15_is_c15_KitGewerk2_v14 = c15_IN_Routinen_Ladestationen;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 11U, *c15_sfEvent);
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 35U, *c15_sfEvent);
        *c15_is_Routinen_Ladestationen = c15_IN_Wegpunkte;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 17U, *c15_sfEvent);
      } else {
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 5U, *c15_sfEvent);
      }
    }
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 5U, *c15_sfEvent);
}

static void c15_A_stern_fahrt(SFc15_KitGewerk2_v14InstanceStruct *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  uint8_T c15_hoistedGlobal;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  uint8_T c15_b_hoistedGlobal;
  uint8_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 1.0;
  boolean_T c15_b_out;
  uint8_T *c15_is_A_stern_fahrt;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_WP_cnt;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_to_GW1;
  boolean_T *c15_B_last_WP;
  boolean_T *c15_B_da;
  uint8_T *c15_UI_from_GW1;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  c15_WP_cnt = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c15_B_da = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c15_B_last_WP = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c15_UI_from_GW1 = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_A_stern_fahrt = (uint8_T *)ssGetDWork(chartInstance->S, 7);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U, *c15_sfEvent);
  guard1 = false;
  switch (*c15_is_A_stern_fahrt) {
   case c15_IN_A_stern:
    CV_STATE_EVAL(0, 0, 1);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 37U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_kb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    c15_out = CV_EML_IF(37, 0, 0, (real_T)*c15_WP_cnt > 1.0);
    _SFD_SYMBOL_SCOPE_POP();
    if (c15_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 37U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, *c15_sfEvent);
      *c15_is_A_stern_fahrt = c15_IN_Kollisionserkennung;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_s_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
      if (CV_EML_IF(2, 1, 0, !*c15_B_Endst)) {
        *c15_UI_to_GW1 = 1U;
        c15_updateDataWrittenToVector(chartInstance, 7U);
        _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
        sf_mex_printf("%s =\\n", "UI_to_GW1");
        c15_hoistedGlobal = *c15_UI_to_GW1;
        c15_u = c15_hoistedGlobal;
        c15_y = NULL;
        sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0),
                      false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
      } else {
        *c15_UI_to_GW1 = 3U;
        c15_updateDataWrittenToVector(chartInstance, 7U);
        _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_to_GW1, 10U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 7U, 10U);
        sf_mex_printf("%s =\\n", "UI_to_GW1");
        c15_b_hoistedGlobal = *c15_UI_to_GW1;
        c15_b_u = c15_b_hoistedGlobal;
        c15_b_y = NULL;
        sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 3, 0U, 0U, 0U, 0),
                      false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14,
                          c15_b_y);
      }

      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 1U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Kollisionserkennung:
    CV_STATE_EVAL(0, 0, 2);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 38U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_nb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    guard2 = false;
    guard3 = false;
    guard4 = false;
    if (CV_EML_COND(38, 0, 0, *c15_B_last_WP)) {
      if (CV_EML_COND(38, 0, 1, *c15_B_da)) {
        if (CV_EML_COND(38, 0, 2, (real_T)*c15_UI_from_GW1 == 1.0)) {
          guard3 = true;
        } else if (CV_EML_COND(38, 0, 3, (real_T)*c15_UI_from_GW1 == 3.0)) {
          guard3 = true;
        } else {
          guard2 = true;
        }
      } else {
        guard4 = true;
      }
    } else {
      guard4 = true;
    }

    if (guard4 == true) {
      guard2 = true;
    }

    if (guard3 == true) {
      CV_EML_MCDC(38, 0, 0, true);
      CV_EML_IF(38, 0, 0, true);
      c15_b_out = true;
    }

    if (guard2 == true) {
      CV_EML_MCDC(38, 0, 0, false);
      CV_EML_IF(38, 0, 0, false);
      c15_b_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_b_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 38U, *c15_sfEvent);
      *c15_is_A_stern_fahrt = c15_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 2U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Eintrittspunkt_erreicht;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 2U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, *c15_sfEvent);
    if (*c15_is_c15_KitGewerk2_v14 != c15_IN_A_stern_fahrt) {
    } else {
      guard1 = true;
    }
    break;

   default:
    CV_STATE_EVAL(0, 0, 0);
    *c15_is_A_stern_fahrt = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, *c15_sfEvent);
    guard1 = true;
    break;
  }

  if (guard1 == true) {
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, *c15_sfEvent);
  }
}

static void c15_Auftrag_empfangen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  uint8_T c15_hoistedGlobal;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  uint8_T c15_b_hoistedGlobal;
  uint8_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 0.0;
  uint8_T c15_c_hoistedGlobal;
  uint8_T c15_c_u;
  const mxArray *c15_c_y = NULL;
  uint8_T c15_d_hoistedGlobal;
  uint8_T c15_d_u;
  const mxArray *c15_d_y = NULL;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_UI_Startstation_in;
  uint8_T *c15_UI_Endstation_in;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_UI_Endstation;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  c15_UI_Startstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c15_UI_Endstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 39U, *c15_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_sb_debug_family_names,
    c15_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
    c15_e_sf_marshallIn);
  guard1 = false;
  if (CV_EML_COND(39, 0, 0, (real_T)*c15_UI_Startstation_in < 200.0)) {
    if (CV_EML_COND(39, 0, 1, (real_T)*c15_UI_Endstation_in < 200.0)) {
      CV_EML_MCDC(39, 0, 0, true);
      CV_EML_IF(39, 0, 0, true);
      c15_out = true;
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1 == true) {
    CV_EML_MCDC(39, 0, 0, false);
    CV_EML_IF(39, 0, 0, false);
    c15_out = false;
  }

  _SFD_SYMBOL_SCOPE_POP();
  if (c15_out) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 39U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 3U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_v_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_UI_Startstation = *c15_UI_Startstation_in;
    c15_updateDataWrittenToVector(chartInstance, 8U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Startstation, 12U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 8U, 12U);
    sf_mex_printf("%s =\\n", "UI_Startstation");
    c15_hoistedGlobal = *c15_UI_Startstation;
    c15_u = c15_hoistedGlobal;
    c15_y = NULL;
    sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0), false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
    *c15_UI_Endstation = *c15_UI_Endstation_in;
    c15_updateDataWrittenToVector(chartInstance, 9U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Endstation, 13U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 9U, 13U);
    sf_mex_printf("%s =\\n", "UI_Endstation");
    c15_b_hoistedGlobal = *c15_UI_Endstation;
    c15_b_u = c15_b_hoistedGlobal;
    c15_b_y = NULL;
    sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 3, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
    _SFD_SYMBOL_SCOPE_POP();
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 3U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, *c15_sfEvent);
    *c15_is_c15_KitGewerk2_v14 = c15_IN_Stationsentscheider;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 39U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_t_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
    if (CV_EML_IF(39, 1, 0, !*c15_B_Endst)) {
      *c15_UI_Auftrnr = *c15_UI_Startstation;
      c15_updateDataWrittenToVector(chartInstance, 1U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      sf_mex_printf("%s =\\n", "UI_Auftrnr");
      c15_c_hoistedGlobal = *c15_UI_Auftrnr;
      c15_c_u = c15_c_hoistedGlobal;
      c15_c_y = NULL;
      sf_mex_assign(&c15_c_y, sf_mex_create("y", &c15_c_u, 3, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_c_y);
    } else {
      c15_errorIfDataNotWrittenToFcn(chartInstance, 8U, 12U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 9U, 13U);
      *c15_UI_Auftrnr = *c15_UI_Endstation;
      c15_updateDataWrittenToVector(chartInstance, 1U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      sf_mex_printf("%s =\\n", "UI_Auftrnr");
      c15_d_hoistedGlobal = *c15_UI_Auftrnr;
      c15_d_u = c15_d_hoistedGlobal;
      c15_d_y = NULL;
      sf_mex_assign(&c15_d_y, sf_mex_create("y", &c15_d_u, 3, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_d_y);
    }

    _SFD_SYMBOL_SCOPE_POP();
  } else {
    _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 3U, *c15_sfEvent);
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 3U, *c15_sfEvent);
}

static void c15_Routinen_Ladestationen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  uint8_T c15_hoistedGlobal;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  uint8_T c15_b_hoistedGlobal;
  uint8_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 1.0;
  boolean_T c15_b_out;
  real_T c15_d_nargin = 0.0;
  real_T c15_d_nargout = 1.0;
  boolean_T c15_c_out;
  uint8_T *c15_is_Routinen_Ladestationen;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  boolean_T *c15_B_last_WP;
  boolean_T *c15_B_da;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_UI_Endstation;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  c15_B_da = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_B_last_WP = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_Routinen_Ladestationen = (uint8_T *)ssGetDWork(chartInstance->S, 8);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 11U, *c15_sfEvent);
  guard1 = false;
  switch (*c15_is_Routinen_Ladestationen) {
   case c15_IN_Fahrt_an_rand_nav1:
    CV_STATE_EVAL(11, 0, 1);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 30U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_ob_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    guard4 = false;
    if (CV_EML_COND(30, 0, 0, *c15_B_last_WP)) {
      if (CV_EML_COND(30, 0, 1, *c15_B_da)) {
        CV_EML_MCDC(30, 0, 0, true);
        CV_EML_IF(30, 0, 0, true);
        c15_out = true;
      } else {
        guard4 = true;
      }
    } else {
      guard4 = true;
    }

    if (guard4 == true) {
      CV_EML_MCDC(30, 0, 0, false);
      CV_EML_IF(30, 0, 0, false);
      c15_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 30U, *c15_sfEvent);
      *c15_is_Routinen_Ladestationen = c15_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 12U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 11U, *c15_sfEvent);
      *c15_is_c15_KitGewerk2_v14 = c15_IN_Stationsentscheider;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 39U, *c15_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_t_debug_family_names,
        c15_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
        c15_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U,
        c15_sf_marshallOut, c15_sf_marshallIn);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
      if (CV_EML_IF(39, 1, 0, !*c15_B_Endst)) {
        *c15_UI_Auftrnr = *c15_UI_Startstation;
        c15_updateDataWrittenToVector(chartInstance, 1U);
        _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
        sf_mex_printf("%s =\\n", "UI_Auftrnr");
        c15_hoistedGlobal = *c15_UI_Auftrnr;
        c15_u = c15_hoistedGlobal;
        c15_y = NULL;
        sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0),
                      false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
      } else {
        c15_errorIfDataNotWrittenToFcn(chartInstance, 8U, 12U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 9U, 13U);
        *c15_UI_Auftrnr = *c15_UI_Endstation;
        c15_updateDataWrittenToVector(chartInstance, 1U);
        _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
        c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
        sf_mex_printf("%s =\\n", "UI_Auftrnr");
        c15_b_hoistedGlobal = *c15_UI_Auftrnr;
        c15_b_u = c15_b_hoistedGlobal;
        c15_b_y = NULL;
        sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 3, 0U, 0U, 0U, 0),
                      false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14,
                          c15_b_y);
      }

      _SFD_SYMBOL_SCOPE_POP();
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 12U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 12U, *c15_sfEvent);
    if (*c15_is_c15_KitGewerk2_v14 != c15_IN_Routinen_Ladestationen) {
    } else {
      guard1 = true;
    }
    break;

   case c15_IN_Kontakt_fehler:
    CV_STATE_EVAL(11, 0, 2);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 31U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_mb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    guard3 = false;
    if (CV_EML_COND(31, 0, 0, *c15_B_last_WP)) {
      if (CV_EML_COND(31, 0, 1, *c15_B_da)) {
        CV_EML_MCDC(31, 0, 0, true);
        CV_EML_IF(31, 0, 0, true);
        c15_b_out = true;
      } else {
        guard3 = true;
      }
    } else {
      guard3 = true;
    }

    if (guard3 == true) {
      CV_EML_MCDC(31, 0, 0, false);
      CV_EML_IF(31, 0, 0, false);
      c15_b_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_b_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 31U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 13U, *c15_sfEvent);
      *c15_is_Routinen_Ladestationen = c15_IN_Laden_beginnen;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 15U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 13U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 13U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Laden_beenden:
    CV_STATE_EVAL(11, 0, 3);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 29U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 14U, *c15_sfEvent);
    *c15_is_Routinen_Ladestationen = c15_IN_Fahrt_an_rand_nav1;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 12U, *c15_sfEvent);
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 14U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Laden_beginnen:
    CV_STATE_EVAL(11, 0, 4);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 26U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 15U, *c15_sfEvent);
    *c15_is_Routinen_Ladestationen = c15_IN_Kontakt_fehler;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 13U, *c15_sfEvent);
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 15U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Warten_auf_Ereignis:
    CV_STATE_EVAL(11, 0, 5);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 28U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 16U, *c15_sfEvent);
    *c15_is_Routinen_Ladestationen = c15_IN_Laden_beenden;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 14U, *c15_sfEvent);
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 16U, *c15_sfEvent);
    guard1 = true;
    break;

   case c15_IN_Wegpunkte:
    CV_STATE_EVAL(11, 0, 6);
    _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 25U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_lb_debug_family_names,
      c15_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_d_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_out, 2U, c15_e_sf_marshallOut,
      c15_e_sf_marshallIn);
    guard2 = false;
    if (CV_EML_COND(25, 0, 0, *c15_B_last_WP)) {
      if (CV_EML_COND(25, 0, 1, *c15_B_da)) {
        CV_EML_MCDC(25, 0, 0, true);
        CV_EML_IF(25, 0, 0, true);
        c15_c_out = true;
      } else {
        guard2 = true;
      }
    } else {
      guard2 = true;
    }

    if (guard2 == true) {
      CV_EML_MCDC(25, 0, 0, false);
      CV_EML_IF(25, 0, 0, false);
      c15_c_out = false;
    }

    _SFD_SYMBOL_SCOPE_POP();
    if (c15_c_out) {
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 25U, *c15_sfEvent);
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 17U, *c15_sfEvent);
      *c15_is_Routinen_Ladestationen = c15_IN_Laden_beginnen;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 15U, *c15_sfEvent);
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 17U, *c15_sfEvent);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 17U, *c15_sfEvent);
    guard1 = true;
    break;

   default:
    CV_STATE_EVAL(11, 0, 0);
    *c15_is_Routinen_Ladestationen = c15_IN_NO_ACTIVE_CHILD;
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 12U, *c15_sfEvent);
    guard1 = true;
    break;
  }

  if (guard1 == true) {
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 11U, *c15_sfEvent);
  }
}

static void c15_Auftrag_empfangen1(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  uint32_T c15_debug_family_var_map[3];
  real_T c15_nargin = 0.0;
  real_T c15_nargout = 1.0;
  boolean_T c15_out;
  uint32_T c15_b_debug_family_var_map[2];
  real_T c15_b_nargin = 0.0;
  real_T c15_b_nargout = 0.0;
  uint8_T c15_hoistedGlobal;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  uint8_T c15_b_hoistedGlobal;
  uint8_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  real_T c15_c_nargin = 0.0;
  real_T c15_c_nargout = 0.0;
  uint8_T c15_c_hoistedGlobal;
  uint8_T c15_c_u;
  const mxArray *c15_c_y = NULL;
  uint8_T c15_d_hoistedGlobal;
  uint8_T c15_d_u;
  const mxArray *c15_d_y = NULL;
  uint8_T *c15_is_c15_KitGewerk2_v14;
  uint8_T *c15_UI_Startstation_in;
  uint8_T *c15_UI_Endstation_in;
  uint8_T *c15_UI_Startstation;
  uint8_T *c15_UI_Endstation;
  boolean_T *c15_B_Endst;
  uint8_T *c15_UI_Auftrnr;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  c15_UI_Startstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c15_UI_Endstation_in = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
  c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
  c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
  c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
  c15_is_c15_KitGewerk2_v14 = (uint8_T *)ssGetDWork(chartInstance->S, 3);
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 40U, *c15_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c15_yb_debug_family_names,
    c15_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 0U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 1U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_out, 2U, c15_e_sf_marshallOut,
    c15_e_sf_marshallIn);
  guard1 = false;
  if (CV_EML_COND(40, 0, 0, (real_T)*c15_UI_Startstation_in < 200.0)) {
    if (CV_EML_COND(40, 0, 1, (real_T)*c15_UI_Endstation_in < 200.0)) {
      CV_EML_MCDC(40, 0, 0, true);
      CV_EML_IF(40, 0, 0, true);
      c15_out = true;
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1 == true) {
    CV_EML_MCDC(40, 0, 0, false);
    CV_EML_IF(40, 0, 0, false);
    c15_out = false;
  }

  _SFD_SYMBOL_SCOPE_POP();
  if (c15_out) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 40U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_ENTER_EXIT_FUNCTION_TAG, 4U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_x_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_b_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    *c15_UI_Startstation = *c15_UI_Startstation_in;
    c15_updateDataWrittenToVector(chartInstance, 8U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Startstation, 12U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 8U, 12U);
    sf_mex_printf("%s =\\n", "UI_Startstation");
    c15_hoistedGlobal = *c15_UI_Startstation;
    c15_u = c15_hoistedGlobal;
    c15_y = NULL;
    sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0), false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
    *c15_UI_Endstation = *c15_UI_Endstation_in;
    c15_updateDataWrittenToVector(chartInstance, 9U);
    _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Endstation, 13U);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 9U, 13U);
    sf_mex_printf("%s =\\n", "UI_Endstation");
    c15_b_hoistedGlobal = *c15_UI_Endstation;
    c15_b_u = c15_b_hoistedGlobal;
    c15_b_y = NULL;
    sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 3, 0U, 0U, 0U, 0),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_b_y);
    _SFD_SYMBOL_SCOPE_POP();
    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 4U, *c15_sfEvent);
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, *c15_sfEvent);
    *c15_is_c15_KitGewerk2_v14 = c15_IN_Stationsentscheider;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 39U, *c15_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c15_t_debug_family_names,
      c15_b_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargin, 0U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_c_nargout, 1U, c15_sf_marshallOut,
      c15_sf_marshallIn);
    c15_errorIfDataNotWrittenToFcn(chartInstance, 0U, 0U);
    if (CV_EML_IF(39, 1, 0, !*c15_B_Endst)) {
      *c15_UI_Auftrnr = *c15_UI_Startstation;
      c15_updateDataWrittenToVector(chartInstance, 1U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      sf_mex_printf("%s =\\n", "UI_Auftrnr");
      c15_c_hoistedGlobal = *c15_UI_Auftrnr;
      c15_c_u = c15_c_hoistedGlobal;
      c15_c_y = NULL;
      sf_mex_assign(&c15_c_y, sf_mex_create("y", &c15_c_u, 3, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_c_y);
    } else {
      c15_errorIfDataNotWrittenToFcn(chartInstance, 8U, 12U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 9U, 13U);
      *c15_UI_Auftrnr = *c15_UI_Endstation;
      c15_updateDataWrittenToVector(chartInstance, 1U);
      _SFD_DATA_RANGE_CHECK((real_T)*c15_UI_Auftrnr, 1U);
      c15_errorIfDataNotWrittenToFcn(chartInstance, 1U, 1U);
      sf_mex_printf("%s =\\n", "UI_Auftrnr");
      c15_d_hoistedGlobal = *c15_UI_Auftrnr;
      c15_d_u = c15_d_hoistedGlobal;
      c15_d_y = NULL;
      sf_mex_assign(&c15_d_y, sf_mex_create("y", &c15_d_u, 3, 0U, 0U, 0U, 0),
                    false);
      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_d_y);
    }

    _SFD_SYMBOL_SCOPE_POP();
  } else {
    _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 4U, *c15_sfEvent);
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 4U, *c15_sfEvent);
}

static void init_script_number_translation(uint32_T c15_machineNumber, uint32_T
  c15_chartNumber, uint32_T c15_instanceNumber)
{
  (void)c15_machineNumber;
  (void)c15_chartNumber;
  (void)c15_instanceNumber;
}

static const mxArray *c15_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  real_T c15_u;
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  c15_u = *(real_T *)c15_inData;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static real_T c15_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId)
{
  real_T c15_y;
  real_T c15_d0;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), &c15_d0, 1, 0, 0U, 0, 0U, 0);
  c15_y = c15_d0;
  sf_mex_destroy(&c15_u);
  return c15_y;
}

static void c15_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_nargout;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  real_T c15_y;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_nargout = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_y = c15_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_nargout),
    &c15_thisId);
  sf_mex_destroy(&c15_nargout);
  *(real_T *)c15_outData = c15_y;
  sf_mex_destroy(&c15_mxArrayInData);
}

static const mxArray *c15_b_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  int32_T c15_i17;
  int32_T c15_i18;
  int32_T c15_i19;
  real_T c15_b_inData[200];
  int32_T c15_i20;
  int32_T c15_i21;
  int32_T c15_i22;
  real_T c15_u[200];
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  c15_i17 = 0;
  for (c15_i18 = 0; c15_i18 < 4; c15_i18++) {
    for (c15_i19 = 0; c15_i19 < 50; c15_i19++) {
      c15_b_inData[c15_i19 + c15_i17] = (*(real_T (*)[200])c15_inData)[c15_i19 +
        c15_i17];
    }

    c15_i17 += 50;
  }

  c15_i20 = 0;
  for (c15_i21 = 0; c15_i21 < 4; c15_i21++) {
    for (c15_i22 = 0; c15_i22 < 50; c15_i22++) {
      c15_u[c15_i22 + c15_i20] = c15_b_inData[c15_i22 + c15_i20];
    }

    c15_i20 += 50;
  }

  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", c15_u, 0, 0U, 1U, 0U, 2, 50, 4),
                false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static void c15_b_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_Wegpunktliste, const char_T *c15_identifier,
  real_T c15_y[200])
{
  emlrtMsgIdentifier c15_thisId;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_Wegpunktliste),
    &c15_thisId, c15_y);
  sf_mex_destroy(&c15_Wegpunktliste);
}

static void c15_c_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId,
  real_T c15_y[200])
{
  real_T c15_dv4[200];
  int32_T c15_i23;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), c15_dv4, 1, 0, 0U, 1, 0U, 2, 50,
                4);
  for (c15_i23 = 0; c15_i23 < 200; c15_i23++) {
    c15_y[c15_i23] = c15_dv4[c15_i23];
  }

  sf_mex_destroy(&c15_u);
}

static void c15_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_Wegpunktliste;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  real_T c15_y[200];
  int32_T c15_i24;
  int32_T c15_i25;
  int32_T c15_i26;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_Wegpunktliste = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_Wegpunktliste),
    &c15_thisId, c15_y);
  sf_mex_destroy(&c15_Wegpunktliste);
  c15_i24 = 0;
  for (c15_i25 = 0; c15_i25 < 4; c15_i25++) {
    for (c15_i26 = 0; c15_i26 < 50; c15_i26++) {
      (*(real_T (*)[200])c15_outData)[c15_i26 + c15_i24] = c15_y[c15_i26 +
        c15_i24];
    }

    c15_i24 += 50;
  }

  sf_mex_destroy(&c15_mxArrayInData);
}

static const mxArray *c15_c_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  uint8_T c15_u;
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  c15_u = *(uint8_T *)c15_inData;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static uint8_T c15_d_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_Is_Endstation, const char_T *c15_identifier)
{
  uint8_T c15_y;
  emlrtMsgIdentifier c15_thisId;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_y = c15_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_Is_Endstation),
    &c15_thisId);
  sf_mex_destroy(&c15_Is_Endstation);
  return c15_y;
}

static uint8_T c15_e_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId)
{
  uint8_T c15_y;
  uint8_T c15_u0;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), &c15_u0, 1, 3, 0U, 0, 0U, 0);
  c15_y = c15_u0;
  sf_mex_destroy(&c15_u);
  return c15_y;
}

static void c15_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_Is_Endstation;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  uint8_T c15_y;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_Is_Endstation = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_y = c15_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_Is_Endstation),
    &c15_thisId);
  sf_mex_destroy(&c15_Is_Endstation);
  *(uint8_T *)c15_outData = c15_y;
  sf_mex_destroy(&c15_mxArrayInData);
}

static const mxArray *c15_d_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  int32_T c15_i27;
  int32_T c15_i28;
  int32_T c15_i29;
  real_T c15_b_inData[12];
  int32_T c15_i30;
  int32_T c15_i31;
  int32_T c15_i32;
  real_T c15_u[12];
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  c15_i27 = 0;
  for (c15_i28 = 0; c15_i28 < 4; c15_i28++) {
    for (c15_i29 = 0; c15_i29 < 3; c15_i29++) {
      c15_b_inData[c15_i29 + c15_i27] = (*(real_T (*)[12])c15_inData)[c15_i29 +
        c15_i27];
    }

    c15_i27 += 3;
  }

  c15_i30 = 0;
  for (c15_i31 = 0; c15_i31 < 4; c15_i31++) {
    for (c15_i32 = 0; c15_i32 < 3; c15_i32++) {
      c15_u[c15_i32 + c15_i30] = c15_b_inData[c15_i32 + c15_i30];
    }

    c15_i30 += 3;
  }

  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", c15_u, 0, 0U, 1U, 0U, 2, 3, 4), false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static void c15_f_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId,
  real_T c15_y[12])
{
  real_T c15_dv5[12];
  int32_T c15_i33;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), c15_dv5, 1, 0, 0U, 1, 0U, 2, 3,
                4);
  for (c15_i33 = 0; c15_i33 < 12; c15_i33++) {
    c15_y[c15_i33] = c15_dv5[c15_i33];
  }

  sf_mex_destroy(&c15_u);
}

static void c15_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_RFID_R;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  real_T c15_y[12];
  int32_T c15_i34;
  int32_T c15_i35;
  int32_T c15_i36;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_RFID_R = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_RFID_R), &c15_thisId,
    c15_y);
  sf_mex_destroy(&c15_RFID_R);
  c15_i34 = 0;
  for (c15_i35 = 0; c15_i35 < 4; c15_i35++) {
    for (c15_i36 = 0; c15_i36 < 3; c15_i36++) {
      (*(real_T (*)[12])c15_outData)[c15_i36 + c15_i34] = c15_y[c15_i36 +
        c15_i34];
    }

    c15_i34 += 3;
  }

  sf_mex_destroy(&c15_mxArrayInData);
}

static const mxArray *c15_e_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  boolean_T c15_u;
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  c15_u = *(boolean_T *)c15_inData;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static boolean_T c15_g_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_sf_internal_predicateOutput, const char_T
  *c15_identifier)
{
  boolean_T c15_y;
  emlrtMsgIdentifier c15_thisId;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_y = c15_h_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c15_sf_internal_predicateOutput), &c15_thisId);
  sf_mex_destroy(&c15_sf_internal_predicateOutput);
  return c15_y;
}

static boolean_T c15_h_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId)
{
  boolean_T c15_y;
  boolean_T c15_b0;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), &c15_b0, 1, 11, 0U, 0, 0U, 0);
  c15_y = c15_b0;
  sf_mex_destroy(&c15_u);
  return c15_y;
}

static void c15_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_sf_internal_predicateOutput;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  boolean_T c15_y;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_sf_internal_predicateOutput = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_y = c15_h_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c15_sf_internal_predicateOutput), &c15_thisId);
  sf_mex_destroy(&c15_sf_internal_predicateOutput);
  *(boolean_T *)c15_outData = c15_y;
  sf_mex_destroy(&c15_mxArrayInData);
}

const mxArray *sf_c15_KitGewerk2_v14_get_eml_resolved_functions_info(void)
{
  const mxArray *c15_nameCaptureInfo = NULL;
  c15_nameCaptureInfo = NULL;
  sf_mex_assign(&c15_nameCaptureInfo, sf_mex_createstruct("structure", 2, 9, 1),
                false);
  c15_info_helper(&c15_nameCaptureInfo);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c15_nameCaptureInfo);
  return c15_nameCaptureInfo;
}

static void c15_info_helper(const mxArray **c15_info)
{
  const mxArray *c15_rhs0 = NULL;
  const mxArray *c15_lhs0 = NULL;
  const mxArray *c15_rhs1 = NULL;
  const mxArray *c15_lhs1 = NULL;
  const mxArray *c15_rhs2 = NULL;
  const mxArray *c15_lhs2 = NULL;
  const mxArray *c15_rhs3 = NULL;
  const mxArray *c15_lhs3 = NULL;
  const mxArray *c15_rhs4 = NULL;
  const mxArray *c15_lhs4 = NULL;
  const mxArray *c15_rhs5 = NULL;
  const mxArray *c15_lhs5 = NULL;
  const mxArray *c15_rhs6 = NULL;
  const mxArray *c15_lhs6 = NULL;
  const mxArray *c15_rhs7 = NULL;
  const mxArray *c15_lhs7 = NULL;
  const mxArray *c15_rhs8 = NULL;
  const mxArray *c15_lhs8 = NULL;
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(""), "context", "context", 0);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("mod"), "name", "name", 0);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 0);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m"), "resolved",
                  "resolved", 0);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1363713854U), "fileTimeLo",
                  "fileTimeLo", 0);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 0);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 0);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 0);
  sf_mex_assign(&c15_rhs0, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs0, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs0), "rhs", "rhs",
                  0);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs0), "lhs", "lhs",
                  0);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m"), "context",
                  "context", 1);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 1);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 1);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 1);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 1);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 1);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 1);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 1);
  sf_mex_assign(&c15_rhs1, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs1, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs1), "rhs", "rhs",
                  1);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs1), "lhs", "lhs",
                  1);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m"), "context",
                  "context", 2);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 2);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 2);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 2);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 2);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 2);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 2);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 2);
  sf_mex_assign(&c15_rhs2, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs2, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs2), "rhs", "rhs",
                  2);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs2), "lhs", "lhs",
                  2);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m"), "context",
                  "context", 3);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("coder.internal.assert"),
                  "name", "name", 3);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 3);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/assert.m"),
                  "resolved", "resolved", 3);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 3);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 3);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 3);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 3);
  sf_mex_assign(&c15_rhs3, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs3, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs3), "rhs", "rhs",
                  3);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs3), "lhs", "lhs",
                  3);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m"), "context",
                  "context", 4);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 4);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 4);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 4);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 4);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 4);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 4);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 4);
  sf_mex_assign(&c15_rhs4, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs4, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs4), "rhs", "rhs",
                  4);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs4), "lhs", "lhs",
                  4);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "context",
                  "context", 5);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("coder.internal.scalarEg"),
                  "name", "name", 5);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 5);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/scalarEg.p"),
                  "resolved", "resolved", 5);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1389307920U), "fileTimeLo",
                  "fileTimeLo", 5);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 5);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 5);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 5);
  sf_mex_assign(&c15_rhs5, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs5, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs5), "rhs", "rhs",
                  5);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs5), "lhs", "lhs",
                  5);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m"), "context",
                  "context", 6);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("eml_scalexp_alloc"), "name",
                  "name", 6);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 6);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m"),
                  "resolved", "resolved", 6);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 6);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 6);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 6);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 6);
  sf_mex_assign(&c15_rhs6, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs6, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs6), "rhs", "rhs",
                  6);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs6), "lhs", "lhs",
                  6);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m"),
                  "context", "context", 7);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("coder.internal.scalexpAlloc"),
                  "name", "name", 7);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 7);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/scalexpAlloc.p"),
                  "resolved", "resolved", 7);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1389307920U), "fileTimeLo",
                  "fileTimeLo", 7);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 7);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 7);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 7);
  sf_mex_assign(&c15_rhs7, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs7, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs7), "rhs", "rhs",
                  7);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs7), "lhs", "lhs",
                  7);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!intmod"), "context",
                  "context", 8);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 8);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut("uint8"), "dominantType",
                  "dominantType", 8);
  sf_mex_addfield(*c15_info, c15_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 8);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 8);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 8);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 8);
  sf_mex_addfield(*c15_info, c15_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 8);
  sf_mex_assign(&c15_rhs8, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c15_lhs8, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_rhs8), "rhs", "rhs",
                  8);
  sf_mex_addfield(*c15_info, sf_mex_duplicatearraysafe(&c15_lhs8), "lhs", "lhs",
                  8);
  sf_mex_destroy(&c15_rhs0);
  sf_mex_destroy(&c15_lhs0);
  sf_mex_destroy(&c15_rhs1);
  sf_mex_destroy(&c15_lhs1);
  sf_mex_destroy(&c15_rhs2);
  sf_mex_destroy(&c15_lhs2);
  sf_mex_destroy(&c15_rhs3);
  sf_mex_destroy(&c15_lhs3);
  sf_mex_destroy(&c15_rhs4);
  sf_mex_destroy(&c15_lhs4);
  sf_mex_destroy(&c15_rhs5);
  sf_mex_destroy(&c15_lhs5);
  sf_mex_destroy(&c15_rhs6);
  sf_mex_destroy(&c15_lhs6);
  sf_mex_destroy(&c15_rhs7);
  sf_mex_destroy(&c15_lhs7);
  sf_mex_destroy(&c15_rhs8);
  sf_mex_destroy(&c15_lhs8);
}

static const mxArray *c15_emlrt_marshallOut(const char * c15_u)
{
  const mxArray *c15_y = NULL;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", c15_u, 15, 0U, 0U, 0U, 2, 1, strlen
    (c15_u)), false);
  return c15_y;
}

static const mxArray *c15_b_emlrt_marshallOut(const uint32_T c15_u)
{
  const mxArray *c15_y = NULL;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 7, 0U, 0U, 0U, 0), false);
  return c15_y;
}

static void c15_Wegpunktliste_erstellen(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, uint8_T c15_Auftragsnummer, uint8_T c15_Is_Endstation, real_T
  c15_Wegpunktliste[200])
{
  uint32_T c15_debug_family_var_map[15];
  real_T c15_offset_Station;
  real_T c15_links_rechts;
  uint8_T c15_hinten_vorne;
  real_T c15_Platz_1[12];
  real_T c15_Platz_2[12];
  real_T c15_Platz_3[12];
  real_T c15_Platz_4[12];
  real_T c15_RFID_L[12];
  real_T c15_RFID_R[12];
  real_T c15_Anz_WP;
  real_T c15_nargin = 2.0;
  real_T c15_nargout = 1.0;
  int32_T c15_i37;
  int32_T c15_i38;
  uint8_T c15_x;
  uint8_T c15_b_x;
  uint8_T c15_t;
  int32_T c15_i39;
  static real_T c15_dv6[12] = { 1.0, 11.0, 111.0, 1.0, 11.0, 111.0, 1.0, 11.0,
    111.0, 1.0, 11.0, 111.0 };

  int32_T c15_i40;
  static real_T c15_dv7[12] = { 2.0, 22.0, 222.0, 2.0, 22.0, 222.0, 2.0, 22.0,
    222.0, 2.0, 22.0, 222.0 };

  int32_T c15_i41;
  static real_T c15_dv8[12] = { 3.0, 33.0, 333.0, 3.0, 33.0, 333.0, 3.0, 33.0,
    333.0, 3.0, 33.0, 333.0 };

  int32_T c15_i42;
  static real_T c15_dv9[12] = { 4.0, 44.0, 444.0, 4.0, 44.0, 444.0, 4.0, 44.0,
    444.0, 4.0, 44.0, 444.0 };

  int32_T c15_i43;
  static real_T c15_dv10[12] = { 5.0, 55.0, 555.0, 5.0, 55.0, 555.0, 5.0, 55.0,
    555.0, 5.0, 55.0, 555.0 };

  int32_T c15_i44;
  static real_T c15_dv11[12] = { 6.0, 66.0, 666.0, 6.0, 66.0, 666.0, 6.0, 66.0,
    666.0, 6.0, 66.0, 666.0 };

  int32_T c15_i45;
  int32_T c15_i46;
  int32_T c15_i47;
  int32_T c15_i48;
  int32_T c15_i49;
  int32_T c15_i50;
  int32_T c15_i51;
  int32_T c15_i52;
  int32_T c15_i53;
  int32_T c15_i54;
  int32_T c15_i55;
  int32_T c15_i56;
  int32_T c15_i57;
  int32_T c15_i58;
  int32_T c15_i59;
  int32_T c15_i60;
  int32_T c15_i61;
  int32_T c15_i62;
  int32_T c15_i63;
  int32_T c15_i64;
  int32_T c15_i65;
  int32_T c15_i66;
  int32_T c15_i67;
  int32_T c15_i68;
  int32_T c15_i69;
  int32_T c15_i70;
  int32_T c15_i71;
  int32_T c15_i72;
  int32_T c15_i73;
  int32_T c15_i74;
  int32_T c15_i75;
  int32_T c15_i76;
  int32_T c15_i77;
  int32_T c15_i78;
  int32_T c15_i79;
  int32_T c15_i80;
  int32_T c15_i81;
  int32_T c15_i82;
  int32_T c15_i83;
  int32_T c15_i84;
  int32_T c15_i85;
  int32_T c15_i86;
  int32_T c15_i87;
  int32_T c15_i88;
  int32_T c15_i89;
  int32_T c15_i90;
  int32_T c15_i91;
  int32_T c15_i92;
  int32_T c15_i93;
  real_T c15_b_Wegpunktliste[6];
  int32_T c15_i94;
  real_T c15_c_Wegpunktliste[24];
  int32_T c15_i95;
  int32_T c15_i96;
  int32_T c15_i97;
  int32_T c15_i98;
  int32_T c15_i99;
  int32_T c15_i100;
  int32_T c15_i101;
  int32_T c15_i102;
  int32_T c15_i103;
  real_T c15_u[200];
  const mxArray *c15_y = NULL;
  int32_T *c15_sfEvent;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  c15_sfEvent = (int32_T *)ssGetDWork(chartInstance->S, 0);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 15U, 15U, c15_b_debug_family_names,
    c15_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_offset_Station, 0U,
    c15_sf_marshallOut, c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_links_rechts, 1U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_hinten_vorne, 2U,
    c15_c_sf_marshallOut, c15_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_Platz_1, 3U, c15_d_sf_marshallOut,
    c15_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_Platz_2, 4U, c15_d_sf_marshallOut,
    c15_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_Platz_3, 5U, c15_d_sf_marshallOut,
    c15_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_Platz_4, 6U, c15_d_sf_marshallOut,
    c15_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_RFID_L, 7U, c15_d_sf_marshallOut,
    c15_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_RFID_R, 8U, c15_d_sf_marshallOut,
    c15_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c15_Anz_WP, 9U, c15_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargin, 10U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_nargout, 11U, c15_sf_marshallOut,
    c15_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_Auftragsnummer, 12U,
    c15_c_sf_marshallOut, c15_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c15_Is_Endstation, 13U,
    c15_c_sf_marshallOut, c15_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c15_Wegpunktliste, 14U,
    c15_b_sf_marshallOut, c15_b_sf_marshallIn);
  CV_EML_FCN(20, 0);
  _SFD_EML_CALL(20U, *c15_sfEvent, 3);
  for (c15_i37 = 0; c15_i37 < 200; c15_i37++) {
    c15_Wegpunktliste[c15_i37] = 0.0;
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 4);
  for (c15_i38 = 0; c15_i38 < 200; c15_i38++) {
    c15_Wegpunktliste[c15_i38] = -1.0;
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 6);
  switch (c15_Auftragsnummer) {
   case 2U:
   case 1U:
    CV_EML_SWITCH(20, 1, 0, 1);
    _SFD_EML_CALL(20U, *c15_sfEvent, 9);
    c15_offset_Station = 0.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 10);
    c15_links_rechts = 0.0;
    break;

   case 3U:
   case 4U:
    CV_EML_SWITCH(20, 1, 0, 2);
    _SFD_EML_CALL(20U, *c15_sfEvent, 12);
    c15_offset_Station = 0.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 13);
    c15_links_rechts = 1.0;
    break;

   case 5U:
   case 6U:
    CV_EML_SWITCH(20, 1, 0, 3);
    _SFD_EML_CALL(20U, *c15_sfEvent, 15);
    c15_offset_Station = 1200.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 16);
    c15_links_rechts = 0.0;
    break;

   case 7U:
   case 8U:
    CV_EML_SWITCH(20, 1, 0, 4);
    _SFD_EML_CALL(20U, *c15_sfEvent, 18);
    c15_offset_Station = 1200.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 19);
    c15_links_rechts = 1.0;
    break;

   case 9U:
   case 10U:
    CV_EML_SWITCH(20, 1, 0, 5);
    _SFD_EML_CALL(20U, *c15_sfEvent, 21);
    c15_offset_Station = 2400.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 22);
    c15_links_rechts = 0.0;
    break;

   case 11U:
   case 12U:
    CV_EML_SWITCH(20, 1, 0, 6);
    _SFD_EML_CALL(20U, *c15_sfEvent, 24);
    c15_offset_Station = 2400.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 25);
    c15_links_rechts = 1.0;
    break;

   case 13U:
   case 14U:
    CV_EML_SWITCH(20, 1, 0, 7);
    _SFD_EML_CALL(20U, *c15_sfEvent, 27);
    c15_offset_Station = 3600.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 28);
    c15_links_rechts = 0.0;
    break;

   case 15U:
   case 16U:
    CV_EML_SWITCH(20, 1, 0, 8);
    _SFD_EML_CALL(20U, *c15_sfEvent, 30);
    c15_offset_Station = 3600.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 31);
    c15_links_rechts = 1.0;
    break;

   default:
    CV_EML_SWITCH(20, 1, 0, 0);
    _SFD_EML_CALL(20U, *c15_sfEvent, 33);
    c15_offset_Station = -1000.0;
    _SFD_EML_CALL(20U, *c15_sfEvent, 34);
    c15_links_rechts = 0.0;
    break;
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 40);
  c15_x = c15_Auftragsnummer;
  c15_b_x = c15_x;
  c15_t = (uint8_T)(c15_b_x >> 1);
  c15_t <<= 1;
  c15_hinten_vorne = (uint8_T)((uint32_T)c15_b_x - (uint32_T)c15_t);
  _SFD_EML_CALL(20U, *c15_sfEvent, 50);
  for (c15_i39 = 0; c15_i39 < 12; c15_i39++) {
    c15_Platz_1[c15_i39] = c15_dv6[c15_i39];
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 51);
  for (c15_i40 = 0; c15_i40 < 12; c15_i40++) {
    c15_Platz_2[c15_i40] = c15_dv7[c15_i40];
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 52);
  for (c15_i41 = 0; c15_i41 < 12; c15_i41++) {
    c15_Platz_3[c15_i41] = c15_dv8[c15_i41];
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 53);
  for (c15_i42 = 0; c15_i42 < 12; c15_i42++) {
    c15_Platz_4[c15_i42] = c15_dv9[c15_i42];
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 54);
  for (c15_i43 = 0; c15_i43 < 12; c15_i43++) {
    c15_RFID_L[c15_i43] = c15_dv10[c15_i43];
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 55);
  for (c15_i44 = 0; c15_i44 < 12; c15_i44++) {
    c15_RFID_R[c15_i44] = c15_dv11[c15_i44];
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 57);
  c15_Anz_WP = 3.0;
  _SFD_EML_CALL(20U, *c15_sfEvent, 66);
  guard4 = false;
  if (CV_EML_COND(20, 1, 0, c15_links_rechts == 0.0)) {
    if (CV_EML_COND(20, 1, 1, (real_T)c15_Is_Endstation == 1.0)) {
      CV_EML_MCDC(20, 1, 0, true);
      CV_EML_IF(20, 1, 0, true);
      _SFD_EML_CALL(20U, *c15_sfEvent, 68);
      c15_i45 = 0;
      c15_i46 = 0;
      for (c15_i47 = 0; c15_i47 < 4; c15_i47++) {
        for (c15_i48 = 0; c15_i48 < 3; c15_i48++) {
          c15_Wegpunktliste[c15_i48 + c15_i45] = c15_RFID_L[c15_i48 + c15_i46];
        }

        c15_i45 += 50;
        c15_i46 += 3;
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 70);
      if (CV_EML_IF(20, 1, 1, (real_T)c15_hinten_vorne == 1.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 71);
        c15_i49 = 0;
        c15_i50 = 0;
        for (c15_i51 = 0; c15_i51 < 4; c15_i51++) {
          for (c15_i52 = 0; c15_i52 < 3; c15_i52++) {
            c15_Wegpunktliste[(c15_i52 + c15_i49) + 3] = c15_Platz_1[c15_i52 +
              c15_i50];
          }

          c15_i49 += 50;
          c15_i50 += 3;
        }
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 74);
      if (CV_EML_IF(20, 1, 2, (real_T)c15_hinten_vorne == 0.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 75);
        c15_i53 = 0;
        c15_i54 = 0;
        for (c15_i55 = 0; c15_i55 < 4; c15_i55++) {
          for (c15_i56 = 0; c15_i56 < 3; c15_i56++) {
            c15_Wegpunktliste[(c15_i56 + c15_i53) + 3] = c15_Platz_2[c15_i56 +
              c15_i54];
          }

          c15_i53 += 50;
          c15_i54 += 3;
        }
      }
    } else {
      guard4 = true;
    }
  } else {
    guard4 = true;
  }

  if (guard4 == true) {
    CV_EML_MCDC(20, 1, 0, false);
    CV_EML_IF(20, 1, 0, false);
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 82);
  guard3 = false;
  if (CV_EML_COND(20, 1, 2, c15_links_rechts == 1.0)) {
    if (CV_EML_COND(20, 1, 3, (real_T)c15_Is_Endstation == 1.0)) {
      CV_EML_MCDC(20, 1, 1, true);
      CV_EML_IF(20, 1, 3, true);
      _SFD_EML_CALL(20U, *c15_sfEvent, 84);
      c15_i57 = 0;
      c15_i58 = 0;
      for (c15_i59 = 0; c15_i59 < 4; c15_i59++) {
        for (c15_i60 = 0; c15_i60 < 3; c15_i60++) {
          c15_Wegpunktliste[c15_i60 + c15_i57] = c15_RFID_R[c15_i60 + c15_i58];
        }

        c15_i57 += 50;
        c15_i58 += 3;
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 86);
      if (CV_EML_IF(20, 1, 4, (real_T)c15_hinten_vorne == 1.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 87);
        c15_i61 = 0;
        c15_i62 = 0;
        for (c15_i63 = 0; c15_i63 < 4; c15_i63++) {
          for (c15_i64 = 0; c15_i64 < 3; c15_i64++) {
            c15_Wegpunktliste[(c15_i64 + c15_i61) + 3] = c15_Platz_3[c15_i64 +
              c15_i62];
          }

          c15_i61 += 50;
          c15_i62 += 3;
        }
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 90);
      if (CV_EML_IF(20, 1, 5, (real_T)c15_hinten_vorne == 0.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 91);
        c15_i65 = 0;
        c15_i66 = 0;
        for (c15_i67 = 0; c15_i67 < 4; c15_i67++) {
          for (c15_i68 = 0; c15_i68 < 3; c15_i68++) {
            c15_Wegpunktliste[(c15_i68 + c15_i65) + 3] = c15_Platz_4[c15_i68 +
              c15_i66];
          }

          c15_i65 += 50;
          c15_i66 += 3;
        }
      }
    } else {
      guard3 = true;
    }
  } else {
    guard3 = true;
  }

  if (guard3 == true) {
    CV_EML_MCDC(20, 1, 1, false);
    CV_EML_IF(20, 1, 3, false);
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 99);
  guard2 = false;
  if (CV_EML_COND(20, 1, 4, c15_links_rechts == 0.0)) {
    if (CV_EML_COND(20, 1, 5, (real_T)c15_Is_Endstation == 0.0)) {
      CV_EML_MCDC(20, 1, 2, true);
      CV_EML_IF(20, 1, 6, true);
      _SFD_EML_CALL(20U, *c15_sfEvent, 102);
      if (CV_EML_IF(20, 1, 7, (real_T)c15_hinten_vorne == 1.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 103);
        c15_i69 = 0;
        c15_i70 = 0;
        for (c15_i71 = 0; c15_i71 < 4; c15_i71++) {
          for (c15_i72 = 0; c15_i72 < 3; c15_i72++) {
            c15_Wegpunktliste[c15_i72 + c15_i69] = c15_Platz_1[c15_i72 + c15_i70];
          }

          c15_i69 += 50;
          c15_i70 += 3;
        }
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 106);
      if (CV_EML_IF(20, 1, 8, (real_T)c15_hinten_vorne == 0.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 107);
        c15_i73 = 0;
        c15_i74 = 0;
        for (c15_i75 = 0; c15_i75 < 4; c15_i75++) {
          for (c15_i76 = 0; c15_i76 < 3; c15_i76++) {
            c15_Wegpunktliste[c15_i76 + c15_i73] = c15_Platz_2[c15_i76 + c15_i74];
          }

          c15_i73 += 50;
          c15_i74 += 3;
        }
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 112);
      c15_i77 = 0;
      c15_i78 = 0;
      for (c15_i79 = 0; c15_i79 < 4; c15_i79++) {
        for (c15_i80 = 0; c15_i80 < 3; c15_i80++) {
          c15_Wegpunktliste[(c15_i80 + c15_i77) + 3] = c15_RFID_L[c15_i80 +
            c15_i78];
        }

        c15_i77 += 50;
        c15_i78 += 3;
      }
    } else {
      guard2 = true;
    }
  } else {
    guard2 = true;
  }

  if (guard2 == true) {
    CV_EML_MCDC(20, 1, 2, false);
    CV_EML_IF(20, 1, 6, false);
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 116);
  guard1 = false;
  if (CV_EML_COND(20, 1, 6, c15_links_rechts == 1.0)) {
    if (CV_EML_COND(20, 1, 7, (real_T)c15_Is_Endstation == 0.0)) {
      CV_EML_MCDC(20, 1, 3, true);
      CV_EML_IF(20, 1, 9, true);
      _SFD_EML_CALL(20U, *c15_sfEvent, 119);
      if (CV_EML_IF(20, 1, 10, (real_T)c15_hinten_vorne == 1.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 120);
        c15_i81 = 0;
        c15_i82 = 0;
        for (c15_i83 = 0; c15_i83 < 4; c15_i83++) {
          for (c15_i84 = 0; c15_i84 < 3; c15_i84++) {
            c15_Wegpunktliste[c15_i84 + c15_i81] = c15_Platz_3[c15_i84 + c15_i82];
          }

          c15_i81 += 50;
          c15_i82 += 3;
        }
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 123);
      if (CV_EML_IF(20, 1, 11, (real_T)c15_hinten_vorne == 0.0)) {
        _SFD_EML_CALL(20U, *c15_sfEvent, 124);
        c15_i85 = 0;
        c15_i86 = 0;
        for (c15_i87 = 0; c15_i87 < 4; c15_i87++) {
          for (c15_i88 = 0; c15_i88 < 3; c15_i88++) {
            c15_Wegpunktliste[c15_i88 + c15_i85] = c15_Platz_4[c15_i88 + c15_i86];
          }

          c15_i85 += 50;
          c15_i86 += 3;
        }
      }

      _SFD_EML_CALL(20U, *c15_sfEvent, 129U);
      c15_i89 = 0;
      c15_i90 = 0;
      for (c15_i91 = 0; c15_i91 < 4; c15_i91++) {
        for (c15_i92 = 0; c15_i92 < 3; c15_i92++) {
          c15_Wegpunktliste[(c15_i92 + c15_i89) + 3] = c15_RFID_R[c15_i92 +
            c15_i90];
        }

        c15_i89 += 50;
        c15_i90 += 3;
      }
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1 == true) {
    CV_EML_MCDC(20, 1, 3, false);
    CV_EML_IF(20, 1, 9, false);
  }

  _SFD_EML_CALL(20U, *c15_sfEvent, 135U);
  for (c15_i93 = 0; c15_i93 < 6; c15_i93++) {
    c15_b_Wegpunktliste[c15_i93] = c15_Wegpunktliste[c15_i93] +
      c15_offset_Station;
  }

  for (c15_i94 = 0; c15_i94 < 6; c15_i94++) {
    c15_c_Wegpunktliste[c15_i94] = c15_b_Wegpunktliste[c15_i94];
  }

  c15_i95 = 0;
  c15_i96 = 0;
  for (c15_i97 = 0; c15_i97 < 3; c15_i97++) {
    for (c15_i98 = 0; c15_i98 < 6; c15_i98++) {
      c15_c_Wegpunktliste[(c15_i98 + c15_i95) + 6] = c15_Wegpunktliste[(c15_i98
        + c15_i96) + 50];
    }

    c15_i95 += 6;
    c15_i96 += 50;
  }

  c15_i99 = 0;
  c15_i100 = 0;
  for (c15_i101 = 0; c15_i101 < 4; c15_i101++) {
    for (c15_i102 = 0; c15_i102 < 6; c15_i102++) {
      c15_Wegpunktliste[c15_i102 + c15_i99] = c15_c_Wegpunktliste[c15_i102 +
        c15_i100];
    }

    c15_i99 += 50;
    c15_i100 += 6;
  }

  sf_mex_printf("%s =\\n", "Wegpunktliste");
  for (c15_i103 = 0; c15_i103 < 200; c15_i103++) {
    c15_u[c15_i103] = c15_Wegpunktliste[c15_i103];
  }

  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", c15_u, 0, 0U, 1U, 0U, 2, 50, 4),
                false);
  sf_mex_call_debug(sfGlobalDebugInstanceStruct, "disp", 0U, 1U, 14, c15_y);
  _SFD_EML_CALL(20U, *c15_sfEvent, -135);
  _SFD_SYMBOL_SCOPE_POP();
}

static const mxArray *c15_f_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  int32_T c15_u;
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  c15_u = *(int32_T *)c15_inData;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", &c15_u, 6, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static int32_T c15_i_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId)
{
  int32_T c15_y;
  int32_T c15_i104;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), &c15_i104, 1, 6, 0U, 0, 0U, 0);
  c15_y = c15_i104;
  sf_mex_destroy(&c15_u);
  return c15_y;
}

static void c15_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_sfEvent;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  int32_T c15_y;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_sfEvent = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_y = c15_i_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_sfEvent),
    &c15_thisId);
  sf_mex_destroy(&c15_sfEvent);
  *(int32_T *)c15_outData = c15_y;
  sf_mex_destroy(&c15_mxArrayInData);
}

static const mxArray *c15_g_sf_marshallOut(void *chartInstanceVoid, void
  *c15_inData)
{
  const mxArray *c15_mxArrayOutData = NULL;
  int32_T c15_i105;
  real_T c15_b_inData[200];
  int32_T c15_i106;
  real_T c15_u[200];
  const mxArray *c15_y = NULL;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_mxArrayOutData = NULL;
  for (c15_i105 = 0; c15_i105 < 200; c15_i105++) {
    c15_b_inData[c15_i105] = (*(real_T (*)[200])c15_inData)[c15_i105];
  }

  for (c15_i106 = 0; c15_i106 < 200; c15_i106++) {
    c15_u[c15_i106] = c15_b_inData[c15_i106];
  }

  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_create("y", c15_u, 0, 0U, 1U, 0U, 1, 200), false);
  sf_mex_assign(&c15_mxArrayOutData, c15_y, false);
  return c15_mxArrayOutData;
}

static void c15_j_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_A_stern_test, const char_T *c15_identifier,
  real_T c15_y[200])
{
  emlrtMsgIdentifier c15_thisId;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_k_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_A_stern_test),
    &c15_thisId, c15_y);
  sf_mex_destroy(&c15_A_stern_test);
}

static void c15_k_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId,
  real_T c15_y[200])
{
  real_T c15_dv12[200];
  int32_T c15_i107;
  (void)chartInstance;
  sf_mex_import(c15_parentId, sf_mex_dup(c15_u), c15_dv12, 1, 0, 0U, 1, 0U, 1,
                200);
  for (c15_i107 = 0; c15_i107 < 200; c15_i107++) {
    c15_y[c15_i107] = c15_dv12[c15_i107];
  }

  sf_mex_destroy(&c15_u);
}

static void c15_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c15_mxArrayInData, const char_T *c15_varName, void *c15_outData)
{
  const mxArray *c15_A_stern_test;
  const char_T *c15_identifier;
  emlrtMsgIdentifier c15_thisId;
  real_T c15_y[200];
  int32_T c15_i108;
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)chartInstanceVoid;
  c15_A_stern_test = sf_mex_dup(c15_mxArrayInData);
  c15_identifier = c15_varName;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  c15_k_emlrt_marshallIn(chartInstance, sf_mex_dup(c15_A_stern_test),
    &c15_thisId, c15_y);
  sf_mex_destroy(&c15_A_stern_test);
  for (c15_i108 = 0; c15_i108 < 200; c15_i108++) {
    (*(real_T (*)[200])c15_outData)[c15_i108] = c15_y[c15_i108];
  }

  sf_mex_destroy(&c15_mxArrayInData);
}

static const mxArray *c15_l_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance, const mxArray *c15_b_setSimStateSideEffectsInfo, const char_T
  *c15_identifier)
{
  const mxArray *c15_y = NULL;
  emlrtMsgIdentifier c15_thisId;
  c15_y = NULL;
  c15_thisId.fIdentifier = c15_identifier;
  c15_thisId.fParent = NULL;
  sf_mex_assign(&c15_y, c15_m_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c15_b_setSimStateSideEffectsInfo), &c15_thisId), false);
  sf_mex_destroy(&c15_b_setSimStateSideEffectsInfo);
  return c15_y;
}

static const mxArray *c15_m_emlrt_marshallIn(SFc15_KitGewerk2_v14InstanceStruct *
  chartInstance, const mxArray *c15_u, const emlrtMsgIdentifier *c15_parentId)
{
  const mxArray *c15_y = NULL;
  (void)chartInstance;
  (void)c15_parentId;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_duplicatearraysafe(&c15_u), false);
  sf_mex_destroy(&c15_u);
  return c15_y;
}

static void c15_updateDataWrittenToVector(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, uint32_T c15_vectorIndex)
{
  (void)chartInstance;
  c15_dataWrittenToVector[(uint32_T)_SFD_EML_ARRAY_BOUNDS_CHECK(0, (int32_T)
    c15_vectorIndex, 0, 13, 1, 0)] = true;
}

static void c15_errorIfDataNotWrittenToFcn(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance, uint32_T c15_vectorIndex, uint32_T c15_dataNumber)
{
  (void)chartInstance;
  _SFD_DATA_READ_BEFORE_WRITE_CHECK(c15_dataNumber, c15_dataWrittenToVector
    [(uint32_T)_SFD_EML_ARRAY_BOUNDS_CHECK(0, (int32_T)c15_vectorIndex, 0, 13, 1,
    0)]);
}

static void init_dsm_address_info(SFc15_KitGewerk2_v14InstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

static uint32_T* sf_get_sfun_dwork_checksum();
void sf_c15_KitGewerk2_v14_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3906688200U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3507529375U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4137675925U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3849857322U);
}

mxArray *sf_c15_KitGewerk2_v14_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("Zgu3OQsNJhjR00TT3n2NSF");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,9,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,8,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,8,"type",mxType);
    }

    mxSetField(mxData,8,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,7,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(50);
      pr[1] = (double)(4);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(200);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,4,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxData);
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c15_KitGewerk2_v14_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c15_KitGewerk2_v14_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c15_KitGewerk2_v14(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x10'type','srcId','name','auxInfo'{{M[1],M[95],T\"A_WPL\",},{M[1],M[348],T\"A_stern_test\",},{M[1],M[107],T\"B_Greifer\",},{M[1],M[104],T\"B_Stop\",},{M[1],M[119],T\"B_WPL_cnt_reset\",},{M[1],M[106],T\"B_WP_weiter\",},{M[1],M[127],T\"UI_to_GW1\",},{M[3],M[89],T\"B_Endst\",},{M[3],M[90],T\"UI_Auftrnr\",},{M[3],M[220],T\"UI_Endstation\",}}",
    "100 S1x9'type','srcId','name','auxInfo'{{M[3],M[219],T\"UI_Startstation\",},{M[8],M[0],T\"is_active_c15_KitGewerk2_v14\",},{M[9],M[0],T\"is_c15_KitGewerk2_v14\",},{M[9],M[150],T\"is_Werkstueck_ablegen\",},{M[9],M[184],T\"is_Werkstueck_aufnehmen\",},{M[9],M[187],T\"is_Routinen_Stationen\",},{M[9],M[190],T\"is_Routinen_Ladestationen\",},{M[9],M[207],T\"is_A_stern_fahrt\",},{M[11],M[0],T\"temporalCounter_i1\",S'et','os','ct'{{T\"at\",M1x2[97 110],M[1]}}}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 19, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c15_KitGewerk2_v14_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
    chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)
      chartInfo->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _KitGewerk2_v14MachineNumber_,
           15,
           42,
           43,
           0,
           26,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           (void *)S);

        /* Each instance must initialize ist own list of scripts */
        init_script_number_translation(_KitGewerk2_v14MachineNumber_,
          chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,_KitGewerk2_v14MachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _KitGewerk2_v14MachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,0,0,0,"B_Endst");
          _SFD_SET_DATA_PROPS(1,0,0,0,"UI_Auftrnr");
          _SFD_SET_DATA_PROPS(2,2,0,1,"A_WPL");
          _SFD_SET_DATA_PROPS(3,1,1,0,"B_Schieber");
          _SFD_SET_DATA_PROPS(4,1,1,0,"UI_from_GW1");
          _SFD_SET_DATA_PROPS(5,2,0,1,"B_Stop");
          _SFD_SET_DATA_PROPS(6,2,0,1,"B_WP_weiter");
          _SFD_SET_DATA_PROPS(7,2,0,1,"B_Greifer");
          _SFD_SET_DATA_PROPS(8,1,1,0,"B_Lichtschranke");
          _SFD_SET_DATA_PROPS(9,2,0,1,"B_WPL_cnt_reset");
          _SFD_SET_DATA_PROPS(10,2,0,1,"UI_to_GW1");
          _SFD_SET_DATA_PROPS(11,1,1,0,"B_last_WP");
          _SFD_SET_DATA_PROPS(12,0,0,0,"UI_Startstation");
          _SFD_SET_DATA_PROPS(13,0,0,0,"UI_Endstation");
          _SFD_SET_DATA_PROPS(14,1,1,0,"B_da");
          _SFD_SET_DATA_PROPS(15,1,1,0,"UI_Robi_ID");
          _SFD_SET_DATA_PROPS(16,1,1,0,"WP_cnt");
          _SFD_SET_DATA_PROPS(17,1,1,0,"UI_Endstation_in");
          _SFD_SET_DATA_PROPS(18,1,1,0,"UI_Startstation_in");
          _SFD_SET_DATA_PROPS(19,2,0,1,"A_stern_test");
          _SFD_SET_DATA_PROPS(20,8,0,0,"");
          _SFD_SET_DATA_PROPS(21,8,0,0,"");
          _SFD_SET_DATA_PROPS(22,9,0,0,"");
          _SFD_SET_DATA_PROPS(23,9,0,0,"");
          _SFD_SET_DATA_PROPS(24,8,0,0,"");
          _SFD_SET_DATA_PROPS(25,9,0,0,"");
          _SFD_STATE_INFO(0,0,0);
          _SFD_STATE_INFO(1,0,0);
          _SFD_STATE_INFO(2,0,0);
          _SFD_STATE_INFO(3,0,0);
          _SFD_STATE_INFO(4,0,0);
          _SFD_STATE_INFO(5,0,0);
          _SFD_STATE_INFO(6,0,0);
          _SFD_STATE_INFO(7,0,0);
          _SFD_STATE_INFO(9,0,0);
          _SFD_STATE_INFO(10,0,0);
          _SFD_STATE_INFO(11,0,0);
          _SFD_STATE_INFO(12,0,0);
          _SFD_STATE_INFO(13,0,0);
          _SFD_STATE_INFO(14,0,0);
          _SFD_STATE_INFO(15,0,0);
          _SFD_STATE_INFO(16,0,0);
          _SFD_STATE_INFO(17,0,0);
          _SFD_STATE_INFO(18,0,0);
          _SFD_STATE_INFO(19,0,0);
          _SFD_STATE_INFO(21,0,0);
          _SFD_STATE_INFO(22,0,0);
          _SFD_STATE_INFO(23,0,0);
          _SFD_STATE_INFO(24,0,0);
          _SFD_STATE_INFO(25,0,0);
          _SFD_STATE_INFO(26,0,0);
          _SFD_STATE_INFO(27,0,0);
          _SFD_STATE_INFO(28,0,0);
          _SFD_STATE_INFO(29,0,0);
          _SFD_STATE_INFO(30,0,0);
          _SFD_STATE_INFO(31,0,0);
          _SFD_STATE_INFO(32,0,0);
          _SFD_STATE_INFO(33,0,0);
          _SFD_STATE_INFO(34,0,0);
          _SFD_STATE_INFO(35,0,0);
          _SFD_STATE_INFO(36,0,0);
          _SFD_STATE_INFO(38,0,0);
          _SFD_STATE_INFO(39,0,0);
          _SFD_STATE_INFO(40,0,0);
          _SFD_STATE_INFO(41,0,0);
          _SFD_STATE_INFO(8,0,2);
          _SFD_STATE_INFO(20,0,2);
          _SFD_STATE_INFO(37,0,2);
          _SFD_CH_SUBSTATE_COUNT(15);
          _SFD_CH_SUBSTATE_DECOMP(0);
          _SFD_CH_SUBSTATE_INDEX(0,0);
          _SFD_CH_SUBSTATE_INDEX(1,3);
          _SFD_CH_SUBSTATE_INDEX(2,4);
          _SFD_CH_SUBSTATE_INDEX(3,5);
          _SFD_CH_SUBSTATE_INDEX(4,6);
          _SFD_CH_SUBSTATE_INDEX(5,7);
          _SFD_CH_SUBSTATE_INDEX(6,9);
          _SFD_CH_SUBSTATE_INDEX(7,10);
          _SFD_CH_SUBSTATE_INDEX(8,11);
          _SFD_CH_SUBSTATE_INDEX(9,18);
          _SFD_CH_SUBSTATE_INDEX(10,36);
          _SFD_CH_SUBSTATE_INDEX(11,38);
          _SFD_CH_SUBSTATE_INDEX(12,39);
          _SFD_CH_SUBSTATE_INDEX(13,40);
          _SFD_CH_SUBSTATE_INDEX(14,41);
          _SFD_ST_SUBSTATE_COUNT(0,2);
          _SFD_ST_SUBSTATE_INDEX(0,0,1);
          _SFD_ST_SUBSTATE_INDEX(0,1,2);
          _SFD_ST_SUBSTATE_COUNT(1,0);
          _SFD_ST_SUBSTATE_COUNT(2,0);
          _SFD_ST_SUBSTATE_COUNT(3,0);
          _SFD_ST_SUBSTATE_COUNT(4,0);
          _SFD_ST_SUBSTATE_COUNT(5,0);
          _SFD_ST_SUBSTATE_COUNT(6,0);
          _SFD_ST_SUBSTATE_COUNT(7,0);
          _SFD_ST_SUBSTATE_COUNT(9,0);
          _SFD_ST_SUBSTATE_COUNT(10,0);
          _SFD_ST_SUBSTATE_COUNT(11,6);
          _SFD_ST_SUBSTATE_INDEX(11,0,12);
          _SFD_ST_SUBSTATE_INDEX(11,1,13);
          _SFD_ST_SUBSTATE_INDEX(11,2,14);
          _SFD_ST_SUBSTATE_INDEX(11,3,15);
          _SFD_ST_SUBSTATE_INDEX(11,4,16);
          _SFD_ST_SUBSTATE_INDEX(11,5,17);
          _SFD_ST_SUBSTATE_COUNT(12,0);
          _SFD_ST_SUBSTATE_COUNT(13,0);
          _SFD_ST_SUBSTATE_COUNT(14,0);
          _SFD_ST_SUBSTATE_COUNT(15,0);
          _SFD_ST_SUBSTATE_COUNT(16,0);
          _SFD_ST_SUBSTATE_COUNT(17,0);
          _SFD_ST_SUBSTATE_COUNT(18,3);
          _SFD_ST_SUBSTATE_INDEX(18,0,19);
          _SFD_ST_SUBSTATE_INDEX(18,1,21);
          _SFD_ST_SUBSTATE_INDEX(18,2,29);
          _SFD_ST_SUBSTATE_COUNT(19,0);
          _SFD_ST_SUBSTATE_COUNT(21,7);
          _SFD_ST_SUBSTATE_INDEX(21,0,22);
          _SFD_ST_SUBSTATE_INDEX(21,1,23);
          _SFD_ST_SUBSTATE_INDEX(21,2,24);
          _SFD_ST_SUBSTATE_INDEX(21,3,25);
          _SFD_ST_SUBSTATE_INDEX(21,4,26);
          _SFD_ST_SUBSTATE_INDEX(21,5,27);
          _SFD_ST_SUBSTATE_INDEX(21,6,28);
          _SFD_ST_SUBSTATE_COUNT(22,0);
          _SFD_ST_SUBSTATE_COUNT(23,0);
          _SFD_ST_SUBSTATE_COUNT(24,0);
          _SFD_ST_SUBSTATE_COUNT(25,0);
          _SFD_ST_SUBSTATE_COUNT(26,0);
          _SFD_ST_SUBSTATE_COUNT(27,0);
          _SFD_ST_SUBSTATE_COUNT(28,0);
          _SFD_ST_SUBSTATE_COUNT(29,6);
          _SFD_ST_SUBSTATE_INDEX(29,0,30);
          _SFD_ST_SUBSTATE_INDEX(29,1,31);
          _SFD_ST_SUBSTATE_INDEX(29,2,32);
          _SFD_ST_SUBSTATE_INDEX(29,3,33);
          _SFD_ST_SUBSTATE_INDEX(29,4,34);
          _SFD_ST_SUBSTATE_INDEX(29,5,35);
          _SFD_ST_SUBSTATE_COUNT(30,0);
          _SFD_ST_SUBSTATE_COUNT(31,0);
          _SFD_ST_SUBSTATE_COUNT(32,0);
          _SFD_ST_SUBSTATE_COUNT(33,0);
          _SFD_ST_SUBSTATE_COUNT(34,0);
          _SFD_ST_SUBSTATE_COUNT(35,0);
          _SFD_ST_SUBSTATE_COUNT(36,0);
          _SFD_ST_SUBSTATE_COUNT(38,0);
          _SFD_ST_SUBSTATE_COUNT(39,0);
          _SFD_ST_SUBSTATE_COUNT(40,0);
          _SFD_ST_SUBSTATE_COUNT(41,0);
        }

        _SFD_CV_INIT_CHART(15,1,0,0);

        {
          _SFD_CV_INIT_STATE(0,2,1,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(1,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(2,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(3,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(4,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(5,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(6,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(7,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(9,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(10,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(11,6,1,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(12,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(13,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(14,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(15,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(16,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(17,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(18,3,1,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(19,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(21,7,1,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(22,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(23,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(24,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(25,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(26,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(27,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(28,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(29,6,1,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(30,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(31,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(32,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(33,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(34,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(35,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(36,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(38,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(39,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(40,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(41,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(8,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(20,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(37,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(4,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(7,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(8,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(9,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(10,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(3,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(1,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(2,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(5,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(6,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(14,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(37,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(36,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(29,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(25,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(27,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(35,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(28,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(31,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(26,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(23,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(42,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(41,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(15,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(22,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(34,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(39,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(33,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(24,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(16,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(19,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(20,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(18,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(32,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(17,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(40,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(11,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(13,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(38,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(30,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(21,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(12,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(20,1,1,12,0,0,1,0,0,8,4);
        _SFD_CV_INIT_EML_FCN(20,0,"Wegpunktliste_erstellen",0,-1,3196);
        _SFD_CV_INIT_EML_IF(20,1,0,1478,1516,-1,1861);
        _SFD_CV_INIT_EML_IF(20,1,1,1601,1621,-1,1719);
        _SFD_CV_INIT_EML_IF(20,1,2,1729,1749,-1,1848);
        _SFD_CV_INIT_EML_IF(20,1,3,1864,1902,-1,2255);
        _SFD_CV_INIT_EML_IF(20,1,4,1995,2015,-1,2113);
        _SFD_CV_INIT_EML_IF(20,1,5,2123,2143,-1,2242);
        _SFD_CV_INIT_EML_IF(20,1,6,2299,2337,-1,2675);
        _SFD_CV_INIT_EML_IF(20,1,7,2382,2402,-1,2487);
        _SFD_CV_INIT_EML_IF(20,1,8,2497,2517,-1,2603);
        _SFD_CV_INIT_EML_IF(20,1,9,2678,2716,-1,3052);
        _SFD_CV_INIT_EML_IF(20,1,10,2761,2781,-1,2866);
        _SFD_CV_INIT_EML_IF(20,1,11,2876,2896,-1,2982);

        {
          static int caseStart[] = { 747, 199, 309, 368, 430, 492, 555, 619, 683
          };

          static int caseExprEnd[] = { 756, 211, 321, 380, 442, 505, 569, 633,
            697 };

          _SFD_CV_INIT_EML_SWITCH(20,1,0,170,192,817,9,&(caseStart[0]),
            &(caseExprEnd[0]));
        }

        {
          static int condStart[] = { 1481, 1500 };

          static int condEnd[] = { 1496, 1516 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(20,1,0,1481,1516,2,0,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1867, 1886 };

          static int condEnd[] = { 1882, 1902 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(20,1,1,1867,1902,2,2,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2302, 2321 };

          static int condEnd[] = { 2317, 2337 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(20,1,2,2302,2337,2,4,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2681, 2700 };

          static int condEnd[] = { 2696, 2716 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(20,1,3,2681,2716,2,6,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(37,1,1,0,0,0,1,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(37,0,"Wegpunktliste_Wartepl",0,-1,262);

        {
          static int caseStart[] = { 237, 184, 201, 213, 225 };

          static int caseExprEnd[] = { 246, 191, 208, 220, 232 };

          _SFD_CV_INIT_EML_SWITCH(37,1,0,152,174,255,5,&(caseStart[0]),
            &(caseExprEnd[0]));
        }

        _SFD_CV_INIT_EML(19,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(30,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(31,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(35,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(32,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(33,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(24,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(26,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(23,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(25,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(28,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(22,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(38,1,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(38,1,0,23,40,74,113);
        _SFD_CV_INIT_EML(2,1,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(2,1,0,27,44,98,157);
        _SFD_CV_INIT_EML(39,1,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(39,1,0,27,44,78,117);
        _SFD_CV_INIT_EML(7,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(3,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(9,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(4,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(4,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(4,0,0,1,28,1,28);

        {
          static int condStart[] = { 1, 13 };

          static int condEnd[] = { 11, 28 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(4,0,0,1,28,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(7,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(7,0,0,0,15,0,15);
        _SFD_CV_INIT_EML(8,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(8,0,0,1,11,1,11);
        _SFD_CV_INIT_EML(9,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(9,0,0,1,15,1,15);
        _SFD_CV_INIT_EML(10,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(3,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(3,0,0,1,11,1,11);
        _SFD_CV_INIT_EML(0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(0,0,0,1,15,1,15);
        _SFD_CV_INIT_EML(2,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(2,0,0,1,11,1,11);
        _SFD_CV_INIT_EML(5,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(5,0,0,0,15,0,15);
        _SFD_CV_INIT_EML(11,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(11,0,0,1,14,1,14);
        _SFD_CV_INIT_EML(13,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(13,0,0,1,15,1,15);
        _SFD_CV_INIT_EML(37,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(37,0,0,1,9,1,9);
        _SFD_CV_INIT_EML(25,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(25,0,0,1,18,1,18);

        {
          static int condStart[] = { 1, 14 };

          static int condEnd[] = { 10, 18 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(25,0,0,1,18,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(31,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(31,0,0,1,18,1,18);

        {
          static int condStart[] = { 1, 14 };

          static int condEnd[] = { 10, 18 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(31,0,0,1,18,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(38,0,0,1,0,0,0,0,0,4,1);
        _SFD_CV_INIT_EML_IF(38,0,0,1,60,1,48);

        {
          static int condStart[] = { 1, 14, 27, 45 };

          static int condEnd[] = { 10, 18, 41, 59 };

          static int pfixExpr[] = { 0, 1, -3, 2, 3, -2, -3 };

          _SFD_CV_INIT_EML_MCDC(38,0,0,1,60,4,0,&(condStart[0]),&(condEnd[0]),7,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(30,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(30,0,0,1,18,1,18);

        {
          static int condStart[] = { 1, 14 };

          static int condEnd[] = { 10, 18 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(30,0,0,1,18,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(15,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(15,0,0,1,15,1,15);
        _SFD_CV_INIT_EML(34,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(34,0,0,1,54,1,48);

        {
          static int condStart[] = { 1, 33 };

          static int condEnd[] = { 24, 54 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(34,0,0,1,54,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(39,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(39,0,0,1,51,1,48);

        {
          static int condStart[] = { 1, 31 };

          static int condEnd[] = { 23, 51 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(39,0,0,1,51,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(33,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(33,0,0,1,18,1,18);

        {
          static int condStart[] = { 1, 14 };

          static int condEnd[] = { 10, 18 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(33,0,0,1,18,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(16,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(16,0,0,1,33,1,33);

        {
          static int condStart[] = { 1, 19 };

          static int condEnd[] = { 14, 33 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(16,0,0,1,33,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(32,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(32,0,0,1,48,1,48);

        {
          static int condStart[] = { 1, 27 };

          static int condEnd[] = { 24, 48 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(32,0,0,1,48,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(17,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(17,0,0,1,14,1,14);
        _SFD_CV_INIT_EML(40,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(40,0,0,1,51,1,48);

        {
          static int condStart[] = { 1, 31 };

          static int condEnd[] = { 23, 51 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(40,0,0,1,51,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML(12,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(12,0,0,1,18,1,18);

        {
          static int condStart[] = { 1, 14 };

          static int condEnd[] = { 10, 18 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(12,0,0,1,18,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)
          c15_e_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)
          c15_c_sf_marshallIn);

        {
          unsigned int dimVector[2];
          dimVector[0]= 50;
          dimVector[1]= 4;
          _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,2,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c15_b_sf_marshallOut,(MexInFcnForType)
            c15_b_sf_marshallIn);
        }

        _SFD_SET_DATA_COMPILED_PROPS(3,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)
          c15_e_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)
          c15_e_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)
          c15_e_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)
          c15_e_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(10,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)
          c15_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(11,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)
          c15_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)
          c15_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(14,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(15,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(16,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(17,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(18,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c15_c_sf_marshallOut,(MexInFcnForType)NULL);

        {
          unsigned int dimVector[1];
          dimVector[0]= 200;
          _SFD_SET_DATA_COMPILED_PROPS(19,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c15_g_sf_marshallOut,(MexInFcnForType)
            c15_g_sf_marshallIn);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295;
          _SFD_SET_DATA_COMPILED_PROPS(20,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295;
          _SFD_SET_DATA_COMPILED_PROPS(21,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295;
          _SFD_SET_DATA_COMPILED_PROPS(22,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 200;
          _SFD_SET_DATA_COMPILED_PROPS(23,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c15_g_sf_marshallOut,(MexInFcnForType)
            c15_g_sf_marshallIn);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295;
          _SFD_SET_DATA_COMPILED_PROPS(24,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295;
          _SFD_SET_DATA_COMPILED_PROPS(25,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_VALUE_PTR(20,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(21,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(22,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(23,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(24,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(25,(void *)(NULL));

        {
          boolean_T *c15_B_Endst;
          uint8_T *c15_UI_Auftrnr;
          boolean_T *c15_B_Schieber;
          uint8_T *c15_UI_from_GW1;
          boolean_T *c15_B_Stop;
          boolean_T *c15_B_WP_weiter;
          boolean_T *c15_B_Greifer;
          boolean_T *c15_B_Lichtschranke;
          boolean_T *c15_B_WPL_cnt_reset;
          uint8_T *c15_UI_to_GW1;
          boolean_T *c15_B_last_WP;
          uint8_T *c15_UI_Startstation;
          uint8_T *c15_UI_Endstation;
          boolean_T *c15_B_da;
          uint8_T *c15_UI_Robi_ID;
          uint8_T *c15_WP_cnt;
          uint8_T *c15_UI_Endstation_in;
          uint8_T *c15_UI_Startstation_in;
          real_T (*c15_A_WPL)[200];
          real_T (*c15_A_stern_test)[200];
          c15_A_stern_test = (real_T (*)[200])ssGetOutputPortSignal
            (chartInstance->S, 7);
          c15_UI_Startstation_in = (uint8_T *)ssGetInputPortSignal
            (chartInstance->S, 8);
          c15_UI_Endstation_in = (uint8_T *)ssGetInputPortSignal
            (chartInstance->S, 7);
          c15_WP_cnt = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c15_UI_Robi_ID = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c15_B_da = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c15_UI_Endstation = (uint8_T *)ssGetDWork(chartInstance->S, 12);
          c15_UI_Startstation = (uint8_T *)ssGetDWork(chartInstance->S, 11);
          c15_B_last_WP = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c15_UI_to_GW1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 6);
          c15_B_WPL_cnt_reset = (boolean_T *)ssGetOutputPortSignal
            (chartInstance->S, 5);
          c15_B_Lichtschranke = (boolean_T *)ssGetInputPortSignal
            (chartInstance->S, 2);
          c15_B_Greifer = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 4);
          c15_B_WP_weiter = (boolean_T *)ssGetOutputPortSignal(chartInstance->S,
            3);
          c15_B_Stop = (boolean_T *)ssGetOutputPortSignal(chartInstance->S, 2);
          c15_UI_from_GW1 = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c15_B_Schieber = (boolean_T *)ssGetInputPortSignal(chartInstance->S, 0);
          c15_A_WPL = (real_T (*)[200])ssGetOutputPortSignal(chartInstance->S, 1);
          c15_UI_Auftrnr = (uint8_T *)ssGetDWork(chartInstance->S, 10);
          c15_B_Endst = (boolean_T *)ssGetDWork(chartInstance->S, 9);
          _SFD_SET_DATA_VALUE_PTR(0U, c15_B_Endst);
          _SFD_SET_DATA_VALUE_PTR(1U, c15_UI_Auftrnr);
          _SFD_SET_DATA_VALUE_PTR(2U, *c15_A_WPL);
          _SFD_SET_DATA_VALUE_PTR(3U, c15_B_Schieber);
          _SFD_SET_DATA_VALUE_PTR(4U, c15_UI_from_GW1);
          _SFD_SET_DATA_VALUE_PTR(5U, c15_B_Stop);
          _SFD_SET_DATA_VALUE_PTR(6U, c15_B_WP_weiter);
          _SFD_SET_DATA_VALUE_PTR(7U, c15_B_Greifer);
          _SFD_SET_DATA_VALUE_PTR(8U, c15_B_Lichtschranke);
          _SFD_SET_DATA_VALUE_PTR(9U, c15_B_WPL_cnt_reset);
          _SFD_SET_DATA_VALUE_PTR(10U, c15_UI_to_GW1);
          _SFD_SET_DATA_VALUE_PTR(11U, c15_B_last_WP);
          _SFD_SET_DATA_VALUE_PTR(12U, c15_UI_Startstation);
          _SFD_SET_DATA_VALUE_PTR(13U, c15_UI_Endstation);
          _SFD_SET_DATA_VALUE_PTR(14U, c15_B_da);
          _SFD_SET_DATA_VALUE_PTR(15U, c15_UI_Robi_ID);
          _SFD_SET_DATA_VALUE_PTR(16U, c15_WP_cnt);
          _SFD_SET_DATA_VALUE_PTR(17U, c15_UI_Endstation_in);
          _SFD_SET_DATA_VALUE_PTR(18U, c15_UI_Startstation_in);
          _SFD_SET_DATA_VALUE_PTR(19U, *c15_A_stern_test);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _KitGewerk2_v14MachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "mZesZ7SEA9JNCNlTwpK5FB";
}

static void sf_check_dwork_consistency(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    const uint32_T *sfunDWorkChecksum = sf_get_sfun_dwork_checksum();
    mxArray *infoStruct = load_KitGewerk2_v14_optimization_info();
    mxArray* mxRTWDWorkChecksum = sf_get_dwork_info_from_mat_file(S,
      sf_get_instance_specialization(), infoStruct, 15, "dworkChecksum");
    if (mxRTWDWorkChecksum != NULL) {
      double *pr = mxGetPr(mxRTWDWorkChecksum);
      if ((uint32_T)pr[0] != sfunDWorkChecksum[0] ||
          (uint32_T)pr[1] != sfunDWorkChecksum[1] ||
          (uint32_T)pr[2] != sfunDWorkChecksum[2] ||
          (uint32_T)pr[3] != sfunDWorkChecksum[3]) {
        sf_mex_error_message("Code generation and simulation targets registered different sets of persistent variables for the block. "
                             "External or Rapid Accelerator mode simulation requires code generation and simulation targets to "
                             "register the same set of persistent variables for this block. "
                             "This discrepancy is typically caused by MATLAB functions that have different code paths for "
                             "simulation and code generation targets where these code paths define different sets of persistent variables. "
                             "Please identify these code paths in the offending block and rewrite the MATLAB code so that "
                             "the set of persistent variables is the same between simulation and code generation.");
      }
    }
  }
}

static void sf_opaque_initialize_c15_KitGewerk2_v14(void *chartInstanceVar)
{
  sf_check_dwork_consistency(((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar)->S);
  chart_debug_initialization(((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
  initialize_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c15_KitGewerk2_v14(void *chartInstanceVar)
{
  enable_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c15_KitGewerk2_v14(void *chartInstanceVar)
{
  disable_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c15_KitGewerk2_v14(void *chartInstanceVar)
{
  sf_gateway_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_ext_mode_exec_c15_KitGewerk2_v14(void *chartInstanceVar)
{
  ext_mode_exec_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c15_KitGewerk2_v14(SimStruct* S)
{
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
  ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c15_KitGewerk2_v14
    ((SFc15_KitGewerk2_v14InstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c15_KitGewerk2_v14();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c15_KitGewerk2_v14(SimStruct* S, const
  mxArray *st)
{
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
  ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[3];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxDuplicateArray(st);      /* high level simctx */
  prhs[2] = (mxArray*) sf_get_sim_state_info_c15_KitGewerk2_v14();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 3, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c15_KitGewerk2_v14(SimStruct* S)
{
  return sf_internal_get_sim_state_c15_KitGewerk2_v14(S);
}

static void sf_opaque_set_sim_state_c15_KitGewerk2_v14(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c15_KitGewerk2_v14(S, st);
}

static void sf_opaque_terminate_c15_KitGewerk2_v14(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc15_KitGewerk2_v14InstanceStruct*) chartInstanceVar)->S;
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_KitGewerk2_v14_optimization_info();
    }

    finalize_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
      chartInstanceVar);
    utFree((void *)chartInstanceVar);
    if (crtInfo != NULL) {
      utFree((void *)crtInfo);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c15_KitGewerk2_v14(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
    initialize_params_c15_KitGewerk2_v14((SFc15_KitGewerk2_v14InstanceStruct*)
      (chartInfo->chartInstance));
  }
}

mxArray *sf_c15_KitGewerk2_v14_get_testpoint_info(void)
{
  return NULL;
}

static void sf_set_sfun_dwork_info(SimStruct *S)
{
  const char *dworkEncStr[] = {
    "100 S1x10'type','isSigned','wordLength','bias','slope','exponent','isScaledDouble','isComplex','size'{{T\"int32\",,,,,,,M[0],M[]},{T\"boolean\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"boolean\",,,,,,,M[0],M[]}}",
    "100 S1x4'type','isSigned','wordLength','bias','slope','exponent','isScaledDouble','isComplex','size'{{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]},{T\"uint8\",,,,,,,M[0],M[]}}"
  };

  sf_set_encoded_dwork_info(S, dworkEncStr, 14, 10);
}

static uint32_T* sf_get_sfun_dwork_checksum()
{
  static uint32_T checksum[4] = { 733983337U, 2558109115U, 2715862414U,
    1362561685U };

  return checksum;
}

static void mdlSetWorkWidths_c15_KitGewerk2_v14(SimStruct *S)
{
  ssSetModelReferenceSampleTimeDisallowInheritance(S);
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_KitGewerk2_v14_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,
      15);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(sf_get_instance_specialization(),
                infoStruct,15,"RTWCG"));
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,15,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(sf_get_instance_specialization(),infoStruct,15);
    sf_mark_output_events_with_multiple_callers(S,sf_get_instance_specialization
      (),infoStruct,15,1);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 7, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 8, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 9, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,15,9);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,15,7);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=7; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 10; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,15);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
    sf_set_sfun_dwork_info(S);
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(2552558171U));
  ssSetChecksum1(S,(1291250597U));
  ssSetChecksum2(S,(1800574836U));
  ssSetChecksum3(S,(280851766U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c15_KitGewerk2_v14(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c15_KitGewerk2_v14(SimStruct *S)
{
  SFc15_KitGewerk2_v14InstanceStruct *chartInstance;
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)utMalloc(sizeof
    (ChartRunTimeInfo));
  chartInstance = (SFc15_KitGewerk2_v14InstanceStruct *)utMalloc(sizeof
    (SFc15_KitGewerk2_v14InstanceStruct));
  memset(chartInstance, 0, sizeof(SFc15_KitGewerk2_v14InstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c15_KitGewerk2_v14;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c15_KitGewerk2_v14;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c15_KitGewerk2_v14;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c15_KitGewerk2_v14;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c15_KitGewerk2_v14;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c15_KitGewerk2_v14;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c15_KitGewerk2_v14;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c15_KitGewerk2_v14;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c15_KitGewerk2_v14;
  chartInstance->chartInfo.mdlStart = mdlStart_c15_KitGewerk2_v14;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c15_KitGewerk2_v14;
  chartInstance->chartInfo.extModeExec =
    sf_opaque_ext_mode_exec_c15_KitGewerk2_v14;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  crtInfo->instanceInfo = (&(chartInstance->chartInfo));
  crtInfo->isJITEnabled = false;
  ssSetUserData(S,(void *)(crtInfo));  /* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c15_KitGewerk2_v14_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c15_KitGewerk2_v14(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c15_KitGewerk2_v14(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c15_KitGewerk2_v14(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c15_KitGewerk2_v14_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
