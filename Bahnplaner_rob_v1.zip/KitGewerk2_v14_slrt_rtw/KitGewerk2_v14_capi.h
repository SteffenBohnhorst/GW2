/*
 * KitGewerk2_v14_capi.h
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef _RTW_HEADER_KitGewerk2_v14_capi_h_
#define _RTW_HEADER_KitGewerk2_v14_capi_h_
#include "KitGewerk2_v14.h"

extern void KitGewerk2_v14_InitializeDataMapInfo(RT_MODEL_KitGewerk2_v14_T
  *KitGewerk2_v14_M
  );

#endif                                 /* _RTW_HEADER_KitGewerk2_v14_capi_h_ */

/* EOF: KitGewerk2_v14_capi.h */
