/*
 * KitGewerk2_v14.c
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "rt_logging_mmi.h"
#include "KitGewerk2_v14_capi.h"
#include "KitGewerk2_v14.h"
#include "KitGewerk2_v14_private.h"
#include "KitGewerk2_v14_dt.h"

/* Named constants for Chart: '<S5>/Chart' */
#define IN_Wegpunktliste_erstellen_stat ((uint8_T)1U)
#define KitG_IN_Eintrittspunkt_erreicht ((uint8_T)4U)
#define KitGe_IN_Routinen_Ladestationen ((uint8_T)9U)
#define KitGew_IN_Routinen_Warteplaetze ((uint8_T)11U)
#define KitGewe_IN_Fahrt_zum_Warteplatz ((uint8_T)6U)
#define KitGewe_IN_Weiterfahren_zu_RFID ((uint8_T)6U)
#define KitGewe_IN_Werkstueck_aufnehmen ((uint8_T)3U)
#define KitGewer_IN_Kollisionserkennung ((uint8_T)2U)
#define KitGewer_IN_Stationsentscheider ((uint8_T)13U)
#define KitGewer_IN_WP_weiterschalten_3 ((uint8_T)5U)
#define KitGewer_IN_Warten_auf_Ereignis ((uint8_T)5U)
#define KitGewerk2_IN_Auftrag_empfangen ((uint8_T)2U)
#define KitGewerk2_IN_WP_weiterschalten ((uint8_T)6U)
#define KitGewerk2_v14_IN_A_stern      ((uint8_T)1U)
#define KitGewerk2_v14_IN_A_stern_fahrt ((uint8_T)1U)
#define KitGewerk2_v14_IN_Fahrt_zu_RFID ((uint8_T)3U)
#define KitGewerk2_v14_IN_Init         ((uint8_T)7U)
#define KitGewerk2_v14_IN_Laden_beenden ((uint8_T)3U)
#define KitGewerk2_v14_IN_Nav2_abfrage ((uint8_T)8U)
#define KitGewerk2_v14_IN_RFID_lesen   ((uint8_T)5U)
#define KitGewerk2_v14_IN_RFID_lesen_2 ((uint8_T)3U)
#define KitGewerk2_v14_IN_Wegpunkte    ((uint8_T)6U)
#define KitGewerk2_v1_IN_Auftrag_fertig ((uint8_T)1U)
#define KitGewerk2_v1_IN_Fahrt_in_nav_2 ((uint8_T)5U)
#define KitGewerk2_v1_IN_Greifer_schlie ((uint8_T)2U)
#define KitGewerk2_v1_IN_Kontakt_fehler ((uint8_T)2U)
#define KitGewerk2_v1_IN_Laden_beginnen ((uint8_T)4U)
#define KitGewerk2_v1_IN_Routine_fertig ((uint8_T)4U)
#define KitGewerk2_v_IN_Fahrt_zu_Ablage ((uint8_T)2U)
#define KitGewerk2_v_IN_Fahrt_zu_Platz1 ((uint8_T)1U)
#define KitGewerk2_v_IN_Greifer_Oeffnen ((uint8_T)4U)
#define KitGewerk2_v_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define KitGewerk2_v_IN_Station_aendern ((uint8_T)12U)
#define KitGewerk_IN_Auftrag_empfangen1 ((uint8_T)3U)
#define KitGewerk_IN_Fahrt_an_rand_nav1 ((uint8_T)1U)
#define KitGewerk_IN_Routinen_Stationen ((uint8_T)10U)
#define KitGewerk_IN_WP_weiterschalten2 ((uint8_T)7U)
#define KitGewerk_IN_Warten_auf_Auftrag ((uint8_T)14U)
#define KitGewerk_IN_Werkstueck_ablegen ((uint8_T)2U)
#define Kit_IN_Warten_auf_neuen_Auftrag ((uint8_T)15U)

const uint8_T KitGewerk2_v14_U8GND = 0U;/* uint8_T ground */
const uint16_T KitGewerk2_v14_U16GND = 0U;/* uint16_T ground */

/* Block signals (auto storage) */
B_KitGewerk2_v14_T KitGewerk2_v14_B;

/* Block states (auto storage) */
DW_KitGewerk2_v14_T KitGewerk2_v14_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_KitGewerk2_v14_T KitGewerk2_v14_PrevZCX;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_KitGewerk2_v14_T KitGewerk2_v14_Y;

/* Real-time model */
RT_MODEL_KitGewerk2_v14_T KitGewerk2_v14_M_;
RT_MODEL_KitGewerk2_v14_T *const KitGewerk2_v14_M = &KitGewerk2_v14_M_;

/* Forward declaration for local functions */
static void KitGew_Warten_auf_neuen_Auftrag(void);
static void KitGewe_Wegpunktliste_erstellen(uint8_T Auftragsnummer, uint8_T
  Is_Endstation, real_T Wegpunktliste[200]);
static void rate_monotonic_scheduler(void);

/* xPC Target Async Interrupt Block '<S34>/IRQ Source' */
void xPCISR2(void)
{
  {
    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Receive1_SubsysRanBC_o);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Transmit1_SubsysRanBC_k);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Receive2_SubsysRanBC_n);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Transmit2_SubsysRanBC_l);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.RS232ISR_SubsysRanBC_d);

    /* RateTransition: '<S34>/Rate Transition' */
    KitGewerk2_v14_B.RateTransition_g = KitGewerk2_v14_B.FIFOwrite1_o1;

    /* RateTransition: '<S34>/Rate Transition2' */
    KitGewerk2_v14_B.RateTransition2_m = KitGewerk2_v14_B.FIFOwrite2_o1;
    KitGewerk2_v14_RS232ISR();
  }
}

/* xPC Target Async Interrupt Block '<S47>/IRQ Source' */
void xPCISR1(void)
{
  {
    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Receive1_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Transmit1_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Receive2_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.Transmit2_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC(KitGewerk2_v14_DW.RS232ISR_SubsysRanBC);

    /* RateTransition: '<S47>/Rate Transition' */
    KitGewerk2_v14_B.RateTransition = KitGewerk2_v14_B.FIFOwrite1_o1_o;

    /* RateTransition: '<S47>/Rate Transition2' */
    KitGewerk2_v14_B.RateTransition2 = KitGewerk2_v14_B.FIFOwrite2_o1_k;
    KitGewerk2_v14_RS232ISR_i();
  }
}

time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(KitGewerk2_v14_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(KitGewerk2_v14_M, 2);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rate: 2 */
  if (KitGewerk2_v14_M->Timing.TaskCounters.TID[1] == 0) {
    KitGewerk2_v14_M->Timing.RateInteraction.TID1_2 =
      (KitGewerk2_v14_M->Timing.TaskCounters.TID[2] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    KitGewerk2_v14_M->Timing.perTaskSampleHits[5] =
      KitGewerk2_v14_M->Timing.RateInteraction.TID1_2;
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (KitGewerk2_v14_M->Timing.TaskCounters.TID[2])++;
  if ((KitGewerk2_v14_M->Timing.TaskCounters.TID[2]) > 99) {/* Sample time: [0.5s, 0.0s] */
    KitGewerk2_v14_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/* Start for function-call system: '<S34>/RS232 ISR' */
void KitGewerk2_v14_RS232ISR_Start(void)
{
  /* Start for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S36>/Receive 1'
   */
  /* Start for function-call system: '<S36>/Receive 1' */

  /* S-Function Block: <S37>/Read HW FIFO1 (serreadbase) */
  {
    int count = 0;

    // Flush the hardware fifo on startup.
    while (xpcInpB( (unsigned short)(760 + LSR) ) & LSRDR ) {
      // Read and discard the data.
      xpcInpB( (unsigned short)(760 + DATA) );
      if (count++ > 1000 ) {
        static char msg[50];
        sprintf( msg, "A UART at address 0x%x is not responding", 760 );

        // No baseboard UART has that large a hardware fifo!
        rtmSetErrorStatus(KitGewerk2_v14_M, msg);
        return;
      }
    }
  }

  /* Level2 S-Function Block: '<S37>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[9];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S36>/Transmit 1'
   */
  /* Start for function-call system: '<S36>/Transmit 1' */

  /* Start for Constant: '<S39>/Constant1' */
  KitGewerk2_v14_B.Constant1_o = KitGewerk2_v14_P.Constant1_Value_b;

  /* Level2 S-Function Block: '<S39>/FIFO read 1' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[10];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S36>/Receive 2'
   */
  /* Start for function-call system: '<S36>/Receive 2' */

  /* Level2 S-Function Block: '<S38>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[11];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S36>/Transmit 2'
   */
  /* Start for function-call system: '<S36>/Transmit 2' */

  /* Start for Constant: '<S40>/Constant2' */
  KitGewerk2_v14_B.Constant2_k = KitGewerk2_v14_P.Constant2_Value_a;

  /* Level2 S-Function Block: '<S40>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[12];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Output and update for function-call system: '<S34>/RS232 ISR' */
void KitGewerk2_v14_RS232ISR(void)
{
  /* S-Function Block: <S36>/Read Int Status FC1 (iquerybase) */
  {
    int base[2] = { (int)760, (int)0 };

    uint32_T port, max;
    volatile int iir;                  // local interrupt register, per uart
    for (port = 0 ; port < 2 ; port++ ) {
      if (base[port] == 0 ) {
        continue;
      }

      iir = xpcInpB( (unsigned short)(base[port] + IIR) ) & 0xff;

      //printf("lint = 0x%x\n", iir );
      if ((iir & (IIRFEBL | IIR64) ) == (IIRFEBL | IIR64) )
        max = 60;
      else if ((iir & (IIRFEBL | IIR64) ) == IIRFEBL )
        max = 15;
      else
        max = 1;
      *(&KitGewerk2_v14_B.ReadIntStatusFC1_o2_c) = max;
      iir &= IIRREASON;
      while (iir != 1 )                // Service all reasons
      {
        switch ( iir )
        {
         case 1:                       // No interrupt on this UART
          break;

         case 4:                       // received data available
         case 6:                       // receiver line status, overrun etc.
         case 0xc:                     // character timeout
          //printf("%1xa", base[i]>>8);
          // All three are receive interrupts
          switch (port)
          {
           case 0:
            /* Output and update for function-call system: '<S36>/Receive 1' */

            /* S-Function (serreadbase): '<S37>/Read HW FIFO1' */
            {
              /* S-Function Block: <S37>/Read HW FIFO1 (serreadbase) */
              int status = 0;
              int count = 0;

              // While there is data in the fifo, read it, also read error status.
              // Cap the read length to the interrupt point in 64 byte fifo mode.
              while (((status = xpcInpB( (unsigned short)(760 + LSR) ) & 0xff )
                      & LSRDR) && (count < 56) ) {
                int c;
                int masked;
                count++;
                c = xpcInpB( (unsigned short)(760 + DATA) ) & 0xff;// read character
                masked = status & (LSROE | LSRPE | LSRFE | LSRBI);
                ((int_T *)&KitGewerk2_v14_B.ReadHWFIFO1_c[0])[count] = (masked <<
                  8) | c;
              }

              ((int_T *)&KitGewerk2_v14_B.ReadHWFIFO1_c[0])[0] = count;
            }

            /* Level2 S-Function Block: '<S37>/FIFO write 1' (fifowrite) */
            {
              SimStruct *rts = KitGewerk2_v14_M->childSfunctions[9];
              sfcnOutputs(rts, 3);
            }

            KitGewerk2_v14_DW.Receive1_SubsysRanBC_o = 4;
            break;
          }
          break;

         case 2:                       // Transmitter holding register empty
          //printf("%1xb", base[i]>>8);
          switch (port)
          {
           case 0:
            /* Output and update for function-call system: '<S36>/Transmit 1' */

            /* Constant: '<S39>/Constant1' */
            KitGewerk2_v14_B.Constant1_o = KitGewerk2_v14_P.Constant1_Value_b;

            /* Level2 S-Function Block: '<S39>/FIFO read 1' (fiforead) */
            {
              SimStruct *rts = KitGewerk2_v14_M->childSfunctions[10];
              sfcnOutputs(rts, 3);
            }

            /* S-Function (serwritebase): '<S39>/Write HW FIFO1' */
            {
              /* S-Function Block: <S39>/Write HW FIFO1 (serwritebase) */
              int_T *IPtr = (int_T *)&KitGewerk2_v14_B.FIFOread1_o1_a[0];
              if (KitGewerk2_v14_B.FIFOread1_o2_i > 0 ) {
                // On entry, verify that the transmitter holding register is empty
                // so we can stuff all that came from the software fifo into the
                // hardware fifo.  Assume that the software fifo has a max read
                // parameter that fits with the hardware fifo mode setting.
                if (IPtr[0] == 0 ) {
                  // No data, turn off the transmitter empty interrupt and leave
                  int ier = xpcInpB( (unsigned short)(760 + IER) ) & 0xff;
                  xpcOutpB( (unsigned short)(760 + IER), (uint8_T)(ier & ~IERXMT)
                           );
                } else if (xpcInpB( (unsigned short)(760 + LSR) ) & LSRTHRE ) {
                  int i;

                  // Copy all the data from the input vector to the HW fifo.
                  // The fifo read block MUST have the correct max read value
                  // for the fifo mode.
                  for (i = 0 ; i < IPtr[0] ; i++ ) {
                    xpcOutpB( (ushort_T)(760 + DATA), (uint8_T)(IPtr[i+1] & 0xff)
                             );
                  }
                } else {
                  rtmSetErrorStatus(KitGewerk2_v14_M,
                                    "Attempted write to hardware fifo that isn't empty");
                  return;
                }
              }
            }

            KitGewerk2_v14_DW.Transmit1_SubsysRanBC_k = 4;
            break;
          }
          break;

         case 0:
          // Modem status change
          break;
        }

        // Read IIR again to see if we're done with this UART
        iir = xpcInpB( (unsigned short)(base[port] + IIR) ) & IIRREASON;
      }
    }
  }

  KitGewerk2_v14_DW.RS232ISR_SubsysRanBC_d = 4;
}

/* Termination for function-call system: '<S34>/RS232 ISR' */
void KitGewerk2_v14_RS232ISR_Term(void)
{
  /* Terminate for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S36>/Receive 1'
   */
  /* Termination for function-call system: '<S36>/Receive 1' */

  /* Level2 S-Function Block: '<S37>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[9];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S36>/Transmit 1'
   */
  /* Termination for function-call system: '<S36>/Transmit 1' */

  /* Level2 S-Function Block: '<S39>/FIFO read 1' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[10];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S36>/Receive 2'
   */
  /* Termination for function-call system: '<S36>/Receive 2' */

  /* Level2 S-Function Block: '<S38>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[11];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (iquerybase): '<S36>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S36>/Transmit 2'
   */
  /* Termination for function-call system: '<S36>/Transmit 2' */

  /* Level2 S-Function Block: '<S40>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[12];
    sfcnTerminate(rts);
  }
}

/* Start for function-call system: '<S47>/RS232 ISR' */
void KitGewerk2_v14_RS232ISR_f_Start(void)
{
  /* Start for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S51>/Receive 1'
   */
  /* Start for function-call system: '<S51>/Receive 1' */

  /* S-Function Block: <S52>/Read HW FIFO1 (serreadbase) */
  {
    int count = 0;

    // Flush the hardware fifo on startup.
    while (xpcInpB( (unsigned short)(1016 + LSR) ) & LSRDR ) {
      // Read and discard the data.
      xpcInpB( (unsigned short)(1016 + DATA) );
      if (count++ > 1000 ) {
        static char msg[50];
        sprintf( msg, "A UART at address 0x%x is not responding", 1016 );

        // No baseboard UART has that large a hardware fifo!
        rtmSetErrorStatus(KitGewerk2_v14_M, msg);
        return;
      }
    }
  }

  /* Level2 S-Function Block: '<S52>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[13];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S51>/Transmit 1'
   */
  /* Start for function-call system: '<S51>/Transmit 1' */

  /* Start for Constant: '<S54>/Constant1' */
  KitGewerk2_v14_B.Constant1_d = KitGewerk2_v14_P.Constant1_Value_m;

  /* Level2 S-Function Block: '<S54>/FIFO read 1' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[14];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S51>/Receive 2'
   */
  /* Start for function-call system: '<S51>/Receive 2' */

  /* Level2 S-Function Block: '<S53>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[15];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Start for SubSystem: '<S51>/Transmit 2'
   */
  /* Start for function-call system: '<S51>/Transmit 2' */

  /* Start for Constant: '<S55>/Constant2' */
  KitGewerk2_v14_B.Constant2_h = KitGewerk2_v14_P.Constant2_Value_i;

  /* Level2 S-Function Block: '<S55>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[16];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Output and update for function-call system: '<S47>/RS232 ISR' */
void KitGewerk2_v14_RS232ISR_i(void)
{
  /* S-Function Block: <S51>/Read Int Status FC1 (iquerybase) */
  {
    int base[2] = { (int)1016, (int)0 };

    uint32_T port, max;
    volatile int iir;                  // local interrupt register, per uart
    for (port = 0 ; port < 2 ; port++ ) {
      if (base[port] == 0 ) {
        continue;
      }

      iir = xpcInpB( (unsigned short)(base[port] + IIR) ) & 0xff;

      //printf("lint = 0x%x\n", iir );
      if ((iir & (IIRFEBL | IIR64) ) == (IIRFEBL | IIR64) )
        max = 60;
      else if ((iir & (IIRFEBL | IIR64) ) == IIRFEBL )
        max = 15;
      else
        max = 1;
      *(&KitGewerk2_v14_B.ReadIntStatusFC1_o2) = max;
      iir &= IIRREASON;
      while (iir != 1 )                // Service all reasons
      {
        switch ( iir )
        {
         case 1:                       // No interrupt on this UART
          break;

         case 4:                       // received data available
         case 6:                       // receiver line status, overrun etc.
         case 0xc:                     // character timeout
          //printf("%1xa", base[i]>>8);
          // All three are receive interrupts
          switch (port)
          {
           case 0:
            /* Output and update for function-call system: '<S51>/Receive 1' */

            /* S-Function (serreadbase): '<S52>/Read HW FIFO1' */
            {
              /* S-Function Block: <S52>/Read HW FIFO1 (serreadbase) */
              int status = 0;
              int count = 0;

              // While there is data in the fifo, read it, also read error status.
              // Cap the read length to the interrupt point in 64 byte fifo mode.
              while (((status = xpcInpB( (unsigned short)(1016 + LSR) ) & 0xff )
                      & LSRDR) && (count < 56) ) {
                int c;
                int masked;
                count++;
                c = xpcInpB( (unsigned short)(1016 + DATA) ) & 0xff;// read character
                masked = status & (LSROE | LSRPE | LSRFE | LSRBI);
                ((int_T *)&KitGewerk2_v14_B.ReadHWFIFO1[0])[count] = (masked <<
                  8) | c;
              }

              ((int_T *)&KitGewerk2_v14_B.ReadHWFIFO1[0])[0] = count;
            }

            /* Level2 S-Function Block: '<S52>/FIFO write 1' (fifowrite) */
            {
              SimStruct *rts = KitGewerk2_v14_M->childSfunctions[13];
              sfcnOutputs(rts, 4);
            }

            KitGewerk2_v14_DW.Receive1_SubsysRanBC = 4;
            break;
          }
          break;

         case 2:                       // Transmitter holding register empty
          //printf("%1xb", base[i]>>8);
          switch (port)
          {
           case 0:
            /* Output and update for function-call system: '<S51>/Transmit 1' */

            /* Constant: '<S54>/Constant1' */
            KitGewerk2_v14_B.Constant1_d = KitGewerk2_v14_P.Constant1_Value_m;

            /* Level2 S-Function Block: '<S54>/FIFO read 1' (fiforead) */
            {
              SimStruct *rts = KitGewerk2_v14_M->childSfunctions[14];
              sfcnOutputs(rts, 4);
            }

            /* S-Function (serwritebase): '<S54>/Write HW FIFO1' */
            {
              /* S-Function Block: <S54>/Write HW FIFO1 (serwritebase) */
              int_T *IPtr = (int_T *)&KitGewerk2_v14_B.FIFOread1_o1[0];
              if (KitGewerk2_v14_B.FIFOread1_o2 > 0 ) {
                // On entry, verify that the transmitter holding register is empty
                // so we can stuff all that came from the software fifo into the
                // hardware fifo.  Assume that the software fifo has a max read
                // parameter that fits with the hardware fifo mode setting.
                if (IPtr[0] == 0 ) {
                  // No data, turn off the transmitter empty interrupt and leave
                  int ier = xpcInpB( (unsigned short)(1016 + IER) ) & 0xff;
                  xpcOutpB( (unsigned short)(1016 + IER), (uint8_T)(ier &
                            ~IERXMT) );
                } else if (xpcInpB( (unsigned short)(1016 + LSR) ) & LSRTHRE ) {
                  int i;

                  // Copy all the data from the input vector to the HW fifo.
                  // The fifo read block MUST have the correct max read value
                  // for the fifo mode.
                  for (i = 0 ; i < IPtr[0] ; i++ ) {
                    xpcOutpB( (ushort_T)(1016 + DATA), (uint8_T)(IPtr[i+1] &
                              0xff) );
                  }
                } else {
                  rtmSetErrorStatus(KitGewerk2_v14_M,
                                    "Attempted write to hardware fifo that isn't empty");
                  return;
                }
              }
            }

            KitGewerk2_v14_DW.Transmit1_SubsysRanBC = 4;
            break;
          }
          break;

         case 0:
          // Modem status change
          break;
        }

        // Read IIR again to see if we're done with this UART
        iir = xpcInpB( (unsigned short)(base[port] + IIR) ) & IIRREASON;
      }
    }
  }

  KitGewerk2_v14_DW.RS232ISR_SubsysRanBC = 4;
}

/* Termination for function-call system: '<S47>/RS232 ISR' */
void KitGewerk2_v14_RS232ISR_k_Term(void)
{
  /* Terminate for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S51>/Receive 1'
   */
  /* Termination for function-call system: '<S51>/Receive 1' */

  /* Level2 S-Function Block: '<S52>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[13];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S51>/Transmit 1'
   */
  /* Termination for function-call system: '<S51>/Transmit 1' */

  /* Level2 S-Function Block: '<S54>/FIFO read 1' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[14];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S51>/Receive 2'
   */
  /* Termination for function-call system: '<S51>/Receive 2' */

  /* Level2 S-Function Block: '<S53>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[15];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (iquerybase): '<S51>/Read Int Status FC1' incorporates:
   *  Terminate for SubSystem: '<S51>/Transmit 2'
   */
  /* Termination for function-call system: '<S51>/Transmit 2' */

  /* Level2 S-Function Block: '<S55>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[16];
    sfcnTerminate(rts);
  }
}

/* Function for Chart: '<S5>/Chart' */
static void KitGew_Warten_auf_neuen_Auftrag(void)
{
  boolean_T out;

  /* During 'Warten_auf_neuen_Auftrag': '<S17>:202' */
  out = ((KitGewerk2_v14_B.DataTypeConversion3_k == 200) &&
         (KitGewerk2_v14_B.DataTypeConversion1_f == 200));
  if (out) {
    /* Transition: '<S17>:283' */
    KitGewerk2_v14_B.UI_to_GW1 = 200U;
    KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk_IN_Auftrag_empfangen1;
  }
}

/* Function for Chart: '<S5>/Chart' */
static void KitGewe_Wegpunktliste_erstellen(uint8_T Auftragsnummer, uint8_T
  Is_Endstation, real_T Wegpunktliste[200])
{
  int32_T offset_Station;
  int32_T links_rechts;
  uint8_T hinten_vorne;
  static const int16_T RFID_R[12] = { 6, 66, 666, 6, 66, 666, 6, 66, 666, 6, 66,
    666 };

  static const int16_T Platz_4[12] = { 4, 44, 444, 4, 44, 444, 4, 44, 444, 4, 44,
    444 };

  static const int16_T Platz_3[12] = { 3, 33, 333, 3, 33, 333, 3, 33, 333, 3, 33,
    333 };

  static const int16_T RFID_L[12] = { 5, 55, 555, 5, 55, 555, 5, 55, 555, 5, 55,
    555 };

  static const uint8_T Platz_2[12] = { 2U, 22U, 222U, 2U, 22U, 222U, 2U, 22U,
    222U, 2U, 22U, 222U };

  static const int8_T Platz_1[12] = { 1, 11, 111, 1, 11, 111, 1, 11, 111, 1, 11,
    111 };

  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  boolean_T guard5 = false;
  boolean_T guard6 = false;
  boolean_T guard7 = false;
  boolean_T guard8 = false;
  int32_T i;
  int16_T Wegpunktliste_0[24];

  /* MATLAB Function 'Wegpunktliste_erstellen': '<S17>:75' */
  /* '<S17>:75:3' */
  /* Intitialisierung WPL mit 50 Elementen */
  /* '<S17>:75:4' */
  for (i = 0; i < 200; i++) {
    Wegpunktliste[i] = -1.0;
  }

  /* '<S17>:75:6' */
  switch (Auftragsnummer) {
   case 2U:
    guard1 = true;
    break;

   case 1U:
    guard1 = true;
    break;

   case 3U:
    guard2 = true;
    break;

   case 4U:
    guard2 = true;
    break;

   case 5U:
    guard3 = true;
    break;

   case 6U:
    guard3 = true;
    break;

   case 7U:
    guard4 = true;
    break;

   case 8U:
    guard4 = true;
    break;

   case 9U:
    guard5 = true;
    break;

   case 10U:
    guard5 = true;
    break;

   case 11U:
    guard6 = true;
    break;

   case 12U:
    guard6 = true;
    break;

   case 13U:
    guard7 = true;
    break;

   case 14U:
    guard7 = true;
    break;

   case 15U:
    guard8 = true;
    break;

   case 16U:
    guard8 = true;
    break;

   default:
    /* '<S17>:75:33' */
    offset_Station = -1000;

    /* '<S17>:75:34' */
    links_rechts = 0;
    break;
  }

  if (guard8) {
    /* '<S17>:75:30' */
    offset_Station = 3600;

    /* '<S17>:75:31' */
    links_rechts = 1;
  }

  if (guard7) {
    /* '<S17>:75:27' */
    offset_Station = 3600;

    /* '<S17>:75:28' */
    links_rechts = 0;
  }

  if (guard6) {
    /* '<S17>:75:24' */
    offset_Station = 2400;

    /* '<S17>:75:25' */
    links_rechts = 1;
  }

  if (guard5) {
    /* '<S17>:75:21' */
    offset_Station = 2400;

    /* '<S17>:75:22' */
    links_rechts = 0;
  }

  if (guard4) {
    /* '<S17>:75:18' */
    offset_Station = 1200;

    /* '<S17>:75:19' */
    links_rechts = 1;
  }

  if (guard3) {
    /* '<S17>:75:15' */
    offset_Station = 1200;

    /* '<S17>:75:16' */
    links_rechts = 0;
  }

  if (guard2) {
    /* '<S17>:75:12' */
    offset_Station = 0;

    /* '<S17>:75:13' */
    links_rechts = 1;
  }

  if (guard1) {
    /* '<S17>:75:9' */
    offset_Station = 0;

    /* Offset in X-Richtung */
    /* '<S17>:75:10' */
    links_rechts = 0;

    /* 0= links , 1= vorne */
  }

  /* platz vorne(stirnseite)=1, hinten (Platz n�he RFID)=0 */
  /* '<S17>:75:40' */
  hinten_vorne = (uint8_T)((uint32_T)Auftragsnummer - ((Auftragsnummer >> 1) <<
    1));

  /* ***** Statische Listen ***** */
  /* Bezogen auf die Erste Station (Rohteillager) */
  /* Koordinaten f�r Pl�tze */
  /* Alle Pl�tze m�ssen die gleich L�nge haben */
  /* '<S17>:75:50' */
  /* '<S17>:75:51' */
  /* '<S17>:75:52' */
  /* '<S17>:75:53' */
  /* '<S17>:75:54' */
  /* '<S17>:75:55' */
  /* Anzahl Wegpunkt (gleiche Anzahl f�r alle Pl�tze) */
  /* **** Auswahl der Richtigen Wegpunktliste ***** */
  /*  **** Ablegen **** */
  if ((links_rechts == 0) && (Is_Endstation == 1)) {
    /* '<S17>:75:66' */
    /* Werkst�ck ablegen linke Seite */
    /* '<S17>:75:68' */
    for (i = 0; i < 4; i++) {
      Wegpunktliste[50 * i] = RFID_L[3 * i];
      Wegpunktliste[1 + 50 * i] = RFID_L[3 * i + 1];
      Wegpunktliste[2 + 50 * i] = RFID_L[3 * i + 2];
    }

    if (hinten_vorne == 1) {
      /* '<S17>:75:70' */
      /* Wegpunkte f�r Platz 1 zuweisen */
      /* '<S17>:75:71' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[3 + 50 * i] = Platz_1[3 * i];
        Wegpunktliste[4 + 50 * i] = Platz_1[3 * i + 1];
        Wegpunktliste[5 + 50 * i] = Platz_1[3 * i + 2];
      }
    }

    if (hinten_vorne == 0) {
      /* '<S17>:75:74' */
      /*  Wegpunkte f�r Platz 2 zuweisen */
      /* '<S17>:75:75' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[3 + 50 * i] = Platz_2[3 * i];
        Wegpunktliste[4 + 50 * i] = Platz_2[3 * i + 1];
        Wegpunktliste[5 + 50 * i] = Platz_2[3 * i + 2];
      }
    }
  }

  if ((links_rechts == 1) && (Is_Endstation == 1)) {
    /* '<S17>:75:82' */
    /* Werkst�ck ablegen rechte Seite */
    /* '<S17>:75:84' */
    for (i = 0; i < 4; i++) {
      Wegpunktliste[50 * i] = RFID_R[3 * i];
      Wegpunktliste[1 + 50 * i] = RFID_R[3 * i + 1];
      Wegpunktliste[2 + 50 * i] = RFID_R[3 * i + 2];
    }

    if (hinten_vorne == 1) {
      /* '<S17>:75:86' */
      /* Wegpunkte f�r Platz 1 zuweisen */
      /* '<S17>:75:87' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[3 + 50 * i] = Platz_3[3 * i];
        Wegpunktliste[4 + 50 * i] = Platz_3[3 * i + 1];
        Wegpunktliste[5 + 50 * i] = Platz_3[3 * i + 2];
      }
    }

    if (hinten_vorne == 0) {
      /* '<S17>:75:90' */
      /*  Wegpunkte f�r Platz 2 zuweisen */
      /* '<S17>:75:91' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[3 + 50 * i] = Platz_4[3 * i];
        Wegpunktliste[4 + 50 * i] = Platz_4[3 * i + 1];
        Wegpunktliste[5 + 50 * i] = Platz_4[3 * i + 2];
      }
    }
  }

  /* ****Werkst�ck aufnehmen*****    */
  if ((links_rechts == 0) && (Is_Endstation == 0)) {
    /* '<S17>:75:99' */
    /* Werkst�ck ablegen linke Seite */
    if (hinten_vorne == 1) {
      /* '<S17>:75:102' */
      /* Wegpunkte f�r Platz 1 zuweisen */
      /* '<S17>:75:103' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[50 * i] = Platz_1[3 * i];
        Wegpunktliste[1 + 50 * i] = Platz_1[3 * i + 1];
        Wegpunktliste[2 + 50 * i] = Platz_1[3 * i + 2];
      }
    }

    if (hinten_vorne == 0) {
      /* '<S17>:75:106' */
      /*  Wegpunkte f�r Platz 2 zuweisen */
      /* '<S17>:75:107' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[50 * i] = Platz_2[3 * i];
        Wegpunktliste[1 + 50 * i] = Platz_2[3 * i + 1];
        Wegpunktliste[2 + 50 * i] = Platz_2[3 * i + 2];
      }
    }

    /* '<S17>:75:112' */
    for (i = 0; i < 4; i++) {
      Wegpunktliste[3 + 50 * i] = RFID_L[3 * i];
      Wegpunktliste[4 + 50 * i] = RFID_L[3 * i + 1];
      Wegpunktliste[5 + 50 * i] = RFID_L[3 * i + 2];
    }
  }

  if ((links_rechts == 1) && (Is_Endstation == 0)) {
    /* '<S17>:75:116' */
    /* Werkst�ck ablegen linke Seite */
    if (hinten_vorne == 1) {
      /* '<S17>:75:119' */
      /* Wegpunkte f�r Platz 1 zuweisen */
      /* '<S17>:75:120' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[50 * i] = Platz_3[3 * i];
        Wegpunktliste[1 + 50 * i] = Platz_3[3 * i + 1];
        Wegpunktliste[2 + 50 * i] = Platz_3[3 * i + 2];
      }
    }

    if (hinten_vorne == 0) {
      /* '<S17>:75:123' */
      /*  Wegpunkte f�r Platz 2 zuweisen */
      /* '<S17>:75:124' */
      for (i = 0; i < 4; i++) {
        Wegpunktliste[50 * i] = Platz_4[3 * i];
        Wegpunktliste[1 + 50 * i] = Platz_4[3 * i + 1];
        Wegpunktliste[2 + 50 * i] = Platz_4[3 * i + 2];
      }
    }

    /* '<S17>:75:129' */
    for (i = 0; i < 4; i++) {
      Wegpunktliste[3 + 50 * i] = RFID_R[3 * i];
      Wegpunktliste[4 + 50 * i] = RFID_R[3 * i + 1];
      Wegpunktliste[5 + 50 * i] = RFID_R[3 * i + 2];
    }
  }

  /* X Werte um Offset erh�hen */
  /* '<S17>:75:135' */
  for (i = 0; i < 6; i++) {
    Wegpunktliste_0[i] = (int16_T)((int32_T)Wegpunktliste[i] + offset_Station);
  }

  for (i = 0; i < 3; i++) {
    for (offset_Station = 0; offset_Station < 6; offset_Station++) {
      Wegpunktliste_0[offset_Station + 6 * (i + 1)] = (int16_T)Wegpunktliste[(1
        + i) * 50 + offset_Station];
    }
  }

  for (i = 0; i < 4; i++) {
    for (offset_Station = 0; offset_Station < 6; offset_Station++) {
      Wegpunktliste[offset_Station + 50 * i] = Wegpunktliste_0[6 * i +
        offset_Station];
    }
  }
}

uint32_T MWDSP_EPH_R_B(boolean_T evt, uint32_T *sta)
{
  uint32_T retVal;
  int32_T curState;
  int32_T newState;
  int32_T newStateR;
  int32_T lastzcevent;
  uint32_T previousState;

  /* S-Function (sdspcount2): '<S5>/Counter' */
  /* Detect rising edge events */
  previousState = *sta;
  retVal = 0U;
  lastzcevent = 0;
  newState = 5;
  newStateR = 5;
  if (evt) {
    curState = 2;
  } else {
    curState = 1;
  }

  if (previousState == 5U) {
    newStateR = curState;
  } else {
    if ((uint32_T)curState != previousState) {
      if (previousState == 3U) {
        if ((uint32_T)curState == 1U) {
          newStateR = 1;
        } else {
          lastzcevent = 2;
          previousState = 1U;
        }
      }

      if (previousState == 4U) {
        if ((uint32_T)curState == 1U) {
          newStateR = 1;
        } else {
          lastzcevent = 3;
          previousState = 1U;
        }
      }

      if ((previousState == 1U) && ((uint32_T)curState == 2U)) {
        retVal = 2U;
      }

      if (previousState == 0U) {
        retVal = 2U;
      }

      if (retVal == (uint32_T)lastzcevent) {
        retVal = 0U;
      }

      if (((uint32_T)curState == 1U) && (retVal == 2U)) {
        newState = 3;
      } else {
        newState = curState;
      }
    }
  }

  if ((uint32_T)newStateR != 5U) {
    *sta = (uint32_T)newStateR;
    retVal = 0U;
  }

  if ((uint32_T)newState != 5U) {
    *sta = (uint32_T)newState;
  }

  /* End of S-Function (sdspcount2): '<S5>/Counter' */
  return retVal;
}

/* Model output function for TID0 */
void KitGewerk2_v14_output0(void)      /* Sample time: [0.0s, 0.0s] */
{
  real_T v0;
  real_T v1;
  real_T v2;
  int16_T y[12];
  real_T x[12];
  int32_T k;
  int32_T low_ip1;
  int32_T high_i;
  int32_T mid_i;
  static const int16_T b_x[12] = { 40, 45, 50, 60, 75, 100, 125, 150, 175, 200,
    250, 300 };

  static const real_T c_x[12] = { 255.0, 249.7733813, 228.6082474, 193.6871795,
    152.0044843, 113.7266187, 92.42268041, 76.36407767, 65.19289827, 55.1025641,
    43.06299213, 34.97068404 };

  boolean_T exitg2;
  uint8_T SOC;
  uint8_T FLAG;
  boolean_T b[9];
  real_T velocity_motor0_in;
  real_T velocity_motor1_in;
  real_T velocity_motor2_in;
  ZCEventType zcEvent;
  int32_T i;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(KitGewerk2_v14_DW.Fahrt_zum_Warteplatzsimfcn_Subs);

  /* Reset subsysRan breadcrumbs */
  srClearBC(KitGewerk2_v14_DW.getIDfromFlash_SubsysRanBC);

  /* RateTransition: '<S47>/Rate Transition1' */
  KitGewerk2_v14_B.RateTransition1 = KitGewerk2_v14_B.FIFOwrite1;

  /* Level2 S-Function Block: '<S47>/FIFO read 1' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[18];
    sfcnOutputs(rts, 0);
  }

  for (i = 0; i < 102; i++) {
    /* DataTypeConversion: '<S45>/uint16 to double' */
    KitGewerk2_v14_B.uint16todouble[i] = KitGewerk2_v14_B.FIFOread1[i];

    /* Memory: '<S45>/last error free response' */
    KitGewerk2_v14_B.lasterrorfreeresponse[i] =
      KitGewerk2_v14_DW.lasterrorfreeresponse_PreviousI[i];
  }

  /* MATLAB Function: '<S45>/error filter & protocol disassembler' */
  /* MATLAB Function 'Robotino/serial communication/error filter & protocol disassembler': '<S48>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Error check of the 'I/O-Board to PC104 message' and filtering of this   % */
  /*  defective response: Substitute defective message by the last error free % */
  /*  message.                                                                % */
  /*  Saving of the rotating direction, velocity, shaft position and running  % */
  /*  time of the three motors. Combining all shaft positions in a vector.    % */
  /*  Combining all running times in a vector.                                % */
  /*  Saving of the three bumper bytes indicating a collision in a vector.    % */
  /*  Saving the values of the nine distance measuring IR-sensors in a vector.% */
  /*                                                                          % */
  /*  inputs: response (actual 'I/O-Board to PC104 message')(vector 102       % */
  /*                    elements)                                             % */
  /*          error_free_resp_in (last error free 'I/O-Board to PC104         % */
  /*                              message')                                   % */
  /*  outputs: directions and velocities of the three motors                  % */
  /*           motor_positions_out (shaft positions of the three motors)      % */
  /*                               (vector 12 elements)                       % */
  /*           time_bytes_out (running times of the three motors)             % */
  /*                          (vector 9 elements)                             % */
  /*           distance_measuring_sensors_out (values of the nine IR-sensors) % */
  /*                                          (vector 9 elements)             % */
  /*           bumper_out (vector 3 elements)                                 % */
  /*           error_free_resp_out (error free 'I/O-Board to PC104 message')  % */
  /*                               (vector 102 elements)                      % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*            motor_positions_out, time_bytes_out, ...) */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  filtering defective 'I/O-Board to PC104 messages' % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*         % if the ... */
  if ((KitGewerk2_v14_B.uint16todouble[0] == 101.0) &&
      (KitGewerk2_v14_B.uint16todouble[1] == 82.0) &&
      (KitGewerk2_v14_B.uint16todouble[2] == 69.0) &&
      (KitGewerk2_v14_B.uint16todouble[3] == 67.0) &&
      (KitGewerk2_v14_B.uint16todouble[99] == 114.0) &&
      (KitGewerk2_v14_B.uint16todouble[100] == 101.0) &&
      (KitGewerk2_v14_B.uint16todouble[101] == 99.0)) {
    /* '<S48>:1:36' */
    /* '<S48>:1:37' */
    /* '<S48>:1:38' */
    /*  counter (101), ... */
    /*  the start (REC) and stop (rec) bytes are true ... */
    /* '<S48>:1:40' */
    memcpy(&KitGewerk2_v14_B.error_free_resp_out[0],
           &KitGewerk2_v14_B.uint16todouble[0], 102U * sizeof(real_T));

    /*  save the actual 'I/O-Board to ... */
    /*  PC104 message' */
  } else {
    /*  otherwise ... */
    /* '<S48>:1:43' */
    memcpy(&KitGewerk2_v14_B.error_free_resp_out[0],
           &KitGewerk2_v14_B.lasterrorfreeresponse[0], 102U * sizeof(real_T));

    /*  save the last error ... */
    /*  free 'I/O-Board to PC104 message' */
  }

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save rotating direction, velocity, shaft position and the running time % */
  /*  of motor0                                                              % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S48>:1:51' */
  KitGewerk2_v14_B.direction_motor0_out_p =
    KitGewerk2_v14_B.error_free_resp_out[25];

  /* '<S48>:1:52' */
  KitGewerk2_v14_B.velocity_motor0_out_d = KitGewerk2_v14_B.error_free_resp_out
    [26];

  /*  position_motor0_byte1 = error_free_resp_out(28); */
  /*  position_motor0_byte2 = error_free_resp_out(29); */
  /*  position_motor0_byte3 = error_free_resp_out(30); */
  /*  position_motor0_byte4 = error_free_resp_out(31); */
  /*  time_motor0_byte1     = error_free_resp_out(34); */
  /*  time_motor0_byte2     = error_free_resp_out(35); */
  /*  time_motor0_byte3     = error_free_resp_out(36); */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save rotating direction, velocity, shaft position and the running time % */
  /*  of motor1                                                              % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S48>:1:65' */
  KitGewerk2_v14_B.direction_motor1_out_d =
    KitGewerk2_v14_B.error_free_resp_out[46];

  /* '<S48>:1:66' */
  KitGewerk2_v14_B.velocity_motor1_out_f = KitGewerk2_v14_B.error_free_resp_out
    [47];

  /*  position_motor1_byte1 = error_free_resp_out(49); */
  /*  position_motor1_byte2 = error_free_resp_out(50); */
  /*  position_motor1_byte3 = error_free_resp_out(51); */
  /*  position_motor1_byte4 = error_free_resp_out(52); */
  /*  time_motor1_byte1     = error_free_resp_out(55); */
  /*  time_motor1_byte2     = error_free_resp_out(56); */
  /*  time_motor1_byte3     = error_free_resp_out(57); */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save rotating direction, velocity, shaft position and the running time % */
  /*  of motor2                                                              % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S48>:1:79' */
  KitGewerk2_v14_B.direction_motor2_out_k =
    KitGewerk2_v14_B.error_free_resp_out[67];

  /* '<S48>:1:80' */
  KitGewerk2_v14_B.velocity_motor2_out_n = KitGewerk2_v14_B.error_free_resp_out
    [68];

  /*  position_motor2_byte1 = error_free_resp_out(70); */
  /*  position_motor2_byte2 = error_free_resp_out(71); */
  /*  position_motor2_byte3 = error_free_resp_out(72); */
  /*  position_motor2_byte4 = error_free_resp_out(73); */
  /*  time_motor2_byte1     = error_free_resp_out(76); */
  /*  time_motor2_byte2     = error_free_resp_out(77); */
  /*  time_motor2_byte3     = error_free_resp_out(78); */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save the three bumper bytes in a vector % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S48>:1:92' */
  KitGewerk2_v14_B.bumper_out[0] = KitGewerk2_v14_B.error_free_resp_out[31];
  KitGewerk2_v14_B.bumper_out[1] = KitGewerk2_v14_B.error_free_resp_out[52];
  KitGewerk2_v14_B.bumper_out[2] = KitGewerk2_v14_B.error_free_resp_out[73];

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save the values of the nine distance measuring sensors in a vector % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S48>:1:98' */
  KitGewerk2_v14_B.distance_measuring_sensors_out[0] =
    KitGewerk2_v14_B.error_free_resp_out[59];
  KitGewerk2_v14_B.distance_measuring_sensors_out[1] =
    KitGewerk2_v14_B.error_free_resp_out[58];
  KitGewerk2_v14_B.distance_measuring_sensors_out[2] =
    KitGewerk2_v14_B.error_free_resp_out[43];
  KitGewerk2_v14_B.distance_measuring_sensors_out[3] =
    KitGewerk2_v14_B.error_free_resp_out[38];
  KitGewerk2_v14_B.distance_measuring_sensors_out[4] =
    KitGewerk2_v14_B.error_free_resp_out[37];
  KitGewerk2_v14_B.distance_measuring_sensors_out[5] =
    KitGewerk2_v14_B.error_free_resp_out[16];
  KitGewerk2_v14_B.distance_measuring_sensors_out[6] =
    KitGewerk2_v14_B.error_free_resp_out[17];
  KitGewerk2_v14_B.distance_measuring_sensors_out[7] =
    KitGewerk2_v14_B.error_free_resp_out[22];
  KitGewerk2_v14_B.distance_measuring_sensors_out[8] =
    KitGewerk2_v14_B.error_free_resp_out[64];

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save positions of the three motor shafts in a vector % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  motor_positions_out = [position_motor0_byte1, position_motor0_byte2, ... */
  /*                         position_motor0_byte3, position_motor0_byte4, ... */
  /*                         position_motor1_byte1, position_motor1_byte2, ... */
  /*                         position_motor1_byte3, position_motor1_byte4, ... */
  /*                         position_motor2_byte1, position_motor2_byte2, ... */
  /*                         position_motor2_byte3, position_motor2_byte4]; */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save the running times of the three motors in a vector % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  time_bytes_out = [time_motor0_byte1, time_motor0_byte2, ... */
  /*                    time_motor0_byte3, time_motor1_byte1, ... */
  /*                    time_motor1_byte2, time_motor1_byte3, ... */
  /*                    time_motor2_byte1, time_motor2_byte2, time_motor2_byte3]; */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  save values of digital input 0 - 3 % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S48>:1:125' */
  KitGewerk2_v14_B.di03_bump_out = KitGewerk2_v14_B.error_free_resp_out[31];

  /* End of MATLAB Function: '<S45>/error filter & protocol disassembler' */

  /* Outport: '<Root>/Robotino raw data' */
  memcpy(&KitGewerk2_v14_Y.Robotinorawdata[0],
         &KitGewerk2_v14_B.error_free_resp_out[0], 102U * sizeof(real_T));

  /* MATLAB Function: '<S7>/receive direction, unit & velocity converter' */
  /* MATLAB Function 'Robotino/receive direction, unit & velocity converter': '<S44>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  assembly of the three separate positive motor velocities (resolution:   % */
  /*  1Byte) and their rotation direction to positive and/or negative         % */
  /*  longitudinal, lateral & rotational velocities (in milimeters per        % */
  /*  second)                                                                 % */
  /*                                                                          % */
  /*  inputs:  direction_motor0_in (rotating direction of motor0              % */
  /*           (129 := counter-clockwise; 128 := clockwise)),                 % */
  /*           velocity_motor0_in (from 0 to 255),                            % */
  /*           direction_motor1_in (rotating direction of motor1              % */
  /*           (0 := counter-clockwise; 1 := clockwise)),                     % */
  /*           velocity_motor1_in (from 0 to 255),                            % */
  /*           direction_motor2_in (rotating direction of motor2              % */
  /*           (0 := counter-clockwise; 1 := clockwise)),                     % */
  /*           velocity_motor2_in (from 0 to 255)                             % */
  /*  outputs: v_x_out (longitudinal velocity (in milimeters per second)),    % */
  /*           v_y_out (lateral velocity (in milimeters per second)),         % */
  /*           v_theta_out (rotational velocity (in milimeters per second))   % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  assembly of absolute motor velocity and rotating direction to % */
  /*  longitudinal, lateral & rotational velocity for every motor   % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  if (KitGewerk2_v14_B.direction_motor0_out_p < 129.0) {
    /* '<S44>:1:27' */
    /* '<S44>:1:28' */
    v0 = -KitGewerk2_v14_B.velocity_motor0_out_d;
  } else {
    /* '<S44>:1:30' */
    v0 = KitGewerk2_v14_B.velocity_motor0_out_d;
  }

  if (KitGewerk2_v14_B.direction_motor1_out_d < 1.0) {
    /* '<S44>:1:33' */
    /* '<S44>:1:34' */
    v1 = -KitGewerk2_v14_B.velocity_motor1_out_f;
  } else {
    /* '<S44>:1:36' */
    v1 = KitGewerk2_v14_B.velocity_motor1_out_f;
  }

  if (KitGewerk2_v14_B.direction_motor2_out_k < 1.0) {
    /* '<S44>:1:39' */
    /* '<S44>:1:40' */
    v2 = -KitGewerk2_v14_B.velocity_motor2_out_n;
  } else {
    /* '<S44>:1:42' */
    v2 = KitGewerk2_v14_B.velocity_motor2_out_n;
  }

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  conversion of the separate motor velocities from a value between -255 % */
  /*  and 255 to millimeters                                                % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S44>:1:50' */
  v0 *= 7.02;

  /* '<S44>:1:51' */
  v1 *= 7.02;

  /* '<S44>:1:52' */
  v2 *= 7.02;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  conversion from three separate motor velocities to longitudinal, % */
  /*  lateral & rotational velocity                                    % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S44>:1:58' */
  KitGewerk2_v14_B.v_x_out = (v2 - v0) / 1.7320508075688774;

  /*  in mm/s */
  /* '<S44>:1:59' */
  KitGewerk2_v14_B.v_y_out = ((v0 - 2.0 * v1) + v2) / 3.0;

  /*  in mm/s */
  /* '<S44>:1:60' */
  KitGewerk2_v14_B.v_theta_out = ((v0 + v1) + v2) / 405.0;

  /* End of MATLAB Function: '<S7>/receive direction, unit & velocity converter' */

  /* MATLAB Function: '<S7>/distance converter' */
  /*  in rad/s */
  /* MATLAB Function 'Robotino/distance converter': '<S42>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  conversion of the nine distance measuring sensor values (resolution:    % */
  /*  1Byte) to unit milimeters (range: from 40mm to 1500mm) with linear      % */
  /*  interpolation                                                           % */
  /*                                                                          % */
  /*  input:  vector containing the values of the nine distance measuring     % */
  /*          sensors                                                         % */
  /*  output: vector containing the nine values in milimeters                 % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  , ... */
  /* 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1500]; */
  /*  , 24.37410072, ... */
  /*  16.3381295, 11.62589928, 8.661870504, ... */
  /*  6.316546763, 4.74, 3.65, 2.96, 2.40, ... */
  /*  2.035971223, 1.539568345]; */
  /*  x_sensor = round(100 * x_sensor) / 100; */
  /* '<S42>:1:25' */
  memcpy(&x[0], &c_x[0], 12U * sizeof(real_T));
  for (i = 0; i < 9; i++) {
    KitGewerk2_v14_B.dms_out[i] = (rtNaN);
  }

  for (i = 0; i < 6; i++) {
    v0 = x[i];
    x[i] = x[11 - i];
    x[11 - i] = v0;
  }

  for (i = 0; i < 12; i++) {
    y[i] = b_x[i];
  }

  for (i = 0; i < 6; i++) {
    low_ip1 = y[i];
    y[i] = y[11 - i];
    y[11 - i] = (int16_T)low_ip1;
  }

  for (i = 0; i < 9; i++) {
    KitGewerk2_v14_B.dms_out[i] = (rtNaN);
  }

  for (k = 0; k < 9; k++) {
    if (rtIsNaN(KitGewerk2_v14_B.distance_measuring_sensors_out[k])) {
      KitGewerk2_v14_B.dms_out[k] = (rtNaN);
    } else {
      if (!((KitGewerk2_v14_B.distance_measuring_sensors_out[k] > x[11]) ||
            (KitGewerk2_v14_B.distance_measuring_sensors_out[k] < x[0]))) {
        i = 1;
        low_ip1 = 2;
        high_i = 12;
        while (high_i > low_ip1) {
          mid_i = (i + high_i) >> 1;
          if (KitGewerk2_v14_B.distance_measuring_sensors_out[k] >= x[mid_i - 1])
          {
            i = mid_i;
            low_ip1 = mid_i + 1;
          } else {
            high_i = mid_i;
          }
        }

        v0 = (KitGewerk2_v14_B.distance_measuring_sensors_out[k] - x[i - 1]) /
          (x[i] - x[i - 1]);
        if (y[i - 1] == y[i]) {
          KitGewerk2_v14_B.dms_out[k] = y[i - 1];
        } else {
          KitGewerk2_v14_B.dms_out[k] = (1.0 - v0) * (real_T)y[i - 1] + v0 *
            (real_T)y[i];
        }
      }
    }
  }

  /* End of MATLAB Function: '<S7>/distance converter' */

  /* Memory: '<S45>/stop marker' */
  KitGewerk2_v14_B.stopmarker[0] = KitGewerk2_v14_DW.stopmarker_PreviousInput[0];
  KitGewerk2_v14_B.stopmarker[1] = KitGewerk2_v14_DW.stopmarker_PreviousInput[1];
  KitGewerk2_v14_B.stopmarker[2] = KitGewerk2_v14_DW.stopmarker_PreviousInput[2];

  /* MATLAB Function: '<S45>/stop by bumper' */
  /* MATLAB Function 'Robotino/serial communication/stop by bumper': '<S50>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Recognition of collisions and creating of variables indicating and      % */
  /*  marking a collision                                                     % */
  /*                                                                          % */
  /*  inputs: bumper (vector of the three bumper bytes)                       % */
  /*          stop_flag_in (As long as no collision has occured,              % */
  /*                        'stop_flag_in' contains the last bumper vector    % */
  /*                        indicating no collision.                          % */
  /*                        If a collision has occured, 'stop_flag_in'        % */
  /*                        contains the last bumper vector indicating a      % */
  /*                        collision until the simulation stops.)            % */
  /*  outputs: stop_out (indicates a collision: 1 = no collision;             % */
  /*                                            0 = collision)                % */
  /*           stop_flag_out (gets the actual bumper vector unless 'bumper'   % */
  /*                          indicates no collision and 'stop_flag_in'       % */
  /*                          indicates a past collision.)                    % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  i = 1;
  v0 = KitGewerk2_v14_B.bumper_out[0];
  if (rtIsNaN(KitGewerk2_v14_B.bumper_out[0])) {
    low_ip1 = 2;
    exitg2 = false;
    while ((!exitg2) && (low_ip1 < 4)) {
      i = low_ip1;
      if (!rtIsNaN(KitGewerk2_v14_B.bumper_out[low_ip1 - 1])) {
        v0 = KitGewerk2_v14_B.bumper_out[low_ip1 - 1];
        exitg2 = true;
      } else {
        low_ip1++;
      }
    }
  }

  if (i < 3) {
    while (i + 1 < 4) {
      if (KitGewerk2_v14_B.bumper_out[i] > v0) {
        v0 = KitGewerk2_v14_B.bumper_out[i];
      }

      i++;
    }
  }

  if (v0 == 31.0) {
    /* '<S50>:1:19' */
    /*  as soon as the maximum value of the bumper ... */
    /*  vector indicates 31 a collision is detected */
    /* '<S50>:1:21' */
    KitGewerk2_v14_B.stop_out = 0.0;

    /* '<S50>:1:22' */
    KitGewerk2_v14_B.stop_flag_out[0] = KitGewerk2_v14_B.bumper_out[0];
    KitGewerk2_v14_B.stop_flag_out[1] = KitGewerk2_v14_B.bumper_out[1];
    KitGewerk2_v14_B.stop_flag_out[2] = KitGewerk2_v14_B.bumper_out[2];
  } else {
    i = 1;
    v1 = KitGewerk2_v14_B.stopmarker[0];
    if (rtIsNaN(KitGewerk2_v14_B.stopmarker[0])) {
      low_ip1 = 2;
      exitg2 = false;
      while ((!exitg2) && (low_ip1 < 4)) {
        i = low_ip1;
        if (!rtIsNaN(KitGewerk2_v14_B.stopmarker[low_ip1 - 1])) {
          v1 = KitGewerk2_v14_B.stopmarker[low_ip1 - 1];
          exitg2 = true;
        } else {
          low_ip1++;
        }
      }
    }

    if (i < 3) {
      while (i + 1 < 4) {
        if (KitGewerk2_v14_B.stopmarker[i] > v1) {
          v1 = KitGewerk2_v14_B.stopmarker[i];
        }

        i++;
      }
    }

    if (v1 == 31.0) {
      /* '<S50>:1:23' */
      /*  if the maximum value of 'stop_flag_in' ... */
      /*  indicates a past collision (31) ... */
      /* '<S50>:1:25' */
      KitGewerk2_v14_B.stop_out = 0.0;

      /*  'stop_out' gets 0 for a further stop of the ... */
      /*  motors and ... */
      /* '<S50>:1:27' */
      KitGewerk2_v14_B.stop_flag_out[0] = KitGewerk2_v14_B.stopmarker[0];
      KitGewerk2_v14_B.stop_flag_out[1] = KitGewerk2_v14_B.stopmarker[1];
      KitGewerk2_v14_B.stop_flag_out[2] = KitGewerk2_v14_B.stopmarker[2];

      /*  'stop_flag_out' gets the last bumper... */
      /*  vector indicating a past collision */
    } else {
      /*  otherwise ... */
      /* '<S50>:1:30' */
      KitGewerk2_v14_B.stop_out = 1.0;

      /*  'stop_out' gets 1 to keep the motors running and ... */
      /* '<S50>:1:31' */
      KitGewerk2_v14_B.stop_flag_out[0] = KitGewerk2_v14_B.bumper_out[0];
      KitGewerk2_v14_B.stop_flag_out[1] = KitGewerk2_v14_B.bumper_out[1];
      KitGewerk2_v14_B.stop_flag_out[2] = KitGewerk2_v14_B.bumper_out[2];

      /*  'stop_flag_out' gets the actual bumper vector */
    }
  }

  /* End of MATLAB Function: '<S45>/stop by bumper' */

  /* MATLAB Function: '<S7>/light barrier & slider' */
  /* MATLAB Function 'Robotino/light barrier & slider': '<S43>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  di03_bump_in = 0 alternatively 12 ->  no light barrier activation       % */
  /*                                        no slider activation              % */
  /*  di03_bump_in = 13                 ->  only light barrier activation     % */
  /*  di03_bump_in = 14                 ->  only slider activation            % */
  /*  di03_bump_in = 15                 ->  light barrier activation          % */
  /*                                        slider activation                 % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  function [light_barrier, slider] = fcn(di03_bump_in) */
  /*  bin = dec2bin(di03_bump_in); */
  /*  if bin(3) == 1 */
  /*      light_barrier = 1; */
  /*  else */
  /*      light_barrier = 0; */
  /*  end */
  /*  if bin(4) == 1 */
  /*      slider = 1; */
  /*  else */
  /*      slider = 0; */
  /*  end */
  if (KitGewerk2_v14_B.di03_bump_out == 13.0) {
    /* '<S43>:1:22' */
    /* '<S43>:1:23' */
    KitGewerk2_v14_B.light_barrier = 1.0;

    /* '<S43>:1:24' */
    KitGewerk2_v14_B.slider = 0.0;
  } else if (KitGewerk2_v14_B.di03_bump_out == 14.0) {
    /* '<S43>:1:25' */
    /* '<S43>:1:26' */
    KitGewerk2_v14_B.light_barrier = 0.0;

    /* '<S43>:1:27' */
    KitGewerk2_v14_B.slider = 1.0;
  } else if (KitGewerk2_v14_B.di03_bump_out == 15.0) {
    /* '<S43>:1:28' */
    /* '<S43>:1:29' */
    KitGewerk2_v14_B.light_barrier = 1.0;

    /* '<S43>:1:30' */
    KitGewerk2_v14_B.slider = 1.0;
  } else {
    /* '<S43>:1:32' */
    KitGewerk2_v14_B.light_barrier = 0.0;

    /* '<S43>:1:33' */
    KitGewerk2_v14_B.slider = 0.0;
  }

  /* End of MATLAB Function: '<S7>/light barrier & slider' */

  /* MATLAB Function: '<S7>/assemble robotino response' */
  /* MATLAB Function 'Robotino/assemble robotino response': '<S41>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Assembly of robot data in a vector of 34 elements.                      % */
  /*                                                                          % */
  /*  inputs:   longitudinal, lateral and rotational velocity (in mm/s),      % */
  /*            shaft positions of the three motors (4 elements per motor),   % */
  /*            running times of the three motors (3 elements per motor),     % */
  /*            values of the nine IR-sensors (in mm),                        % */
  /*            bumper collision (1 = no collision;                           % */
  /*                              0 = collision)                              % */
  /*  outputs:  vector containing assembled input data                        % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  motor_positions_in, time_bytes_in, ...) */
  /* %motor_positions_in, time_bytes_in, ... */
  /* '<S41>:1:16' */
  KitGewerk2_v14_B.robotino_response[0] = KitGewerk2_v14_B.light_barrier;
  KitGewerk2_v14_B.robotino_response[1] = KitGewerk2_v14_B.slider;
  KitGewerk2_v14_B.robotino_response[2] = KitGewerk2_v14_B.v_x_out;
  KitGewerk2_v14_B.robotino_response[3] = KitGewerk2_v14_B.v_y_out;
  KitGewerk2_v14_B.robotino_response[4] = KitGewerk2_v14_B.v_theta_out;
  memcpy(&KitGewerk2_v14_B.robotino_response[5], &KitGewerk2_v14_B.dms_out[0],
         9U * sizeof(real_T));
  KitGewerk2_v14_B.robotino_response[14] = KitGewerk2_v14_B.stop_out;

  /* Outport: '<Root>/Robotino processed data' */
  memcpy(&KitGewerk2_v14_Y.Robotinoprocesseddata[0],
         &KitGewerk2_v14_B.robotino_response[0], 15U * sizeof(real_T));

  /* Level2 S-Function Block: '<S8>/Receive' (xpcudpbytereceive) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[19];
    sfcnOutputs(rts, 0);
  }

  /* Unpack: <S8>/Unpack */
  (void) memcpy(&KitGewerk2_v14_B.Unpack[0], &KitGewerk2_v14_B.Receive_o1[0],
                448);

  /* Outport: '<Root>/UDP data' */
  memcpy(&KitGewerk2_v14_Y.UDPdata[0], &KitGewerk2_v14_B.Unpack[0], 56U * sizeof
         (real_T));

  /* RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */
  if (KitGewerk2_v14_M->Timing.RateInteraction.TID1_2) {
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_B.RateTransitionupsamplingtofunda[i] =
        KitGewerk2_v14_DW.RateTransitionupsamplingtofunda[i];
    }
  }

  /* End of RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */

  /* Unpack: <S4>/Unpack */
  (void) memcpy(&KitGewerk2_v14_B.Unpack_o1,
                &KitGewerk2_v14_B.RateTransitionupsamplingtofunda[0],
                1);
  (void) memcpy(&KitGewerk2_v14_B.Unpack_o2,
                &KitGewerk2_v14_B.RateTransitionupsamplingtofunda[1],
                1);
  (void) memcpy(&KitGewerk2_v14_B.Unpack_o3,
                &KitGewerk2_v14_B.RateTransitionupsamplingtofunda[2],
                1);
  (void) memcpy(&KitGewerk2_v14_B.Unpack_o4,
                &KitGewerk2_v14_B.RateTransitionupsamplingtofunda[3],
                1);
  (void) memcpy(&KitGewerk2_v14_B.Unpack_o5,
                &KitGewerk2_v14_B.RateTransitionupsamplingtofunda[4],
                1);

  /* DataTypeConversion: '<S4>/Data Type Conversion2' */
  KitGewerk2_v14_B.DataTypeConversion2_b = KitGewerk2_v14_B.Unpack_o3;

  /* DataTypeConversion: '<S4>/Data Type Conversion4' */
  KitGewerk2_v14_B.DataTypeConversion4_d = KitGewerk2_v14_B.Unpack_o4;

  /* DataTypeConversion: '<S4>/Data Type Conversion1' */
  KitGewerk2_v14_B.DataTypeConversion1_f = KitGewerk2_v14_B.Unpack_o2;

  /* Constant: '<S5>/Constant7' */
  KitGewerk2_v14_B.Constant7 = KitGewerk2_v14_P.Constant7_Value;

  /* Constant: '<S5>/Constant5' */
  KitGewerk2_v14_B.Constant5 = KitGewerk2_v14_P.Constant5_Value;

  /* Constant: '<S5>/Constant' */
  KitGewerk2_v14_B.Constant = KitGewerk2_v14_P.Constant_Value_m;

  /* Constant: '<S5>/Constant2' */
  KitGewerk2_v14_B.Constant2_f = KitGewerk2_v14_P.Constant2_Value_b;

  /* Constant: '<S5>/Constant4' */
  KitGewerk2_v14_B.Constant4 = KitGewerk2_v14_P.Constant4_Value_g;

  /* DataTypeConversion: '<S4>/Data Type Conversion3' */
  KitGewerk2_v14_B.DataTypeConversion3_k = KitGewerk2_v14_B.Unpack_o1;

  /* Chart: '<S5>/Chart' incorporates:
   *  Constant: '<S20>/Constant1'
   *  Constant: '<S20>/Constant2'
   *  Constant: '<S20>/Constant3'
   */
  if (KitGewerk2_v14_DW.temporalCounter_i1 < 127U) {
    KitGewerk2_v14_DW.temporalCounter_i1++;
  }

  /* Gateway: Gewerk_2/Chart */
  KitGewerk2_v14_DW.sfEvent = -1;

  /* During: Gewerk_2/Chart */
  if (KitGewerk2_v14_DW.is_active_c15_KitGewerk2_v14 == 0U) {
    /* Entry: Gewerk_2/Chart */
    KitGewerk2_v14_DW.is_active_c15_KitGewerk2_v14 = 1U;

    /* Entry Internal: Gewerk_2/Chart */
    /* Transition: '<S17>:227' */
    KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk2_v14_IN_Init;

    /* Entry 'Init': '<S17>:225' */
    KitGewerk2_v14_DW.B_Endst = false;
  } else {
    switch (KitGewerk2_v14_DW.is_c15_KitGewerk2_v14) {
     case KitGewerk2_v14_IN_A_stern_fahrt:
      /* During 'A_stern_fahrt': '<S17>:207' */
      if (KitGewerk2_v14_DW.is_A_stern_fahrt == KitGewerk2_v14_IN_A_stern) {
        /* During 'A_stern': '<S17>:316' */
        if (KitGewerk2_v14_B.Constant4 > 1) {
          /* Transition: '<S17>:321' */
          /*  Sobald der Z�hler>1 */
          /*  befindet sich der  */
          /*  Robi im Feld */
          KitGewerk2_v14_DW.is_A_stern_fahrt = KitGewer_IN_Kollisionserkennung;

          /* Entry 'Kollisionserkennung': '<S17>:319' */
          if (!KitGewerk2_v14_DW.B_Endst) {
            /* Startplatz f�r GW1 freigeben */
            KitGewerk2_v14_B.UI_to_GW1 = 1U;
          } else {
            /* Endplatz f�r GW1 freigeben */
            KitGewerk2_v14_B.UI_to_GW1 = 3U;
          }
        }
      } else {
        /* During 'Kollisionserkennung': '<S17>:319' */
        exitg2 = (KitGewerk2_v14_B.Constant && KitGewerk2_v14_B.Constant2_f &&
                  ((KitGewerk2_v14_B.DataTypeConversion2_b == 1) ||
                   (KitGewerk2_v14_B.DataTypeConversion2_b == 3)));
        if (exitg2) {
          /* Transition: '<S17>:322' */
          KitGewerk2_v14_DW.is_A_stern_fahrt = KitGewerk2_v_IN_NO_ACTIVE_CHILD;
          KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
            KitG_IN_Eintrittspunkt_erreicht;
        }
      }
      break;

     case KitGewerk2_IN_Auftrag_empfangen:
      /* During 'Auftrag_empfangen': '<S17>:326' */
      exitg2 = ((KitGewerk2_v14_B.DataTypeConversion3_k < 200) &&
                (KitGewerk2_v14_B.DataTypeConversion1_f < 200));
      if (exitg2) {
        /* Transition: '<S17>:327' */
        /* Exit 'Auftrag_empfangen': '<S17>:326' */
        KitGewerk2_v14_DW.UI_Startstation =
          KitGewerk2_v14_B.DataTypeConversion3_k;
        KitGewerk2_v14_DW.UI_Endstation = KitGewerk2_v14_B.DataTypeConversion1_f;

        /* Eing�nge speichern */
        KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
          KitGewer_IN_Stationsentscheider;

        /* Entry 'Stationsentscheider': '<S17>:214' */
        if (!KitGewerk2_v14_DW.B_Endst) {
          KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Startstation;
        } else {
          KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Endstation;
        }
      }
      break;

     case KitGewerk_IN_Auftrag_empfangen1:
      /* During 'Auftrag_empfangen1': '<S17>:328' */
      exitg2 = ((KitGewerk2_v14_B.DataTypeConversion3_k < 200) &&
                (KitGewerk2_v14_B.DataTypeConversion1_f < 200));
      if (exitg2) {
        /* Transition: '<S17>:330' */
        /* Exit 'Auftrag_empfangen1': '<S17>:328' */
        KitGewerk2_v14_DW.UI_Startstation =
          KitGewerk2_v14_B.DataTypeConversion3_k;
        KitGewerk2_v14_DW.UI_Endstation = KitGewerk2_v14_B.DataTypeConversion1_f;

        /* Eing�nge speichern */
        KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
          KitGewer_IN_Stationsentscheider;

        /* Entry 'Stationsentscheider': '<S17>:214' */
        if (!KitGewerk2_v14_DW.B_Endst) {
          KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Startstation;
        } else {
          KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Endstation;
        }
      }
      break;

     case KitG_IN_Eintrittspunkt_erreicht:
      /* During 'Eintrittspunkt_erreicht': '<S17>:191' */
      if (KitGewerk2_v14_DW.UI_Auftrnr <= 16) {
        /* Transition: '<S17>:192' */
        KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
          KitGewerk_IN_Routinen_Stationen;

        /* Entry Internal 'Routinen_Stationen': '<S17>:187' */
        /* Transition: '<S17>:188' */
        KitGewerk2_v14_DW.is_Routinen_Stationen =
          IN_Wegpunktliste_erstellen_stat;

        /* Entry 'Wegpunktliste_erstellen_state': '<S17>:76' */
        KitGewe_Wegpunktliste_erstellen(KitGewerk2_v14_DW.UI_Auftrnr, (uint8_T)
          KitGewerk2_v14_DW.B_Endst, KitGewerk2_v14_B.A_WPL);
        KitGewerk2_v14_B.B_WPL_cnt_reset = true;
      } else {
        exitg2 = ((KitGewerk2_v14_DW.UI_Auftrnr > 16) &&
                  (KitGewerk2_v14_DW.UI_Auftrnr <= 20));
        if (exitg2) {
          /* Transition: '<S17>:193' */
          KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
            KitGew_IN_Routinen_Warteplaetze;
        } else {
          if (KitGewerk2_v14_DW.UI_Auftrnr > 20) {
            /* Transition: '<S17>:196' */
            KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
              KitGe_IN_Routinen_Ladestationen;

            /* Entry Internal 'Routinen_Ladestationen': '<S17>:190' */
            /* Transition: '<S17>:315' */
            KitGewerk2_v14_DW.is_Routinen_Ladestationen =
              KitGewerk2_v14_IN_Wegpunkte;
          }
        }
      }
      break;

     case KitGewerk2_v1_IN_Fahrt_in_nav_2:
      /* During 'Fahrt_in_nav_2': '<S17>:233' */
      /* Transition: '<S17>:343' */
      KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk2_v_IN_Station_aendern;

      /* Entry 'Station_aendern': '<S17>:342' */
      if (!KitGewerk2_v14_DW.B_Endst) {
        KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Startstation;
      } else {
        KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Endstation;
      }
      break;

     case KitGewe_IN_Fahrt_zum_Warteplatz:
      /* During 'Fahrt_zum_Warteplatz': '<S17>:240' */
      exitg2 = (KitGewerk2_v14_B.Constant && KitGewerk2_v14_B.Constant2_f);
      if (exitg2) {
        /* Transition: '<S17>:287' */
        /* Exit 'Fahrt_zum_Warteplatz': '<S17>:240' */
        KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
          KitGewerk_IN_Warten_auf_Auftrag;
      }
      break;

     case KitGewerk2_v14_IN_Init:
      /* During 'Init': '<S17>:225' */
      /* Transition: '<S17>:241' */
      KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewe_IN_Fahrt_zum_Warteplatz;

      /* Outputs for Function Call SubSystem: '<S17>/Fahrt_zum_Warteplatz.simfcn' */
      /* Entry 'Fahrt_zum_Warteplatz': '<S17>:240' */
      /* Simulink Function 'simfcn': '<S17>:345' */
      KitGewerk2_v14_B.Constant1[0] = KitGewerk2_v14_P.Constant1_Value[0];
      KitGewerk2_v14_B.Constant1[1] = KitGewerk2_v14_P.Constant1_Value[1];
      KitGewerk2_v14_B.Constant2[0] = KitGewerk2_v14_P.Constant2_Value[0];
      KitGewerk2_v14_B.Constant2[1] = KitGewerk2_v14_P.Constant2_Value[1];
      for (i = 0; i < 6; i++) {
        KitGewerk2_v14_B.Constant3[i] = KitGewerk2_v14_P.Constant3_Value[i];
      }

      /* Level2 S-Function Block: '<S21>/S-Function' (bahnplaner_v22) */
      {
        SimStruct *rts = KitGewerk2_v14_M->childSfunctions[8];
        sfcnOutputs(rts, 1);
      }

      /* Level2 S-Function Block: '<S21>/S-Function' (bahnplaner_v22) */
      {
        SimStruct *rts = KitGewerk2_v14_M->childSfunctions[8];
        sfcnUpdate(rts, 1);
        if (ssGetErrorStatus(rts) != (NULL))
          return;
      }

      KitGewerk2_v14_DW.Fahrt_zum_Warteplatzsimfcn_Subs = 4;

      /* End of Outputs for SubSystem: '<S17>/Fahrt_zum_Warteplatz.simfcn' */
      memcpy(&KitGewerk2_v14_B.A_stern_test[0], &KitGewerk2_v14_B.Wegpunkte[0],
             200U * sizeof(real_T));
      break;

     case KitGewerk2_v14_IN_Nav2_abfrage:
      /* During 'Nav2_abfrage': '<S17>:231' */
      /* Transition: '<S17>:238' */
      KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk2_v14_IN_A_stern_fahrt;

      /* Entry Internal 'A_stern_fahrt': '<S17>:207' */
      /* Transition: '<S17>:317' */
      KitGewerk2_v14_DW.is_A_stern_fahrt = KitGewerk2_v14_IN_A_stern;
      break;

     case KitGe_IN_Routinen_Ladestationen:
      /* During 'Routinen_Ladestationen': '<S17>:190' */
      switch (KitGewerk2_v14_DW.is_Routinen_Ladestationen) {
       case KitGewerk_IN_Fahrt_an_rand_nav1:
        /* During 'Fahrt_an_rand_nav1': '<S17>:262' */
        exitg2 = (KitGewerk2_v14_B.Constant && KitGewerk2_v14_B.Constant2_f);
        if (exitg2) {
          /* Transition: '<S17>:264' */
          KitGewerk2_v14_DW.is_Routinen_Ladestationen =
            KitGewerk2_v_IN_NO_ACTIVE_CHILD;
          KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
            KitGewer_IN_Stationsentscheider;

          /* Entry 'Stationsentscheider': '<S17>:214' */
          if (!KitGewerk2_v14_DW.B_Endst) {
            KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Startstation;
          } else {
            KitGewerk2_v14_DW.UI_Auftrnr = KitGewerk2_v14_DW.UI_Endstation;
          }
        }
        break;

       case KitGewerk2_v1_IN_Kontakt_fehler:
        /* During 'Kontakt_fehler': '<S17>:255' */
        exitg2 = (KitGewerk2_v14_B.Constant && KitGewerk2_v14_B.Constant2_f);
        if (exitg2) {
          /* Transition: '<S17>:267' */
          KitGewerk2_v14_DW.is_Routinen_Ladestationen =
            KitGewerk2_v1_IN_Laden_beginnen;
        }
        break;

       case KitGewerk2_v14_IN_Laden_beenden:
        /* During 'Laden_beenden': '<S17>:260' */
        /* Transition: '<S17>:263' */
        KitGewerk2_v14_DW.is_Routinen_Ladestationen =
          KitGewerk_IN_Fahrt_an_rand_nav1;
        break;

       case KitGewerk2_v1_IN_Laden_beginnen:
        /* During 'Laden_beginnen': '<S17>:253' */
        /* Transition: '<S17>:256' */
        KitGewerk2_v14_DW.is_Routinen_Ladestationen =
          KitGewerk2_v1_IN_Kontakt_fehler;
        break;

       case KitGewer_IN_Warten_auf_Ereignis:
        /* During 'Warten_auf_Ereignis': '<S17>:258' */
        /* Transition: '<S17>:261' */
        KitGewerk2_v14_DW.is_Routinen_Ladestationen =
          KitGewerk2_v14_IN_Laden_beenden;
        break;

       default:
        /* During 'Wegpunkte': '<S17>:252' */
        exitg2 = (KitGewerk2_v14_B.Constant && KitGewerk2_v14_B.Constant2_f);
        if (exitg2) {
          /* Transition: '<S17>:254' */
          KitGewerk2_v14_DW.is_Routinen_Ladestationen =
            KitGewerk2_v1_IN_Laden_beginnen;
        }
        break;
      }
      break;

     case KitGewerk_IN_Routinen_Stationen:
      /* During 'Routinen_Stationen': '<S17>:187' */
      switch (KitGewerk2_v14_DW.is_Routinen_Stationen) {
       case IN_Wegpunktliste_erstellen_stat:
        /* During 'Wegpunktliste_erstellen_state': '<S17>:76' */
        if (KitGewerk2_v14_DW.B_Endst) {
          /* Transition: '<S17>:114' */
          KitGewerk2_v14_DW.is_Routinen_Stationen =
            KitGewerk_IN_Werkstueck_ablegen;
          KitGewerk2_v14_DW.is_Werkstueck_ablegen =
            KitGewerk2_v14_IN_Fahrt_zu_RFID;

          /* Entry 'Fahrt_zu_RFID': '<S17>:113' */
          KitGewerk2_v14_B.B_WPL_cnt_reset = false;
        } else {
          /* Transition: '<S17>:116' */
          KitGewerk2_v14_DW.is_Routinen_Stationen =
            KitGewe_IN_Werkstueck_aufnehmen;
          KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
            KitGewerk2_v_IN_Fahrt_zu_Platz1;

          /* Entry 'Fahrt_zu_Platz1': '<S17>:115' */
          KitGewerk2_v14_B.B_WPL_cnt_reset = false;
        }
        break;

       case KitGewerk_IN_Werkstueck_ablegen:
        /* During 'Werkstueck_ablegen': '<S17>:150' */
        switch (KitGewerk2_v14_DW.is_Werkstueck_ablegen) {
         case KitGewerk2_v1_IN_Auftrag_fertig:
          /* During 'Auftrag_fertig': '<S17>:129' */
          exitg2 = (KitGewerk2_v14_B.Constant && KitGewerk2_v14_B.Constant2_f);
          if (exitg2) {
            /* Transition: '<S17>:182' */
            /* Exit 'Auftrag_fertig': '<S17>:129' */
            KitGewerk2_v14_B.UI_to_GW1 = 5U;
            KitGewerk2_v14_DW.B_Endst = false;
            KitGewerk2_v14_DW.is_Werkstueck_ablegen =
              KitGewerk2_v_IN_NO_ACTIVE_CHILD;
            KitGewerk2_v14_DW.is_Routinen_Stationen =
              KitGewerk2_v_IN_NO_ACTIVE_CHILD;
            KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
              Kit_IN_Warten_auf_neuen_Auftrag;
          }
          break;

         case KitGewerk2_v_IN_Fahrt_zu_Ablage:
          /* During 'Fahrt_zu_Ablage': '<S17>:108' */
          if (KitGewerk2_v14_B.Constant7) {
            /* Transition: '<S17>:111' */
            KitGewerk2_v14_DW.is_Werkstueck_ablegen =
              KitGewerk2_v_IN_Greifer_Oeffnen;
            KitGewerk2_v14_DW.temporalCounter_i1 = 0U;

            /* Entry 'Greifer_Oeffnen': '<S17>:110' */
            KitGewerk2_v14_B.B_Stop = true;
            KitGewerk2_v14_B.B_Greifer = false;
            KitGewerk2_v14_B.B_WP_weiter = true;
          }
          break;

         case KitGewerk2_v14_IN_Fahrt_zu_RFID:
          /* During 'Fahrt_zu_RFID': '<S17>:113' */
          if (KitGewerk2_v14_B.Constant7) {
            /* Transition: '<S17>:117' */
            KitGewerk2_v14_DW.is_Werkstueck_ablegen =
              KitGewerk2_v14_IN_RFID_lesen;

            /* Entry 'RFID_lesen': '<S17>:83' */
            KitGewerk2_v14_B.UI_to_GW1 = 4U;
            KitGewerk2_v14_B.B_Stop = true;
          }
          break;

         case KitGewerk2_v_IN_Greifer_Oeffnen:
          /* During 'Greifer_Oeffnen': '<S17>:110' */
          if (KitGewerk2_v14_DW.temporalCounter_i1 >= 100U) {
            /* Transition: '<S17>:123' */
            KitGewerk2_v14_DW.is_Werkstueck_ablegen =
              KitGewerk_IN_WP_weiterschalten2;

            /* Entry 'WP_weiterschalten2': '<S17>:122' */
            KitGewerk2_v14_B.B_Stop = false;
          }
          break;

         case KitGewerk2_v14_IN_RFID_lesen:
          /* During 'RFID_lesen': '<S17>:83' */
          if (KitGewerk2_v14_B.DataTypeConversion2_b == 4) {
            /* Transition: '<S17>:101' */
            /* Exit 'RFID_lesen': '<S17>:83' */
            KitGewerk2_v14_B.B_Stop = false;
            KitGewerk2_v14_B.B_WP_weiter = true;
            KitGewerk2_v14_DW.is_Werkstueck_ablegen =
              KitGewerk2_IN_WP_weiterschalten;
          }
          break;

         case KitGewerk2_IN_WP_weiterschalten:
          /* During 'WP_weiterschalten': '<S17>:100' */
          /* Transition: '<S17>:109' */
          KitGewerk2_v14_DW.is_Werkstueck_ablegen =
            KitGewerk2_v_IN_Fahrt_zu_Ablage;

          /* Entry 'Fahrt_zu_Ablage': '<S17>:108' */
          KitGewerk2_v14_B.B_WP_weiter = false;
          break;

         default:
          /* During 'WP_weiterschalten2': '<S17>:122' */
          /* Transition: '<S17>:126' */
          KitGewerk2_v14_DW.is_Werkstueck_ablegen =
            KitGewerk2_v1_IN_Auftrag_fertig;

          /* Entry 'Auftrag_fertig': '<S17>:129' */
          KitGewerk2_v14_B.B_WP_weiter = false;
          break;
        }
        break;

       default:
        /* During 'Werkstueck_aufnehmen': '<S17>:184' */
        switch (KitGewerk2_v14_DW.is_Werkstueck_aufnehmen) {
         case KitGewerk2_v_IN_Fahrt_zu_Platz1:
          /* During 'Fahrt_zu_Platz1': '<S17>:115' */
          exitg2 = (KitGewerk2_v14_B.Constant7 && KitGewerk2_v14_B.Constant5);
          if (exitg2) {
            /* Transition: '<S17>:118' */
            KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
              KitGewerk2_v1_IN_Greifer_schlie;
            KitGewerk2_v14_DW.temporalCounter_i1 = 0U;

            /* Entry 'Greifer_schlie': '<S17>:97' */
            KitGewerk2_v14_B.B_WP_weiter = true;
            KitGewerk2_v14_B.B_Greifer = true;
            KitGewerk2_v14_B.B_Stop = true;
          }
          break;

         case KitGewerk2_v1_IN_Greifer_schlie:
          /* During 'Greifer_schlie': '<S17>:97' */
          if (KitGewerk2_v14_DW.temporalCounter_i1 >= 100U) {
            /* Transition: '<S17>:139' */
            /* Exit 'Greifer_schlie': '<S17>:97' */
            KitGewerk2_v14_B.B_Stop = false;
            KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
              KitGewe_IN_Weiterfahren_zu_RFID;

            /* Entry 'Weiterfahren_zu_RFID': '<S17>:138' */
            KitGewerk2_v14_B.B_WP_weiter = false;
          }
          break;

         case KitGewerk2_v14_IN_RFID_lesen_2:
          /* During 'RFID_lesen_2': '<S17>:140' */
          if (KitGewerk2_v14_B.DataTypeConversion2_b == 2) {
            /* Transition: '<S17>:143' */
            /* Exit 'RFID_lesen_2': '<S17>:140' */
            KitGewerk2_v14_B.B_Stop = false;
            KitGewerk2_v14_B.B_WP_weiter = true;
            KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
              KitGewer_IN_WP_weiterschalten_3;
          } else {
            KitGewerk2_v14_B.UI_to_GW1 = 2U;
            KitGewerk2_v14_B.B_Stop = true;
          }
          break;

         case KitGewerk2_v1_IN_Routine_fertig:
          /* During 'Routine_fertig': '<S17>:145' */
          /* Transition: '<S17>:229' */
          KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
            KitGewerk2_v_IN_NO_ACTIVE_CHILD;
          KitGewerk2_v14_DW.is_Routinen_Stationen =
            KitGewerk2_v_IN_NO_ACTIVE_CHILD;
          KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
            KitGewerk2_v14_IN_Nav2_abfrage;
          break;

         case KitGewer_IN_WP_weiterschalten_3:
          /* During 'WP_weiterschalten_3': '<S17>:142' */
          /* Transition: '<S17>:146' */
          KitGewerk2_v14_B.B_WP_weiter = false;
          KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
            KitGewerk2_v1_IN_Routine_fertig;

          /* Entry 'Routine_fertig': '<S17>:145' */
          KitGewerk2_v14_DW.B_Endst = true;
          break;

         default:
          /* During 'Weiterfahren_zu_RFID': '<S17>:138' */
          if (KitGewerk2_v14_B.Constant7) {
            /* Transition: '<S17>:141' */
            KitGewerk2_v14_DW.is_Werkstueck_aufnehmen =
              KitGewerk2_v14_IN_RFID_lesen_2;
          }
          break;
        }
        break;
      }
      break;

     case KitGew_IN_Routinen_Warteplaetze:
      /* During 'Routinen_Warteplaetze': '<S17>:189' */
      /* Transition: '<S17>:212' */
      KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = Kit_IN_Warten_auf_neuen_Auftrag;
      break;

     case KitGewerk2_v_IN_Station_aendern:
      /* During 'Station_aendern': '<S17>:342' */
      /* Transition: '<S17>:344' */
      KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk_IN_Routinen_Stationen;

      /* Entry Internal 'Routinen_Stationen': '<S17>:187' */
      /* Transition: '<S17>:188' */
      KitGewerk2_v14_DW.is_Routinen_Stationen = IN_Wegpunktliste_erstellen_stat;

      /* Entry 'Wegpunktliste_erstellen_state': '<S17>:76' */
      KitGewe_Wegpunktliste_erstellen(KitGewerk2_v14_DW.UI_Auftrnr, (uint8_T)
        KitGewerk2_v14_DW.B_Endst, KitGewerk2_v14_B.A_WPL);
      KitGewerk2_v14_B.B_WPL_cnt_reset = true;
      break;

     case KitGewer_IN_Stationsentscheider:
      /* During 'Stationsentscheider': '<S17>:214' */
      /* Transition: '<S17>:221' */
      KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk2_v14_IN_A_stern_fahrt;

      /* Entry Internal 'A_stern_fahrt': '<S17>:207' */
      /* Transition: '<S17>:317' */
      KitGewerk2_v14_DW.is_A_stern_fahrt = KitGewerk2_v14_IN_A_stern;
      break;

     case KitGewerk_IN_Warten_auf_Auftrag:
      /* During 'Warten_auf_Auftrag': '<S17>:286' */
      exitg2 = ((KitGewerk2_v14_B.DataTypeConversion3_k == 200) &&
                (KitGewerk2_v14_B.DataTypeConversion1_f == 200));
      if (exitg2) {
        /* Transition: '<S17>:288' */
        KitGewerk2_v14_B.UI_to_GW1 = 200U;
        KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 =
          KitGewerk2_IN_Auftrag_empfangen;
      }
      break;

     default:
      KitGew_Warten_auf_neuen_Auftrag();
      break;
    }
  }

  /* End of Chart: '<S5>/Chart' */
  /* RateTransition: '<S34>/Rate Transition1' */
  KitGewerk2_v14_B.RateTransition1_g = KitGewerk2_v14_B.FIFOwrite1_c;

  /* Level2 S-Function Block: '<S34>/FIFO read 1' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[20];
    sfcnOutputs(rts, 0);
  }

  /* DataTypeConversion: '<S24>/Data Type Conversion2' */
  KitGewerk2_v14_B.DataTypeConversion2_d[0] = (uint8_T)
    KitGewerk2_v14_B.FIFOread1_j[0];
  KitGewerk2_v14_B.DataTypeConversion2_d[1] = (uint8_T)
    KitGewerk2_v14_B.FIFOread1_j[1];
  KitGewerk2_v14_B.DataTypeConversion2_d[2] = (uint8_T)
    KitGewerk2_v14_B.FIFOread1_j[2];
  KitGewerk2_v14_B.DataTypeConversion2_d[3] = (uint8_T)
    KitGewerk2_v14_B.FIFOread1_j[3];

  /* Memory: '<S24>/Previous Flag' */
  KitGewerk2_v14_B.PreviousFlag = KitGewerk2_v14_DW.PreviousFlag_PreviousInput;

  /* DataTypeConversion: '<S24>/Data Type Conversion' */
  KitGewerk2_v14_B.DataTypeConversion_c = KitGewerk2_v14_B.PreviousFlag;

  /* Memory: '<S24>/Previous SOC' */
  KitGewerk2_v14_B.PreviousSOC = KitGewerk2_v14_DW.PreviousSOC_PreviousInput;

  /* DataTypeConversion: '<S24>/Data Type Conversion1' */
  KitGewerk2_v14_B.DataTypeConversion1_fj = KitGewerk2_v14_B.PreviousSOC;

  /* MATLAB Function: '<S24>/Microcontroller Data' */
  /* MATLAB Function 'Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Microcontroller Data': '<S35>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Error check of the 'I/O-Board to PC104 message' and filtering of this   % */
  /*  defective response: Substitute defective message by the last error free % */
  /*  message.                                                                % */
  /*  Saving of the rotating direction, velocity, shaft position and running  % */
  /*  time of the three motors. Combining all shaft positions in a vector.    % */
  /*  Combining all running times in a vector.                                % */
  /*  Saving of the three bumper bytes indicating a collision in a vector.    % */
  /*  Saving the values of the nine distance measuring IR-sensors in a vector.% */
  /*                                                                          % */
  /*  inputs: response (actual 'I/O-Board to PC104 message')(vector 102       % */
  /*                    elements)                                             % */
  /*          error_free_resp_in (last error free 'I/O-Board to PC104         % */
  /*                              message')                                   % */
  /*  outputs: directions and velocities of the three motors                  % */
  /*           motor_positions_out (shaft positions of the three motors)      % */
  /*                               (vector 12 elements)                       % */
  /*           time_bytes_out (running times of the three motors)             % */
  /*                          (vector 9 elements)                             % */
  /*           distance_measuring_sensors_out (values of the nine IR-sensors) % */
  /*                                          (vector 9 elements)             % */
  /*           bumper_out (vector 3 elements)                                 % */
  /*           error_free_resp_out (error free 'I/O-Board to PC104 message')  % */
  /*                               (vector 102 elements)                      % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S35>:1:29' */
  FLAG = KitGewerk2_v14_B.DataTypeConversion2_d[2];

  /* '<S35>:1:30' */
  SOC = KitGewerk2_v14_B.DataTypeConversion2_d[1];
  if (KitGewerk2_v14_B.DataTypeConversion2_d[1] > 106) {
    /* '<S35>:1:34' */
    /* '<S35>:1:35' */
    SOC = KitGewerk2_v14_B.DataTypeConversion1_fj;
  }

  if (KitGewerk2_v14_B.DataTypeConversion2_d[2] > 6) {
    /* '<S35>:1:38' */
    /* '<S35>:1:39' */
    FLAG = KitGewerk2_v14_B.DataTypeConversion_c;
  }

  /*            motor_positions_out, time_bytes_out, ...) */
  KitGewerk2_v14_B.SOC_a = SOC;
  KitGewerk2_v14_B.FLAG = FLAG;

  /* End of MATLAB Function: '<S24>/Microcontroller Data' */

  /* DataTypeConversion: '<S24>/Data Type Conversion3' */
  KitGewerk2_v14_B.DataTypeConversion3 = KitGewerk2_v14_B.FLAG;

  /* MATLAB Function: '<S26>/Flag Communication Simulation' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  /* MATLAB Function 'Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Flag Communication Simulation': '<S29>:1' */
  if (KitGewerk2_v14_P.Constant2_Value_p == 1) {
    /* '<S29>:1:3' */
    /* '<S29>:1:4' */
    KitGewerk2_v14_B.Output_Flag = 1.0;
  } else if (KitGewerk2_v14_P.Constant2_Value_p == 2) {
    /* '<S29>:1:6' */
    /* '<S29>:1:7' */
    KitGewerk2_v14_B.Output_Flag = 2.0;
  } else {
    /* '<S29>:1:10' */
    KitGewerk2_v14_B.Output_Flag = 0.0;
  }

  /* End of MATLAB Function: '<S26>/Flag Communication Simulation' */

  /* Step: '<S9>/Step' */
  v0 = KitGewerk2_v14_M->Timing.t[0];
  if (v0 < KitGewerk2_v14_P.Step_Time) {
    KitGewerk2_v14_B.Step = KitGewerk2_v14_P.Step_Y0;
  } else {
    KitGewerk2_v14_B.Step = KitGewerk2_v14_P.Step_YFinal;
  }

  /* End of Step: '<S9>/Step' */

  /* Outputs for Triggered SubSystem: '<S9>/getIDfromFlash' incorporates:
   *  TriggerPort: '<S57>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &KitGewerk2_v14_PrevZCX.getIDfromFlash_Trig_ZCE,
                     (KitGewerk2_v14_B.Step));
  if (zcEvent != NO_ZCEVENT) {
    /* Level2 S-Function Block: '<S57>/From File' (xpcfromfile) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[17];
      sfcnOutputs(rts, 1);
    }

    /* Unpack: <S57>/Unpack */
    (void) memcpy(&KitGewerk2_v14_B.Unpack_o, &KitGewerk2_v14_B.FromFile[0],
                  8);
    KitGewerk2_v14_DW.getIDfromFlash_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S9>/getIDfromFlash' */

  /* MATLAB Function: '<S6>/Output_Flag-Comparison: Blei oder Li-ION' */
  /* MATLAB Function 'Power Management Gewerk 4/Output_Flag-Comparison: Blei oder Li-ION': '<S22>:1' */
  if ((KitGewerk2_v14_B.Unpack_o == 4.0) || (KitGewerk2_v14_B.Unpack_o == 3.0))
  {
    /* '<S22>:1:3' */
    /* '<S22>:1:4' */
    KitGewerk2_v14_B.Output_Flag_d = KitGewerk2_v14_B.DataTypeConversion3;
  } else {
    /* '<S22>:1:6' */
    KitGewerk2_v14_B.Output_Flag_d = KitGewerk2_v14_B.Output_Flag;
  }

  /* End of MATLAB Function: '<S6>/Output_Flag-Comparison: Blei oder Li-ION' */

  /* DataTypeConversion: '<S24>/Data Type Conversion4' */
  KitGewerk2_v14_B.DataTypeConversion4 = KitGewerk2_v14_B.SOC_a;

  /* MATLAB Function: '<S26>/Unterscheidung Blei Gel Roboter an der virtuellen Ladestation' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  /* MATLAB Function 'Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Unterscheidung Blei Gel Roboter an der virtuellen Ladestation': '<S33>:1' */
  if (KitGewerk2_v14_P.Constant2_Value_p == 1) {
    /* '<S33>:1:3' */
    /* '<S33>:1:5' */
    KitGewerk2_v14_B.Laden = 1.0;
  } else {
    /* '<S33>:1:9' */
    KitGewerk2_v14_B.Laden = 0.0;
  }

  /* End of MATLAB Function: '<S26>/Unterscheidung Blei Gel Roboter an der virtuellen Ladestation' */

  /* DataTypeConversion: '<S26>/Data Type Conversion3' */
  KitGewerk2_v14_B.DataTypeConversion3_j = KitGewerk2_v14_B.Laden;

  /* Memory: '<S26>/Memory' */
  KitGewerk2_v14_B.Memory = KitGewerk2_v14_DW.Memory_PreviousInput;

  /* MATLAB Function: '<S26>/MATLAB Function' */
  /* MATLAB Function 'Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/MATLAB Function': '<S30>:1' */
  if (KitGewerk2_v14_B.Memory >= 3000) {
    /* '<S30>:1:3' */
    /* '<S30>:1:4' */
    KitGewerk2_v14_B.y_k = 0.0;
  } else {
    /* '<S30>:1:6' */
    KitGewerk2_v14_B.y_k = KitGewerk2_v14_B.Laden;
  }

  /* End of MATLAB Function: '<S26>/MATLAB Function' */

  /* RelationalOperator: '<S28>/Compare' incorporates:
   *  Constant: '<S28>/Constant'
   */
  KitGewerk2_v14_B.Compare_o = (KitGewerk2_v14_B.Laden <=
    KitGewerk2_v14_P.Constant_Value);

  /* S-Function (sdspcount2): '<S26>/Charging Counter' */
  if (KitGewerk2_v14_B.Compare_o) {
    KitGewerk2_v14_DW.ChargingCounter_Count =
      KitGewerk2_v14_P.ChargingCounter_InitialCount;
  }

  if (KitGewerk2_v14_B.y_k != 0.0) {
    if (KitGewerk2_v14_DW.ChargingCounter_Count < ((uint16_T)3002U)) {
      KitGewerk2_v14_DW.ChargingCounter_Count++;
    } else {
      KitGewerk2_v14_DW.ChargingCounter_Count = 0U;
    }
  }

  KitGewerk2_v14_B.ChargingCounter = KitGewerk2_v14_DW.ChargingCounter_Count;

  /* End of S-Function (sdspcount2): '<S26>/Charging Counter' */

  /* Gain: '<S26>/Gain1' */
  KitGewerk2_v14_B.Gain1 = (uint32_T)KitGewerk2_v14_P.Gain1_Gain *
    KitGewerk2_v14_B.ChargingCounter;

  /* DataTypeConversion: '<S26>/Data Type Conversion2' */
  KitGewerk2_v14_B.DataTypeConversion2 = (real_T)KitGewerk2_v14_B.Gain1 *
    9.5367431640625E-7;

  /* Memory: '<S26>/Memory1' */
  KitGewerk2_v14_B.Memory1 = KitGewerk2_v14_DW.Memory1_PreviousInput;

  /* RelationalOperator: '<S27>/Compare' incorporates:
   *  Constant: '<S27>/Constant'
   */
  KitGewerk2_v14_B.Compare = (uint8_T)(KitGewerk2_v14_B.Laden <=
    KitGewerk2_v14_P.Constant_Value_b);

  /* MATLAB Function: '<S26>/MATLAB Function1' */
  /* MATLAB Function 'Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/MATLAB Function1': '<S31>:1' */
  if (KitGewerk2_v14_B.Memory1 <= 2U) {
    /* '<S31>:1:3' */
    /* '<S31>:1:4' */
    KitGewerk2_v14_B.y = 0.0;
  } else {
    /* '<S31>:1:6' */
    KitGewerk2_v14_B.y = KitGewerk2_v14_B.Compare;
  }

  /* End of MATLAB Function: '<S26>/MATLAB Function1' */

  /* S-Function (sdspcount2): '<S26>/Discharging Counter' */
  if (KitGewerk2_v14_B.Laden != 0.0) {
    KitGewerk2_v14_DW.DischargingCounter_Count =
      KitGewerk2_v14_P.DischargingCounter_InitialCount;
  }

  if (KitGewerk2_v14_B.y != 0.0) {
    if (KitGewerk2_v14_DW.DischargingCounter_Count > 0U) {
      KitGewerk2_v14_DW.DischargingCounter_Count--;
    } else {
      KitGewerk2_v14_DW.DischargingCounter_Count = 180002U;
    }
  }

  KitGewerk2_v14_B.DischargingCounter =
    KitGewerk2_v14_DW.DischargingCounter_Count;

  /* End of S-Function (sdspcount2): '<S26>/Discharging Counter' */

  /* Sum: '<S26>/Sum' incorporates:
   *  Constant: '<S26>/Constant2'
   */
  KitGewerk2_v14_B.Sum = (real_T)KitGewerk2_v14_B.DischargingCounter +
    KitGewerk2_v14_P.Constant2_Value_g;

  /* Gain: '<S26>/Gain' */
  KitGewerk2_v14_B.Gain = KitGewerk2_v14_P.Gain_Gain * KitGewerk2_v14_B.Sum;

  /* DataTypeConversion: '<S26>/Data Type Conversion1' */
  KitGewerk2_v14_B.DataTypeConversion1 = KitGewerk2_v14_B.Gain;

  /* MATLAB Function: '<S26>/Relais ansteuern1' */
  /* MATLAB Function 'Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Relais ansteuern1': '<S32>:1' */
  if (KitGewerk2_v14_B.DataTypeConversion3_j == 1.0) {
    /* '<S32>:1:3' */
    /* '<S32>:1:4' */
    KitGewerk2_v14_B.SOC = KitGewerk2_v14_B.DataTypeConversion2;
  } else {
    /* '<S32>:1:6' */
    KitGewerk2_v14_B.SOC = KitGewerk2_v14_B.DataTypeConversion1;
  }

  /* End of MATLAB Function: '<S26>/Relais ansteuern1' */

  /* MATLAB Function: '<S6>/SOC-Comparison: Blei oder Li-ION' */
  /* MATLAB Function 'Power Management Gewerk 4/SOC-Comparison: Blei oder Li-ION': '<S25>:1' */
  if ((KitGewerk2_v14_B.Unpack_o == 4.0) || (KitGewerk2_v14_B.Unpack_o == 3.0))
  {
    /* '<S25>:1:3' */
    /* '<S25>:1:4' */
    KitGewerk2_v14_B.Output_SOC = KitGewerk2_v14_B.DataTypeConversion4;
  } else {
    /* '<S25>:1:6' */
    KitGewerk2_v14_B.Output_SOC = KitGewerk2_v14_B.SOC;
  }

  /* End of MATLAB Function: '<S6>/SOC-Comparison: Blei oder Li-ION' */

  /* MATLAB Function: '<S5>/Kollisionserkennung' incorporates:
   *  Constant: '<S5>/Bremsabstand'
   */
  /* MATLAB Function 'Gewerk_2/Kollisionserkennung': '<S18>:1' */
  /* '<S18>:1:2' */
  KitGewerk2_v14_B.b_stop = false;
  for (i = 0; i < 9; i++) {
    /* Selector: '<S15>/Auswahl6' incorporates:
     *  Constant: '<S15>/Konstante f�r die Abstandssensoren'
     */
    KitGewerk2_v14_B.Auswahl6[i] = KitGewerk2_v14_B.robotino_response[(int32_T)
      KitGewerk2_v14_P.KonstantefrdieAbstandssensoren_[i] - 1];
    b[i] = rtIsNaN(KitGewerk2_v14_B.Auswahl6[i]);
  }

  v0 = b[0];
  for (k = 0; k < 8; k++) {
    v0 += (real_T)b[k + 1];
  }

  if (v0 == 9.0) {
    /* '<S18>:1:3' */
    /*  nan = kein Hinderniss */
    /*  kein Hinderniss    */
    /* '<S18>:1:5' */
    KitGewerk2_v14_B.b_stop = false;
  } else {
    /*  Hinderniss entdeckt, min. ein Sensor(kein nan) */
    if ((KitGewerk2_v14_B.Auswahl6[0] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[1] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[2] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[3] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[4] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[5] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[6] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[7] < KitGewerk2_v14_P.Bremsabstand_Value) ||
        (KitGewerk2_v14_B.Auswahl6[8] < KitGewerk2_v14_P.Bremsabstand_Value)) {
      /* '<S18>:1:8' */
      /* '<S18>:1:9' */
      /* '<S18>:1:10' */
      /* '<S18>:1:12' */
      KitGewerk2_v14_B.b_stop = true;
    }
  }

  /* End of MATLAB Function: '<S5>/Kollisionserkennung' */

  /* DataTypeConversion: '<S5>/Data Type Conversion' */
  KitGewerk2_v14_B.DataTypeConversion_l = KitGewerk2_v14_B.B_Stop;

  /* RelationalOperator: '<S5>/Relational Operator' */
  KitGewerk2_v14_B.RelationalOperator = ((int32_T)KitGewerk2_v14_B.b_stop <=
    (int32_T)KitGewerk2_v14_B.DataTypeConversion_l);

  /* DataTypeConversion: '<Root>/Data Type Conversion' */
  KitGewerk2_v14_B.DataTypeConversion = KitGewerk2_v14_B.RelationalOperator;

  /* Sum: '<Root>/Add' incorporates:
   *  Constant: '<Root>/Constant'
   */
  KitGewerk2_v14_B.Add = KitGewerk2_v14_P.Constant_Value_g -
    KitGewerk2_v14_B.DataTypeConversion;

  /* Gain: '<Root>/Gain' */
  KitGewerk2_v14_B.Gain_b = KitGewerk2_v14_P.Gain_Gain_c * KitGewerk2_v14_B.Add;

  /* MATLAB Function: '<Root>/Begrenzung' */
  /* MATLAB Function 'Begrenzung': '<S1>:1' */
  if (KitGewerk2_v14_B.Gain_b > 500.0) {
    /* '<S1>:1:3' */
    /* '<S1>:1:4' */
    v0 = 500.0;
  } else {
    /* '<S1>:1:6' */
    v0 = KitGewerk2_v14_B.Gain_b;
  }

  /* '<S1>:1:8' */
  KitGewerk2_v14_B.wout_m = v0;

  /* End of MATLAB Function: '<Root>/Begrenzung' */

  /* MATLAB Function: '<Root>/Begrenzung1' incorporates:
   *  Constant: '<Root>/Constant4'
   */
  /* MATLAB Function 'Begrenzung1': '<S2>:1' */
  if (KitGewerk2_v14_P.Constant4_Value > 500.0) {
    /* '<S2>:1:3' */
    /* '<S2>:1:4' */
    v0 = 500.0;
  } else {
    /* '<S2>:1:6' */
    v0 = KitGewerk2_v14_P.Constant4_Value;
  }

  /* '<S2>:1:8' */
  KitGewerk2_v14_B.wout_p = v0;

  /* End of MATLAB Function: '<Root>/Begrenzung1' */

  /* MATLAB Function: '<Root>/Begrenzung2' incorporates:
   *  Constant: '<Root>/constant1'
   */
  /* MATLAB Function 'Begrenzung2': '<S3>:1' */
  if (KitGewerk2_v14_P.constant1_Value > 3.0) {
    /* '<S3>:1:3' */
    /* '<S3>:1:4' */
    v0 = 3.0;
  } else {
    /* '<S3>:1:6' */
    v0 = KitGewerk2_v14_P.constant1_Value;
  }

  /* '<S3>:1:8' */
  KitGewerk2_v14_B.wout = v0;

  /* End of MATLAB Function: '<Root>/Begrenzung2' */

  /* DataTypeConversion: '<S4>/Data Type Conversion5' */
  KitGewerk2_v14_B.DataTypeConversion5 = KitGewerk2_v14_B.Unpack_o5;

  /* DataTypeConversion: '<S4>/Data Type Conversion6' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  KitGewerk2_v14_B.DataTypeConversion6 = KitGewerk2_v14_P.Constant1_Value_n;

  /* DataTypeConversion: '<S4>/Data Type Conversion7' */
  KitGewerk2_v14_B.DataTypeConversion7 = KitGewerk2_v14_B.UI_to_GW1;

  /* DataTypeConversion: '<Root>/Data Type Conversion1' incorporates:
   *  Constant: '<Root>/Constant3'
   */
  KitGewerk2_v14_B.DataTypeConversion1_o = KitGewerk2_v14_P.Constant3_Value_j;

  /* DataTypeConversion: '<S4>/Data Type Conversion8' */
  KitGewerk2_v14_B.DataTypeConversion8 = KitGewerk2_v14_B.DataTypeConversion1_o;

  /* DataTypeConversion: '<S4>/Data Type Conversion9' */
  KitGewerk2_v14_B.DataTypeConversion9 = KitGewerk2_v14_B.DataTypeConversion4_d;

  /* Pack: <S4>/Pack */
  (void) memcpy(&KitGewerk2_v14_B.Pack[0], &KitGewerk2_v14_B.DataTypeConversion7,
                1);
  (void) memcpy(&KitGewerk2_v14_B.Pack[1], &KitGewerk2_v14_B.DataTypeConversion8,
                1);
  (void) memcpy(&KitGewerk2_v14_B.Pack[2], &KitGewerk2_v14_B.DataTypeConversion9,
                1);
  (void) memcpy(&KitGewerk2_v14_B.Pack[3], &KitGewerk2_v14_B.DataTypeConversion6,
                1);

  /* RateTransition: '<S10>/Rate Transition down-sampling to 500ms' */
  if (KitGewerk2_v14_M->Timing.RateInteraction.TID1_2) {
    KitGewerk2_v14_B.RateTransitiondownsamplingto500 = KitGewerk2_v14_B.Unpack_o;

    /* RateTransition: '<S10>/Rate Transition down-sampling to 500 ms' */
    KitGewerk2_v14_B.RateTransitiondownsamplingto5_o[0] = KitGewerk2_v14_B.Pack
      [0];
    KitGewerk2_v14_B.RateTransitiondownsamplingto5_o[1] = KitGewerk2_v14_B.Pack
      [1];
    KitGewerk2_v14_B.RateTransitiondownsamplingto5_o[2] = KitGewerk2_v14_B.Pack
      [2];
    KitGewerk2_v14_B.RateTransitiondownsamplingto5_o[3] = KitGewerk2_v14_B.Pack
      [3];
  }

  /* End of RateTransition: '<S10>/Rate Transition down-sampling to 500ms' */

  /* S-Function (sdspcount2): '<S5>/Counter' incorporates:
   *  Constant: '<Root>/constant2'
   */
  KitGewerk2_v14_B.Counter_o2 = false;
  if (MWDSP_EPH_R_B(KitGewerk2_v14_P.constant2_Value,
                    &KitGewerk2_v14_DW.Counter_ClkEphState) != 0U) {
    if (KitGewerk2_v14_DW.Counter_Count < ((uint8_T)49U)) {
      KitGewerk2_v14_DW.Counter_Count++;
    } else {
      KitGewerk2_v14_DW.Counter_Count = 0U;
    }
  }

  KitGewerk2_v14_B.Counter_o1 = KitGewerk2_v14_DW.Counter_Count;
  if (KitGewerk2_v14_DW.Counter_Count == KitGewerk2_v14_P.Counter_HitValue) {
    KitGewerk2_v14_B.Counter_o2 = true;
  }

  /* End of S-Function (sdspcount2): '<S5>/Counter' */

  /* MATLAB Function: '<S5>/MATLAB Function' */
  /* MATLAB Function 'Gewerk_2/MATLAB Function': '<S19>:1' */
  /* '<S19>:1:3' */
  i = KitGewerk2_v14_B.Counter_o1;
  k = i + 1;
  if ((i > 0) && (k <= 0)) {
    k = MAX_int32_T;
  }

  i = k - 1;

  /* Offset, da Zeilenindex bei 1 beginnt */
  if ((KitGewerk2_v14_B.A_WPL[i] < 0.0) || (KitGewerk2_v14_B.A_WPL[50 + i] < 0.0)
      || (KitGewerk2_v14_B.A_WPL[100 + i] < 0.0) || (KitGewerk2_v14_B.A_WPL[150
       + i] < 0.0)) {
    /* '<S19>:1:7' */
    /* '<S19>:1:8' */
    i--;
  }

  /* '<S19>:1:11' */
  KitGewerk2_v14_B.d_Y_soll = KitGewerk2_v14_B.A_WPL[i];

  /* '<S19>:1:12' */
  KitGewerk2_v14_B.d_X_soll = KitGewerk2_v14_B.A_WPL[50 + i];

  /* '<S19>:1:13' */
  KitGewerk2_v14_B.d_Phi_soll = KitGewerk2_v14_B.A_WPL[100 + i];

  /* '<S19>:1:14' */
  KitGewerk2_v14_B.d_V_Max_soll = KitGewerk2_v14_B.A_WPL[150 + i];

  /* End of MATLAB Function: '<S5>/MATLAB Function' */

  /* Selector: '<S15>/Auswahl1' incorporates:
   *  Constant: '<S15>/Konstante f�r den Lichtschranke'
   */
  KitGewerk2_v14_B.Auswahl1 = KitGewerk2_v14_B.robotino_response[(int32_T)
    KitGewerk2_v14_P.KonstantefrdenLichtschranke_Val - 1];

  /* Selector: '<S15>/Auswahl2' incorporates:
   *  Constant: '<S15>/Konstante f�r den Schieber'
   */
  KitGewerk2_v14_B.Auswahl2 = KitGewerk2_v14_B.robotino_response[(int32_T)
    KitGewerk2_v14_P.KonstantefrdenSchieber_Value - 1];

  /* Selector: '<S15>/Auswahl3' incorporates:
   *  Constant: '<S15>/Konstante f�r den L�ngsgeschwindigkeit'
   */
  KitGewerk2_v14_B.Auswahl3 = KitGewerk2_v14_B.robotino_response[(int32_T)
    KitGewerk2_v14_P.KonstantefrdenLngsgeschwindigke - 1];

  /* Selector: '<S15>/Auswahl4' incorporates:
   *  Constant: '<S15>/Konstante f�r den Quergeschwindigkeit1'
   */
  KitGewerk2_v14_B.Auswahl4 = KitGewerk2_v14_B.robotino_response[(int32_T)
    KitGewerk2_v14_P.KonstantefrdenQuergeschwindigke - 1];

  /* Selector: '<S15>/Auswahl5' incorporates:
   *  Constant: '<S15>/Konstante f�r den Rotationegeschwindigkeit'
   */
  KitGewerk2_v14_B.Auswahl5 = KitGewerk2_v14_B.robotino_response[(int32_T)
    KitGewerk2_v14_P.KonstantefrdenRotationegeschwin - 1];

  /* Selector: '<S15>/Auswahl7' incorporates:
   *  Constant: '<S15>/Konstante f�r Kollision '
   */
  KitGewerk2_v14_B.Auswahl7 = KitGewerk2_v14_B.robotino_response[(int32_T)
    KitGewerk2_v14_P.KonstantefrKollision_Value - 1];

  /* DataTypeConversion: '<S5>/Data Type Conversion1' */
  KitGewerk2_v14_B.DataTypeConversion1_i = KitGewerk2_v14_B.B_Greifer;

  /* Selector: '<S16>/Auswahl1' incorporates:
   *  Constant: '<S16>/Kamera X Y Roboter 1'
   */
  KitGewerk2_v14_B.Auswahl1_h[0] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter1_Value[0] - 1];
  KitGewerk2_v14_B.Auswahl1_h[1] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter1_Value[1] - 1];
  KitGewerk2_v14_B.Auswahl1_h[2] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter1_Value[2] - 1];

  /* Selector: '<S16>/Auswahl10' incorporates:
   *  Constant: '<S16>/�bermittelung Koordinaten Kons.'
   */
  for (i = 0; i < 20; i++) {
    KitGewerk2_v14_B.Auswahl10[i] = KitGewerk2_v14_B.Unpack[(int32_T)
      KitGewerk2_v14_P.bermittelungKoordinatenKons_Val[i] - 1];
  }

  /* End of Selector: '<S16>/Auswahl10' */

  /* Selector: '<S16>/Auswahl2' incorporates:
   *  Constant: '<S16>/Kamera X Y Roboter 2'
   */
  KitGewerk2_v14_B.Auswahl2_e[0] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter2_Value[0] - 1];
  KitGewerk2_v14_B.Auswahl2_e[1] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter2_Value[1] - 1];
  KitGewerk2_v14_B.Auswahl2_e[2] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter2_Value[2] - 1];

  /* Selector: '<S16>/Auswahl3' incorporates:
   *  Constant: '<S16>/Kamera X Y Roboter 3'
   */
  KitGewerk2_v14_B.Auswahl3_m[0] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter3_Value[0] - 1];
  KitGewerk2_v14_B.Auswahl3_m[1] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter3_Value[1] - 1];
  KitGewerk2_v14_B.Auswahl3_m[2] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter3_Value[2] - 1];

  /* Selector: '<S16>/Auswahl4' incorporates:
   *  Constant: '<S16>/Kamera X Y Roboter 4'
   */
  KitGewerk2_v14_B.Auswahl4_i[0] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter4_Value[0] - 1];
  KitGewerk2_v14_B.Auswahl4_i[1] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter4_Value[1] - 1];
  KitGewerk2_v14_B.Auswahl4_i[2] = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.KameraXYRoboter4_Value[2] - 1];

  /* Selector: '<S16>/Auswahl5' incorporates:
   *  Constant: '<S16>/Zeitstempel'
   */
  KitGewerk2_v14_B.Auswahl5_m = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.Zeitstempel_Value - 1];

  /* Selector: '<S16>/Auswahl6' incorporates:
   *  Constant: '<S16>/Zeitstempel1'
   */
  KitGewerk2_v14_B.Auswahl6_k = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.Zeitstempel1_Value - 1];

  /* Selector: '<S16>/Auswahl7' incorporates:
   *  Constant: '<S16>/Zeitstempel2'
   */
  KitGewerk2_v14_B.Auswahl7_b = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.Zeitstempel2_Value - 1];

  /* Selector: '<S16>/Auswahl8' incorporates:
   *  Constant: '<S16>/Fahrerlaubnis Kons.'
   */
  KitGewerk2_v14_B.Auswahl8 = KitGewerk2_v14_B.Unpack[(int32_T)
    KitGewerk2_v14_P.FahrerlaubnisKons_Value - 1];

  /* Selector: '<S16>/Auswahl9' incorporates:
   *  Constant: '<S16>/Camera Variablen Konst.'
   */
  for (i = 0; i < 8; i++) {
    KitGewerk2_v14_B.Auswahl9[i] = KitGewerk2_v14_B.Unpack[(int32_T)
      KitGewerk2_v14_P.CameraVariablenKonst_Value[i] - 1];
  }

  /* End of Selector: '<S16>/Auswahl9' */

  /* Constant: '<S5>/Wegpunktliste zum Testen' */
  memcpy(&KitGewerk2_v14_B.WegpunktlistezumTesten[0],
         &KitGewerk2_v14_P.WegpunktlistezumTesten_Value[0], 68U * sizeof(real_T));

  /* DataTypeConversion: '<S24>/Data Type Conversion5' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  KitGewerk2_v14_B.DataTypeConversion5_i = KitGewerk2_v14_P.Constant2_Value_p;

  /* Level2 S-Function Block: '<S34>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[21];
    sfcnOutputs(rts, 0);
  }

  /* S-Function Block: <S34>/Enable TX 1 (sertxenablebase) */
  if (KitGewerk2_v14_B.FIFOwrite1_o2 == 1 ) {
    uint8_T reg = (uint8_T)xpcInpB( (unsigned short)(760 + IER) ) & 0xff;
    xpcOutpB( (unsigned short)(760 + IER), (uint8_T)(reg & ~IERXMT) );
    reg |= IERXMT;
    xpcOutpB( (unsigned short)(760 + IER), reg );
  }

  /* Level2 S-Function Block: '<S34>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[22];
    sfcnOutputs(rts, 0);
  }

  /* RateTransition: '<S34>/Rate Transition3' */
  KitGewerk2_v14_B.RateTransition3 = KitGewerk2_v14_B.FIFOwrite2_a;

  /* Level2 S-Function Block: '<S34>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[23];
    sfcnOutputs(rts, 0);
  }

  /* Level2 S-Function Block: '<S34>/Setup1' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[24];
    sfcnOutputs(rts, 0);
  }

  /* Level2 S-Function Block: '<S34>/Setup2' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[25];
    sfcnOutputs(rts, 0);
  }

  /* Gain: '<S7>/Gain' */
  KitGewerk2_v14_B.Gain_o = KitGewerk2_v14_P.Gain_Gain_k *
    KitGewerk2_v14_B.DataTypeConversion1_i;

  /* MATLAB Function: '<S7>/transmit velocity, unit & direction converter' */
  /* MATLAB Function 'Robotino/transmit velocity, unit & direction converter': '<S46>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  conversion from positive and/or negative longitudinal, lateral and      % */
  /*  rotational velocities (in milimeters per second) to three separate      % */
  /*  positive motor velocities (resolution: 1Byte) and their rotation        % */
  /*  direction                                                               % */
  /*                                                                          % */
  /*  inputs:  v_x_in (longitudinal velocity in milimeters per second),       % */
  /*           v_y_in (lateral velocity in milimeters per second),            % */
  /*           v_theta_in (rotational velocity in milimeters per second)      % */
  /*  outputs: direction_motor0_out (rotating direction of motor0             % */
  /*           (0 := counter-clockwise; 2 := clockwise)),                     % */
  /*           velocity_motor0_out (from 0 to 255),                           % */
  /*           direction_motor1_out (rotating direction of motor1             % */
  /*           (0 := counter-clockwise; 2 := clockwise)),                     % */
  /*           velocity_motor1_out (from 0 to 255),                           % */
  /*           direction_motor2_out (rotating direction of motor2             % */
  /*           (0 := counter-clockwise; 2 := clockwise)),                     % */
  /*           velocity_motor2_out (from 0 to 255)                            % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  conversion from longitudinal, lateral & rotational velocity to the % */
  /*  three separate motor velocities                                    % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S46>:1:28' */
  /* '<S46>:1:29' */
  /* '<S46>:1:30' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  conversion of the separate motor velocities from millimeters to a % */
  /*  value between -255 and 255                                        % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S46>:1:37' */
  v0 = ((-KitGewerk2_v14_B.wout_m * 0.86602540378443871 +
         KitGewerk2_v14_B.wout_p * 0.49999999999999994) + KitGewerk2_v14_B.wout *
        135.0) * 0.14245014245014245;

  /* '<S46>:1:38' */
  v1 = (KitGewerk2_v14_B.wout * 135.0 + -KitGewerk2_v14_B.wout_p) *
    0.14245014245014245;

  /* '<S46>:1:39' */
  v2 = ((KitGewerk2_v14_B.wout_m * 0.86602540378443871 + KitGewerk2_v14_B.wout_p
         * 0.49999999999999994) + KitGewerk2_v14_B.wout * 135.0) *
    0.14245014245014245;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  division of motor velocities into absolute velocity and rotating % */
  /*  direction                                                        % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  if (v0 < 0.0) {
    /* '<S46>:1:45' */
    /* '<S46>:1:46' */
    KitGewerk2_v14_B.direction_motor0_out = 0.0;

    /* '<S46>:1:47' */
    KitGewerk2_v14_B.velocity_motor0_out = -v0;
  } else {
    /* '<S46>:1:49' */
    KitGewerk2_v14_B.direction_motor0_out = 2.0;

    /* '<S46>:1:50' */
    KitGewerk2_v14_B.velocity_motor0_out = v0;
  }

  if (v1 < 0.0) {
    /* '<S46>:1:53' */
    /* '<S46>:1:54' */
    KitGewerk2_v14_B.direction_motor1_out = 0.0;

    /* '<S46>:1:55' */
    KitGewerk2_v14_B.velocity_motor1_out = -v1;
  } else {
    /* '<S46>:1:57' */
    KitGewerk2_v14_B.direction_motor1_out = 2.0;

    /* '<S46>:1:58' */
    KitGewerk2_v14_B.velocity_motor1_out = v1;
  }

  if (v2 < 0.0) {
    /* '<S46>:1:61' */
    /* '<S46>:1:62' */
    KitGewerk2_v14_B.direction_motor2_out = 0.0;

    /* '<S46>:1:63' */
    KitGewerk2_v14_B.velocity_motor2_out = -v2;
  } else {
    /* '<S46>:1:65' */
    KitGewerk2_v14_B.direction_motor2_out = 2.0;

    /* '<S46>:1:66' */
    KitGewerk2_v14_B.velocity_motor2_out = v2;
  }

  /* End of MATLAB Function: '<S7>/transmit velocity, unit & direction converter' */

  /* SignalConversion: '<S49>/TmpSignal ConversionAt SFunction Inport9' incorporates:
   *  Constant: '<Root>/constant'
   *  MATLAB Function: '<S45>/protocol adder & optional velocity adaption'
   */
  KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0] =
    KitGewerk2_v14_P.constant_Value;
  KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1] =
    KitGewerk2_v14_B.stop_out;

  /* MATLAB Function: '<S45>/protocol adder & optional velocity adaption' incorporates:
   *  Constant: '<S7>/Grabber velocity'
   */
  velocity_motor0_in = KitGewerk2_v14_B.velocity_motor0_out;
  velocity_motor1_in = KitGewerk2_v14_B.velocity_motor1_out;
  velocity_motor2_in = KitGewerk2_v14_B.velocity_motor2_out;

  /* MATLAB Function 'Robotino/serial communication/protocol adder & optional velocity adaption': '<S49>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  parameterising the 'PC104 to I/O-Board message' for serial line         % */
  /*  communication with control commands for the robotino motors             % */
  /*                                                                          % */
  /*  optional: velocity adaption as soon as at least one motor is near the   % */
  /*            speed limit                                                   % */
  /*                                                                          % */
  /*  inputs: rotating directions and velocities of the three motors          % */
  /*  output: vector containing the 'PC104 to I/O-Board message' for serial   % */
  /*          line communication                                              % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  optional velocity adaption % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S49>:1:18' */
  /*  v_motor_dez_max */
  if (KitGewerk2_v14_B.velocity_motor0_out > 175.0) {
    /* '<S49>:1:20' */
    /* '<S49>:1:21' */
    /* '<S49>:1:23' */
    velocity_motor0_in = 175.0;

    /* '<S49>:1:24' */
    velocity_motor1_in = 175.0 * KitGewerk2_v14_B.velocity_motor1_out /
      KitGewerk2_v14_B.velocity_motor0_out;

    /* '<S49>:1:25' */
    velocity_motor2_in = 175.0 * KitGewerk2_v14_B.velocity_motor2_out /
      KitGewerk2_v14_B.velocity_motor0_out;
  }

  if (velocity_motor1_in > 175.0) {
    /* '<S49>:1:28' */
    /* '<S49>:1:29' */
    v0 = velocity_motor1_in;

    /* '<S49>:1:31' */
    velocity_motor0_in = 175.0 * velocity_motor0_in / velocity_motor1_in;

    /* '<S49>:1:32' */
    velocity_motor1_in = 175.0;

    /* '<S49>:1:33' */
    velocity_motor2_in = 175.0 * velocity_motor2_in / v0;
  }

  if (velocity_motor2_in > 175.0) {
    /* '<S49>:1:36' */
    /* '<S49>:1:39' */
    velocity_motor0_in = 175.0 * velocity_motor0_in / velocity_motor2_in;

    /* '<S49>:1:40' */
    velocity_motor1_in = 175.0 * velocity_motor1_in / velocity_motor2_in;

    /* '<S49>:1:41' */
    velocity_motor2_in = 175.0;
  }

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  vector containing the 'PC104 to I/O-Board message' for serial line % */
  /*  communication                                                      % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S49>:1:47' */
  i = 1;
  v0 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0];
  if (rtIsNaN(KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0])) {
    low_ip1 = 2;
    exitg2 = false;
    while ((!exitg2) && (low_ip1 < 3)) {
      i = 2;
      if (!rtIsNaN(KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1])) {
        v0 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1];
        exitg2 = true;
      } else {
        low_ip1 = 3;
      }
    }
  }

  if ((i < 2) && (KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1] < v0)) {
    v0 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1];
  }

  i = 1;
  v1 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0];
  if (rtIsNaN(KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0])) {
    low_ip1 = 2;
    exitg2 = false;
    while ((!exitg2) && (low_ip1 < 3)) {
      i = 2;
      if (!rtIsNaN(KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1])) {
        v1 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1];
        exitg2 = true;
      } else {
        low_ip1 = 3;
      }
    }
  }

  if ((i < 2) && (KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1] < v1)) {
    v1 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1];
  }

  i = 1;
  v2 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0];
  if (rtIsNaN(KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0])) {
    low_ip1 = 2;
    exitg2 = false;
    while ((!exitg2) && (low_ip1 < 3)) {
      i = 2;
      if (!rtIsNaN(KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1])) {
        v2 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1];
        exitg2 = true;
      } else {
        low_ip1 = 3;
      }
    }
  }

  if ((i < 2) && (KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1] < v2)) {
    v2 = KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1];
  }

  KitGewerk2_v14_B.message[0] = 47.0;
  KitGewerk2_v14_B.message[1] = 82.0;
  KitGewerk2_v14_B.message[2] = 69.0;
  KitGewerk2_v14_B.message[3] = 67.0;
  KitGewerk2_v14_B.message[4] = 5.0;
  KitGewerk2_v14_B.message[5] = v0;
  KitGewerk2_v14_B.message[6] = KitGewerk2_v14_B.direction_motor0_out;
  KitGewerk2_v14_B.message[7] = velocity_motor0_in;
  KitGewerk2_v14_B.message[8] = 0.0;
  KitGewerk2_v14_B.message[9] = 0.0;
  KitGewerk2_v14_B.message[10] = 0.0;
  KitGewerk2_v14_B.message[11] = 0.0;
  KitGewerk2_v14_B.message[12] = 255.0;
  KitGewerk2_v14_B.message[13] = 255.0;
  KitGewerk2_v14_B.message[14] = 255.0;
  KitGewerk2_v14_B.message[15] = v1;
  KitGewerk2_v14_B.message[16] = KitGewerk2_v14_B.direction_motor1_out;
  KitGewerk2_v14_B.message[17] = velocity_motor1_in;
  KitGewerk2_v14_B.message[18] = 0.0;
  KitGewerk2_v14_B.message[19] = 0.0;
  KitGewerk2_v14_B.message[20] = 0.0;
  KitGewerk2_v14_B.message[21] = 0.0;
  KitGewerk2_v14_B.message[22] = 255.0;
  KitGewerk2_v14_B.message[23] = 255.0;
  KitGewerk2_v14_B.message[24] = 255.0;
  KitGewerk2_v14_B.message[25] = v2;
  KitGewerk2_v14_B.message[26] = KitGewerk2_v14_B.direction_motor2_out;
  KitGewerk2_v14_B.message[27] = velocity_motor2_in;
  KitGewerk2_v14_B.message[28] = 0.0;
  KitGewerk2_v14_B.message[29] = 0.0;
  KitGewerk2_v14_B.message[30] = 0.0;
  KitGewerk2_v14_B.message[31] = 0.0;
  KitGewerk2_v14_B.message[32] = 255.0;
  KitGewerk2_v14_B.message[33] = 255.0;
  KitGewerk2_v14_B.message[34] = 255.0;
  KitGewerk2_v14_B.message[35] = 1.0;
  KitGewerk2_v14_B.message[36] = KitGewerk2_v14_B.Gain_o;
  KitGewerk2_v14_B.message[37] = KitGewerk2_v14_P.Grabbervelocity_Value;
  KitGewerk2_v14_B.message[38] = 0.0;
  KitGewerk2_v14_B.message[39] = 0.0;
  KitGewerk2_v14_B.message[40] = 0.0;
  KitGewerk2_v14_B.message[41] = 0.0;
  KitGewerk2_v14_B.message[42] = 255.0;
  KitGewerk2_v14_B.message[43] = 255.0;
  KitGewerk2_v14_B.message[44] = 255.0;
  KitGewerk2_v14_B.message[45] = 114.0;
  KitGewerk2_v14_B.message[46] = 101.0;
  KitGewerk2_v14_B.message[47] = 99.0;

  /* DataTypeConversion: '<S45>/double to uint16' */
  for (i = 0; i < 48; i++) {
    v0 = KitGewerk2_v14_B.message[i];
    v1 = fabs(v0);
    if (v1 < 4.503599627370496E+15) {
      if (v1 >= 0.5) {
        v0 = floor(v0 + 0.5);
      } else {
        v0 *= 0.0;
      }
    }

    if (rtIsNaN(v0) || rtIsInf(v0)) {
      v0 = 0.0;
    } else {
      v0 = fmod(v0, 65536.0);
    }

    KitGewerk2_v14_B.doubletouint16[i] = (uint16_T)(v0 < 0.0 ? (int32_T)
      (uint16_T)-(int16_T)(uint16_T)-v0 : (int32_T)(uint16_T)v0);
  }

  /* End of DataTypeConversion: '<S45>/double to uint16' */

  /* Level2 S-Function Block: '<S47>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[26];
    sfcnOutputs(rts, 0);
  }

  /* S-Function Block: <S47>/Enable TX 1 (sertxenablebase) */
  if (KitGewerk2_v14_B.FIFOwrite1_o2_n == 1 ) {
    uint8_T reg = (uint8_T)xpcInpB( (unsigned short)(1016 + IER) ) & 0xff;
    xpcOutpB( (unsigned short)(1016 + IER), (uint8_T)(reg & ~IERXMT) );
    reg |= IERXMT;
    xpcOutpB( (unsigned short)(1016 + IER), reg );
  }

  /* Level2 S-Function Block: '<S47>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[27];
    sfcnOutputs(rts, 0);
  }

  /* RateTransition: '<S47>/Rate Transition3' */
  KitGewerk2_v14_B.RateTransition3_e = KitGewerk2_v14_B.FIFOwrite2;

  /* Level2 S-Function Block: '<S47>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[28];
    sfcnOutputs(rts, 0);
  }

  /* Level2 S-Function Block: '<S47>/Setup1' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[29];
    sfcnOutputs(rts, 0);
  }

  /* Level2 S-Function Block: '<S47>/Setup2' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[30];
    sfcnOutputs(rts, 0);
  }

  /* MATLAB Function: '<S8>/stop signals' */
  /* MATLAB Function 'UDP interface/stop signals': '<S56>:1' */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Leads the enable command through. The enable command turns the Robotino % */
  /*  inputs to selectable form.                                              % */
  /*                                                                          % */
  /*  input: udp_in (vector of 56 elements containing the data sent by the    % */
  /*                 camera-model)                                            % */
  /*  outputs: enable_out (1 = inputs are in selectable form;                 % */
  /*                       0 = inputs are set to 0)                           % */
  /*           udp_out (vector of 56 elements containing the data sent by the % */
  /*                    camera-model)                                         % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* '<S56>:1:13' */
  KitGewerk2_v14_B.enable_out[0] = 0.0;
  KitGewerk2_v14_B.enable_out[1] = 0.0;
  if ((KitGewerk2_v14_B.Unpack[(int32_T)(KitGewerk2_v14_B.Unpack_o * 3.0 - 2.0)
       - 1] <= 0.0) && (KitGewerk2_v14_B.Unpack[(int32_T)
                        (KitGewerk2_v14_B.Unpack_o * 3.0 - 1.0) - 1] <= 0.0) &&
      (KitGewerk2_v14_B.Unpack[(int32_T)(KitGewerk2_v14_B.Unpack_o * 3.0) - 1] <=
       0.0)) {
    /* '<S56>:1:14' */
    /* '<S56>:1:15' */
    /* '<S56>:1:16' */
    KitGewerk2_v14_B.enable_out[0] = 0.0;
  } else {
    /* '<S56>:1:18' */
    KitGewerk2_v14_B.enable_out[0] = 1.0;
  }

  /* '<S56>:1:20' */
  KitGewerk2_v14_B.enable_out[1] = KitGewerk2_v14_B.Unpack[27];

  /* End of MATLAB Function: '<S8>/stop signals' */

  /* Constant: '<Root>/constant3' */
  KitGewerk2_v14_B.constant3 = KitGewerk2_v14_P.constant3_Value;

  /* Constant: '<Root>/constant4' */
  KitGewerk2_v14_B.constant4 = KitGewerk2_v14_P.constant4_Value;

  /* Constant: '<Root>/constant5' */
  KitGewerk2_v14_B.constant5 = KitGewerk2_v14_P.constant5_Value;
}

/* Model update function for TID0 */
void KitGewerk2_v14_update0(void)      /* Sample time: [0.0s, 0.0s] */
{
  /* Update for Memory: '<S45>/last error free response' */
  memcpy(&KitGewerk2_v14_DW.lasterrorfreeresponse_PreviousI[0],
         &KitGewerk2_v14_B.error_free_resp_out[0], 102U * sizeof(real_T));

  /* Update for Memory: '<S45>/stop marker' */
  KitGewerk2_v14_DW.stopmarker_PreviousInput[0] =
    KitGewerk2_v14_B.stop_flag_out[0];
  KitGewerk2_v14_DW.stopmarker_PreviousInput[1] =
    KitGewerk2_v14_B.stop_flag_out[1];
  KitGewerk2_v14_DW.stopmarker_PreviousInput[2] =
    KitGewerk2_v14_B.stop_flag_out[2];

  /* Update for Memory: '<S24>/Previous Flag' */
  KitGewerk2_v14_DW.PreviousFlag_PreviousInput = KitGewerk2_v14_B.FLAG;

  /* Update for Memory: '<S24>/Previous SOC' */
  KitGewerk2_v14_DW.PreviousSOC_PreviousInput = KitGewerk2_v14_B.SOC_a;

  /* Update for Memory: '<S26>/Memory' */
  KitGewerk2_v14_DW.Memory_PreviousInput = KitGewerk2_v14_B.ChargingCounter;

  /* Update for Memory: '<S26>/Memory1' */
  KitGewerk2_v14_DW.Memory1_PreviousInput = KitGewerk2_v14_B.DischargingCounter;

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++KitGewerk2_v14_M->Timing.clockTick0)) {
    ++KitGewerk2_v14_M->Timing.clockTickH0;
  }

  KitGewerk2_v14_M->Timing.t[0] = KitGewerk2_v14_M->Timing.clockTick0 *
    KitGewerk2_v14_M->Timing.stepSize0 + KitGewerk2_v14_M->Timing.clockTickH0 *
    KitGewerk2_v14_M->Timing.stepSize0 * 4294967296.0;
  switch (KitGewerk2_v14_M->Timing.rtmDbBufReadBuf3) {
   case 0:
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3 = 1;
    break;

   case 1:
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3 = 0;
    break;

   default:
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3 =
      !KitGewerk2_v14_M->Timing.rtmDbBufLastBufWr3;
    break;
  }

  KitGewerk2_v14_M->Timing.rtmDbBufClockTick3
    [KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3] =
    KitGewerk2_v14_M->Timing.clockTick0;
  KitGewerk2_v14_M->Timing.rtmDbBufClockTickH3
    [KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3] =
    KitGewerk2_v14_M->Timing.clockTickH0;
  KitGewerk2_v14_M->Timing.rtmDbBufLastBufWr3 =
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3;
  KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3 = 0xFF;
  switch (KitGewerk2_v14_M->Timing.rtmDbBufReadBuf4) {
   case 0:
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4 = 1;
    break;

   case 1:
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4 = 0;
    break;

   default:
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4 =
      !KitGewerk2_v14_M->Timing.rtmDbBufLastBufWr4;
    break;
  }

  KitGewerk2_v14_M->Timing.rtmDbBufClockTick4
    [KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4] =
    KitGewerk2_v14_M->Timing.clockTick0;
  KitGewerk2_v14_M->Timing.rtmDbBufClockTickH4
    [KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4] =
    KitGewerk2_v14_M->Timing.clockTickH0;
  KitGewerk2_v14_M->Timing.rtmDbBufLastBufWr4 =
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4;
  KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4 = 0xFF;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++KitGewerk2_v14_M->Timing.clockTick1)) {
    ++KitGewerk2_v14_M->Timing.clockTickH1;
  }

  KitGewerk2_v14_M->Timing.t[1] = KitGewerk2_v14_M->Timing.clockTick1 *
    KitGewerk2_v14_M->Timing.stepSize1 + KitGewerk2_v14_M->Timing.clockTickH1 *
    KitGewerk2_v14_M->Timing.stepSize1 * 4294967296.0;
}

/* Model output function for TID2 */
void KitGewerk2_v14_output2(void)      /* Sample time: [0.5s, 0.0s] */
{
  int32_T i;
  real_T u;

  /* Reset subsysRan breadcrumbs */
  srClearBC(KitGewerk2_v14_DW.IfRobotino4_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(KitGewerk2_v14_DW.IfRobotino3_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(KitGewerk2_v14_DW.IfRobotino2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(KitGewerk2_v14_DW.IfRobotino1_SubsysRanBC);

  /* SwitchCase: '<S10>/Switch Case' */
  u = KitGewerk2_v14_B.RateTransitiondownsamplingto500;
  if (u < 0.0) {
    u = ceil(u);
  } else {
    u = floor(u);
  }

  if (rtIsNaN(u) || rtIsInf(u)) {
    u = 0.0;
  } else {
    u = fmod(u, 4.294967296E+9);
  }

  switch (u < 0.0 ? -(int32_T)(uint32_T)-u : (int32_T)(uint32_T)u) {
   case 4:
    /* Outputs for IfAction SubSystem: '<S10>/If Robotino 4' incorporates:
     *  ActionPort: '<S14>/Action Port'
     */

    /* Level2 S-Function Block: '<S14>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[0];
      sfcnOutputs(rts, 2);
    }

    /* Level2 S-Function Block: '<S14>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[1];
      sfcnOutputs(rts, 2);
    }

    /* End of Outputs for SubSystem: '<S10>/If Robotino 4' */

    /* Update for IfAction SubSystem: '<S10>/If Robotino 4' incorporates:
     *  Update for ActionPort: '<S14>/Action Port'
     */
    /* Update for SwitchCase: '<S10>/Switch Case' */
    srUpdateBC(KitGewerk2_v14_DW.IfRobotino4_SubsysRanBC);

    /* End of Update for SubSystem: '<S10>/If Robotino 4' */
    break;

   case 3:
    /* Outputs for IfAction SubSystem: '<S10>/If Robotino 3' incorporates:
     *  ActionPort: '<S13>/Action Port'
     */

    /* Level2 S-Function Block: '<S13>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[2];
      sfcnOutputs(rts, 2);
    }

    /* Level2 S-Function Block: '<S13>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[3];
      sfcnOutputs(rts, 2);
    }

    /* End of Outputs for SubSystem: '<S10>/If Robotino 3' */

    /* Update for IfAction SubSystem: '<S10>/If Robotino 3' incorporates:
     *  Update for ActionPort: '<S13>/Action Port'
     */
    /* Update for SwitchCase: '<S10>/Switch Case' */
    srUpdateBC(KitGewerk2_v14_DW.IfRobotino3_SubsysRanBC);

    /* End of Update for SubSystem: '<S10>/If Robotino 3' */
    break;

   case 2:
    /* Outputs for IfAction SubSystem: '<S10>/If Robotino 2' incorporates:
     *  ActionPort: '<S12>/Action Port'
     */

    /* Level2 S-Function Block: '<S12>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[4];
      sfcnOutputs(rts, 2);
    }

    /* Level2 S-Function Block: '<S12>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[5];
      sfcnOutputs(rts, 2);
    }

    /* End of Outputs for SubSystem: '<S10>/If Robotino 2' */

    /* Update for IfAction SubSystem: '<S10>/If Robotino 2' incorporates:
     *  Update for ActionPort: '<S12>/Action Port'
     */
    /* Update for SwitchCase: '<S10>/Switch Case' */
    srUpdateBC(KitGewerk2_v14_DW.IfRobotino2_SubsysRanBC);

    /* End of Update for SubSystem: '<S10>/If Robotino 2' */
    break;

   case 1:
    /* Outputs for IfAction SubSystem: '<S10>/If Robotino 1' incorporates:
     *  ActionPort: '<S11>/Action Port'
     */

    /* Level2 S-Function Block: '<S11>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[6];
      sfcnOutputs(rts, 2);
    }

    /* Level2 S-Function Block: '<S11>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[7];
      sfcnOutputs(rts, 2);
    }

    /* End of Outputs for SubSystem: '<S10>/If Robotino 1' */

    /* Update for IfAction SubSystem: '<S10>/If Robotino 1' incorporates:
     *  Update for ActionPort: '<S11>/Action Port'
     */
    /* Update for SwitchCase: '<S10>/Switch Case' */
    srUpdateBC(KitGewerk2_v14_DW.IfRobotino1_SubsysRanBC);

    /* End of Update for SubSystem: '<S10>/If Robotino 1' */
    break;
  }

  /* End of SwitchCase: '<S10>/Switch Case' */

  /* MultiPortSwitch: '<S10>/Multiport Switch' */
  switch ((int32_T)KitGewerk2_v14_B.RateTransitiondownsamplingto500) {
   case 1:
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_B.MultiportSwitch[i] = KitGewerk2_v14_B.Receivefromall_o1[i];
    }
    break;

   case 2:
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_B.MultiportSwitch[i] =
        KitGewerk2_v14_B.Receivefromall_o1_p[i];
    }
    break;

   case 3:
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_B.MultiportSwitch[i] =
        KitGewerk2_v14_B.Receivefromall_o1_j[i];
    }
    break;

   default:
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_B.MultiportSwitch[i] =
        KitGewerk2_v14_B.Receivefromall_o1_g[i];
    }
    break;
  }

  /* End of MultiPortSwitch: '<S10>/Multiport Switch' */
}

/* Model update function for TID2 */
void KitGewerk2_v14_update2(void)      /* Sample time: [0.5s, 0.0s] */
{
  int32_T i;

  /* Update for RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */
  for (i = 0; i < 5; i++) {
    KitGewerk2_v14_DW.RateTransitionupsamplingtofunda[i] =
      KitGewerk2_v14_B.MultiportSwitch[i];
  }

  /* End of Update for RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++KitGewerk2_v14_M->Timing.clockTick2)) {
    ++KitGewerk2_v14_M->Timing.clockTickH2;
  }

  KitGewerk2_v14_M->Timing.t[2] = KitGewerk2_v14_M->Timing.clockTick2 *
    KitGewerk2_v14_M->Timing.stepSize2 + KitGewerk2_v14_M->Timing.clockTickH2 *
    KitGewerk2_v14_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output wrapper function for compatibility with a static main program */
void KitGewerk2_v14_output(int_T tid)
{
  switch (tid) {
   case 0 :
    KitGewerk2_v14_output0();
    break;

   case 2 :
    KitGewerk2_v14_output2();
    break;

   default :
    break;
  }
}

/* Model update wrapper function for compatibility with a static main program */
void KitGewerk2_v14_update(int_T tid)
{
  switch (tid) {
   case 0 :
    KitGewerk2_v14_update0();
    break;

   case 2 :
    KitGewerk2_v14_update2();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void KitGewerk2_v14_initialize(void)
{
  {
    int32_T i;

    /* Start for S-Function (xpcinterrupt): '<S47>/IRQ Source' incorporates:
     *  Start for SubSystem: '<S47>/RS232 ISR'
     */
    KitGewerk2_v14_RS232ISR_f_Start(); /* Level2 S-Function Block: '<S47>/FIFO read 1' (fiforead) */

    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[18];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S8>/Receive' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[19];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_B.RateTransitionupsamplingtofunda[i] =
        KitGewerk2_v14_P.RateTransitionupsamplingtofunda;
    }

    /* End of Start for RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */

    /* Start for Constant: '<S5>/Constant7' */
    KitGewerk2_v14_B.Constant7 = KitGewerk2_v14_P.Constant7_Value;

    /* Start for Constant: '<S5>/Constant5' */
    KitGewerk2_v14_B.Constant5 = KitGewerk2_v14_P.Constant5_Value;

    /* Start for Constant: '<S5>/Constant' */
    KitGewerk2_v14_B.Constant = KitGewerk2_v14_P.Constant_Value_m;

    /* Start for Constant: '<S5>/Constant2' */
    KitGewerk2_v14_B.Constant2_f = KitGewerk2_v14_P.Constant2_Value_b;

    /* Start for Constant: '<S5>/Constant4' */
    KitGewerk2_v14_B.Constant4 = KitGewerk2_v14_P.Constant4_Value_g;

    /* Start for Chart: '<S5>/Chart' incorporates:
     *  Start for SubSystem: '<S17>/Fahrt_zum_Warteplatz.simfcn'
     */
    /* Start for Constant: '<S20>/Constant1' */
    KitGewerk2_v14_B.Constant1[0] = KitGewerk2_v14_P.Constant1_Value[0];
    KitGewerk2_v14_B.Constant1[1] = KitGewerk2_v14_P.Constant1_Value[1];

    /* Start for Constant: '<S20>/Constant2' */
    KitGewerk2_v14_B.Constant2[0] = KitGewerk2_v14_P.Constant2_Value[0];
    KitGewerk2_v14_B.Constant2[1] = KitGewerk2_v14_P.Constant2_Value[1];
    for (i = 0; i < 6; i++) {
      /* Start for Constant: '<S20>/Constant3' */
      KitGewerk2_v14_B.Constant3[i] = KitGewerk2_v14_P.Constant3_Value[i];
    }

    /* Start for S-Function (xpcinterrupt): '<S34>/IRQ Source' incorporates:
     *  Start for SubSystem: '<S34>/RS232 ISR'
     */
    KitGewerk2_v14_RS232ISR_Start();   /* Level2 S-Function Block: '<S34>/FIFO read 1' (fiforead) */

    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[20];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for Triggered SubSystem: '<S9>/getIDfromFlash' */

    /* Level2 S-Function Block: '<S57>/From File' (xpcfromfile) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[17];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* End of Start for SubSystem: '<S9>/getIDfromFlash' */

    /* Start for IfAction SubSystem: '<S10>/If Robotino 4' */

    /* Level2 S-Function Block: '<S14>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[0];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S14>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[1];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* End of Start for SubSystem: '<S10>/If Robotino 4' */

    /* Start for IfAction SubSystem: '<S10>/If Robotino 3' */

    /* Level2 S-Function Block: '<S13>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[2];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S13>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[3];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* End of Start for SubSystem: '<S10>/If Robotino 3' */

    /* Start for IfAction SubSystem: '<S10>/If Robotino 2' */

    /* Level2 S-Function Block: '<S12>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[4];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S12>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[5];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* End of Start for SubSystem: '<S10>/If Robotino 2' */

    /* Start for IfAction SubSystem: '<S10>/If Robotino 1' */

    /* Level2 S-Function Block: '<S11>/Receive from all' (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[6];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S11>/Send to all' (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[7];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* End of Start for SubSystem: '<S10>/If Robotino 1' */

    /* Level2 S-Function Block: '<S34>/FIFO write 1' (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[21];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S34>/FIFO write 2' (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[22];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S34>/FIFO read 2' (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[23];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S34>/Setup1' (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[24];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S34>/Setup2' (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[25];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S47>/FIFO write 1' (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[26];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S47>/FIFO write 2' (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[27];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S47>/FIFO read 2' (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[28];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S47>/Setup1' (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[29];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Level2 S-Function Block: '<S47>/Setup2' (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[30];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* user code (Start function Trailer) */
    {
      uint8_T irq = 4;

      /* For an ISA board, save the given address in the struct. */
      xpcDev_1.BaseAddress[0] = 0;

      /* connect ISR system: IRQ 4 */
      if (xpceRegisterISR( irq, xPCISR1,
                          NULL,
                          NULL, 0,
                          &xpcDev_1) == -1) {
        static uint8_T ermsg[100];
        sprintf( ermsg,
                "ISR registration failed for Interrupt %d ISA board at 0." );
        rtmSetErrorStatus(KitGewerk2_v14_M, ermsg);
        return;
      }
    }

    xpcOutpB( 0xA0, 0x20 );
    xpcOutpB( 0x20, 0x20 );

    {
      uint8_T irq = 3;

      /* For an ISA board, save the given address in the struct. */
      xpcDev_2.BaseAddress[0] = 0;

      /* connect ISR system: IRQ 3 */
      if (xpceRegisterISR( irq, xPCISR2,
                          NULL,
                          NULL, 0,
                          &xpcDev_2) == -1) {
        static uint8_T ermsg[100];
        sprintf( ermsg,
                "ISR registration failed for Interrupt %d ISA board at 0." );
        rtmSetErrorStatus(KitGewerk2_v14_M, ermsg);
        return;
      }
    }
  }

  KitGewerk2_v14_PrevZCX.getIDfromFlash_Trig_ZCE = UNINITIALIZED_ZCSIG;

  {
    int32_T i;
    KitGewerk2_v14_M->Timing.rtmDbBufReadBuf3 = 0xFF;
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf3 = 0xFF;
    KitGewerk2_v14_M->Timing.rtmDbBufLastBufWr3 = 0;
    KitGewerk2_v14_M->Timing.rtmDbBufReadBuf4 = 0xFF;
    KitGewerk2_v14_M->Timing.rtmDbBufWriteBuf4 = 0xFF;
    KitGewerk2_v14_M->Timing.rtmDbBufLastBufWr4 = 0;

    /* InitializeConditions for Memory: '<S45>/last error free response' */
    memcpy(&KitGewerk2_v14_DW.lasterrorfreeresponse_PreviousI[0],
           &KitGewerk2_v14_P.lasterrorfreeresponse_X0[0], 102U * sizeof(real_T));

    /* InitializeConditions for Memory: '<S45>/stop marker' */
    KitGewerk2_v14_DW.stopmarker_PreviousInput[0] =
      KitGewerk2_v14_P.stopmarker_X0[0];
    KitGewerk2_v14_DW.stopmarker_PreviousInput[1] =
      KitGewerk2_v14_P.stopmarker_X0[1];
    KitGewerk2_v14_DW.stopmarker_PreviousInput[2] =
      KitGewerk2_v14_P.stopmarker_X0[2];

    /* InitializeConditions for RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */
    for (i = 0; i < 5; i++) {
      KitGewerk2_v14_DW.RateTransitionupsamplingtofunda[i] =
        KitGewerk2_v14_P.RateTransitionupsamplingtofunda;
    }

    /* End of InitializeConditions for RateTransition: '<S10>/Rate Transition up-sampling to fundamental sample time' */
    KitGewerk2_v14_DW.sfEvent = -1;
    KitGewerk2_v14_DW.is_A_stern_fahrt = KitGewerk2_v_IN_NO_ACTIVE_CHILD;
    KitGewerk2_v14_DW.is_Routinen_Ladestationen =
      KitGewerk2_v_IN_NO_ACTIVE_CHILD;
    KitGewerk2_v14_DW.is_Routinen_Stationen = KitGewerk2_v_IN_NO_ACTIVE_CHILD;
    KitGewerk2_v14_DW.is_Werkstueck_ablegen = KitGewerk2_v_IN_NO_ACTIVE_CHILD;
    KitGewerk2_v14_DW.is_Werkstueck_aufnehmen = KitGewerk2_v_IN_NO_ACTIVE_CHILD;
    KitGewerk2_v14_DW.temporalCounter_i1 = 0U;
    KitGewerk2_v14_DW.is_active_c15_KitGewerk2_v14 = 0U;
    KitGewerk2_v14_DW.is_c15_KitGewerk2_v14 = KitGewerk2_v_IN_NO_ACTIVE_CHILD;

    /* InitializeConditions for Chart: '<S5>/Chart' incorporates:
     *  InitializeConditions for SubSystem: '<S17>/Fahrt_zum_Warteplatz.simfcn'
     */
    /* Level2 S-Function Block: '<S21>/S-Function' (bahnplaner_v22) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[8];
      sfcnInitializeConditions(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* InitializeConditions for Memory: '<S24>/Previous Flag' */
    KitGewerk2_v14_DW.PreviousFlag_PreviousInput =
      KitGewerk2_v14_P.PreviousFlag_X0;

    /* InitializeConditions for Memory: '<S24>/Previous SOC' */
    KitGewerk2_v14_DW.PreviousSOC_PreviousInput =
      KitGewerk2_v14_P.PreviousSOC_X0;

    /* InitializeConditions for Memory: '<S26>/Memory' */
    KitGewerk2_v14_DW.Memory_PreviousInput = KitGewerk2_v14_P.Memory_X0;

    /* InitializeConditions for S-Function (sdspcount2): '<S26>/Charging Counter' */
    KitGewerk2_v14_DW.ChargingCounter_Count =
      KitGewerk2_v14_P.ChargingCounter_InitialCount;

    /* InitializeConditions for Memory: '<S26>/Memory1' */
    KitGewerk2_v14_DW.Memory1_PreviousInput = KitGewerk2_v14_P.Memory1_X0;

    /* InitializeConditions for S-Function (sdspcount2): '<S26>/Discharging Counter' */
    KitGewerk2_v14_DW.DischargingCounter_Count =
      KitGewerk2_v14_P.DischargingCounter_InitialCount;

    /* InitializeConditions for S-Function (sdspcount2): '<S5>/Counter' */
    KitGewerk2_v14_DW.Counter_ClkEphState = 5U;
    KitGewerk2_v14_DW.Counter_Count = KitGewerk2_v14_P.Counter_InitialCount;
  }
}

/* Model terminate function */
void KitGewerk2_v14_terminate(void)
{
  /* user code (Terminate function Header) */

  /* Stop first, then deregister, else the board could interrupt
   * after deregistering and before the stop.
   */
  /* disable interrupt for IRQ 4 */
  xpceDeRegisterISR( &xpcDev_1 );

  /* Stop first, then deregister, else the board could interrupt
   * after deregistering and before the stop.
   */
  /* disable interrupt for IRQ 3 */
  xpceDeRegisterISR( &xpcDev_2 );

  /* Terminate for S-Function (xpcinterrupt): '<S47>/IRQ Source' incorporates:
   *  Terminate for SubSystem: '<S47>/RS232 ISR'
   */
  KitGewerk2_v14_RS232ISR_k_Term();    /* Level2 S-Function Block: '<S47>/FIFO read 1' (fiforead) */

  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[18];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S8>/Receive' (xpcudpbytereceive) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[19];
    sfcnTerminate(rts);
  }

  /* Terminate for Chart: '<S5>/Chart' incorporates:
   *  Terminate for SubSystem: '<S17>/Fahrt_zum_Warteplatz.simfcn'
   */
  /* Level2 S-Function Block: '<S21>/S-Function' (bahnplaner_v22) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[8];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (xpcinterrupt): '<S34>/IRQ Source' incorporates:
   *  Terminate for SubSystem: '<S34>/RS232 ISR'
   */
  KitGewerk2_v14_RS232ISR_Term();      /* Level2 S-Function Block: '<S34>/FIFO read 1' (fiforead) */

  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[20];
    sfcnTerminate(rts);
  }

  /* Terminate for Triggered SubSystem: '<S9>/getIDfromFlash' */

  /* Level2 S-Function Block: '<S57>/From File' (xpcfromfile) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[17];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/getIDfromFlash' */

  /* Terminate for IfAction SubSystem: '<S10>/If Robotino 4' */

  /* Level2 S-Function Block: '<S14>/Receive from all' (xpcudpbytereceive) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S14>/Send to all' (xpcudpbytesend) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S10>/If Robotino 4' */

  /* Terminate for IfAction SubSystem: '<S10>/If Robotino 3' */

  /* Level2 S-Function Block: '<S13>/Receive from all' (xpcudpbytereceive) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S13>/Send to all' (xpcudpbytesend) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S10>/If Robotino 3' */

  /* Terminate for IfAction SubSystem: '<S10>/If Robotino 2' */

  /* Level2 S-Function Block: '<S12>/Receive from all' (xpcudpbytereceive) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S12>/Send to all' (xpcudpbytesend) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S10>/If Robotino 2' */

  /* Terminate for IfAction SubSystem: '<S10>/If Robotino 1' */

  /* Level2 S-Function Block: '<S11>/Receive from all' (xpcudpbytereceive) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S11>/Send to all' (xpcudpbytesend) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S10>/If Robotino 1' */

  /* Level2 S-Function Block: '<S34>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[21];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S34>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[22];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S34>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[23];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S34>/Setup1' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[24];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S34>/Setup2' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[25];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S47>/FIFO write 1' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[26];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S47>/FIFO write 2' (fifowrite) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[27];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S47>/FIFO read 2' (fiforead) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[28];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S47>/Setup1' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[29];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S47>/Setup2' (sersetupbase) */
  {
    SimStruct *rts = KitGewerk2_v14_M->childSfunctions[30];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  KitGewerk2_v14_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  KitGewerk2_v14_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  KitGewerk2_v14_initialize();
}

void MdlTerminate(void)
{
  KitGewerk2_v14_terminate();
}

/* Registration function */
RT_MODEL_KitGewerk2_v14_T *KitGewerk2_v14(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)KitGewerk2_v14_M, 0,
                sizeof(RT_MODEL_KitGewerk2_v14_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&KitGewerk2_v14_M->solverInfo,
                          &KitGewerk2_v14_M->Timing.simTimeStep);
    rtsiSetTPtr(&KitGewerk2_v14_M->solverInfo, &rtmGetTPtr(KitGewerk2_v14_M));
    rtsiSetStepSizePtr(&KitGewerk2_v14_M->solverInfo,
                       &KitGewerk2_v14_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&KitGewerk2_v14_M->solverInfo, (&rtmGetErrorStatus
      (KitGewerk2_v14_M)));
    rtsiSetRTModelPtr(&KitGewerk2_v14_M->solverInfo, KitGewerk2_v14_M);
  }

  rtsiSetSimTimeStep(&KitGewerk2_v14_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&KitGewerk2_v14_M->solverInfo,"FixedStepDiscrete");
  KitGewerk2_v14_M->solverInfoPtr = (&KitGewerk2_v14_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = KitGewerk2_v14_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    mdlTsMap[2] = 2;
    KitGewerk2_v14_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    KitGewerk2_v14_M->Timing.sampleTimes =
      (&KitGewerk2_v14_M->Timing.sampleTimesArray[0]);
    KitGewerk2_v14_M->Timing.offsetTimes =
      (&KitGewerk2_v14_M->Timing.offsetTimesArray[0]);

    /* task periods */
    KitGewerk2_v14_M->Timing.sampleTimes[0] = (0.0);
    KitGewerk2_v14_M->Timing.sampleTimes[1] = (0.005);
    KitGewerk2_v14_M->Timing.sampleTimes[2] = (0.5);

    /* task offsets */
    KitGewerk2_v14_M->Timing.offsetTimes[0] = (0.0);
    KitGewerk2_v14_M->Timing.offsetTimes[1] = (0.0);
    KitGewerk2_v14_M->Timing.offsetTimes[2] = (0.0);
  }

  rtmSetTPtr(KitGewerk2_v14_M, &KitGewerk2_v14_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = KitGewerk2_v14_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits =
      KitGewerk2_v14_M->Timing.perTaskSampleHitsArray;
    KitGewerk2_v14_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    KitGewerk2_v14_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(KitGewerk2_v14_M, -1);
  KitGewerk2_v14_M->Timing.stepSize0 = 0.005;
  KitGewerk2_v14_M->Timing.stepSize1 = 0.005;
  KitGewerk2_v14_M->Timing.stepSize2 = 0.5;
  KitGewerk2_v14_M->Timing.stepSize3 = 0.005;
  KitGewerk2_v14_M->Timing.stepSize4 = 0.005;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    KitGewerk2_v14_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(KitGewerk2_v14_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(KitGewerk2_v14_M->rtwLogInfo, (NULL));
    rtliSetLogT(KitGewerk2_v14_M->rtwLogInfo, "tout");
    rtliSetLogX(KitGewerk2_v14_M->rtwLogInfo, "");
    rtliSetLogXFinal(KitGewerk2_v14_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(KitGewerk2_v14_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(KitGewerk2_v14_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(KitGewerk2_v14_M->rtwLogInfo, 0);
    rtliSetLogDecimation(KitGewerk2_v14_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &KitGewerk2_v14_Y.Robotinorawdata[0],
        &KitGewerk2_v14_Y.Robotinoprocesseddata[0],
        &KitGewerk2_v14_Y.UDPdata[0]
      };

      rtliSetLogYSignalPtrs(KitGewerk2_v14_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        102,
        15,
        56
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        102,
        15,
        56
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0,
        0,
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL),
        (NULL),
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4,
        4,
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE,
        SS_DOUBLE,
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0,
        0,
        0
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "102 elements",
        "15 elements",
        "56 elements" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "KitGewerk2_v14/Robotino raw data",
        "KitGewerk2_v14/Robotino processed data",
        "KitGewerk2_v14/UDP data" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          3,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(KitGewerk2_v14_M->rtwLogInfo,
                            rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
      rt_LoggedCurrentSignalDimensions[1] = &rt_LoggedOutputWidths[1];
      rt_LoggedCurrentSignalDimensions[2] = &rt_LoggedOutputWidths[2];
    }

    rtliSetLogY(KitGewerk2_v14_M->rtwLogInfo, "yout");
  }

  /* External mode info */
  KitGewerk2_v14_M->Sizes.checksums[0] = (551439995U);
  KitGewerk2_v14_M->Sizes.checksums[1] = (352028151U);
  KitGewerk2_v14_M->Sizes.checksums[2] = (2585246182U);
  KitGewerk2_v14_M->Sizes.checksums[3] = (4036248840U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[40];
    KitGewerk2_v14_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = (sysRanDType *)&KitGewerk2_v14_DW.IfRobotino1_SubsysRanBC;
    systemRan[5] = (sysRanDType *)&KitGewerk2_v14_DW.IfRobotino2_SubsysRanBC;
    systemRan[6] = (sysRanDType *)&KitGewerk2_v14_DW.IfRobotino3_SubsysRanBC;
    systemRan[7] = (sysRanDType *)&KitGewerk2_v14_DW.IfRobotino4_SubsysRanBC;
    systemRan[8] = (sysRanDType *)
      &KitGewerk2_v14_DW.Fahrt_zum_Warteplatzsimfcn_Subs;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    systemRan[13] = &rtAlwaysEnabled;
    systemRan[14] = &rtAlwaysEnabled;
    systemRan[15] = &rtAlwaysEnabled;
    systemRan[16] = &rtAlwaysEnabled;
    systemRan[17] = &rtAlwaysEnabled;
    systemRan[18] = (sysRanDType *)&KitGewerk2_v14_DW.Receive1_SubsysRanBC_o;
    systemRan[19] = (sysRanDType *)&KitGewerk2_v14_DW.Receive2_SubsysRanBC_n;
    systemRan[20] = (sysRanDType *)&KitGewerk2_v14_DW.Transmit1_SubsysRanBC_k;
    systemRan[21] = (sysRanDType *)&KitGewerk2_v14_DW.Transmit2_SubsysRanBC_l;
    systemRan[22] = (sysRanDType *)&KitGewerk2_v14_DW.RS232ISR_SubsysRanBC_d;
    systemRan[23] = &rtAlwaysEnabled;
    systemRan[24] = &rtAlwaysEnabled;
    systemRan[25] = &rtAlwaysEnabled;
    systemRan[26] = &rtAlwaysEnabled;
    systemRan[27] = &rtAlwaysEnabled;
    systemRan[28] = &rtAlwaysEnabled;
    systemRan[29] = (sysRanDType *)&KitGewerk2_v14_DW.Receive1_SubsysRanBC;
    systemRan[30] = (sysRanDType *)&KitGewerk2_v14_DW.Receive2_SubsysRanBC;
    systemRan[31] = (sysRanDType *)&KitGewerk2_v14_DW.Transmit1_SubsysRanBC;
    systemRan[32] = (sysRanDType *)&KitGewerk2_v14_DW.Transmit2_SubsysRanBC;
    systemRan[33] = (sysRanDType *)&KitGewerk2_v14_DW.RS232ISR_SubsysRanBC;
    systemRan[34] = &rtAlwaysEnabled;
    systemRan[35] = &rtAlwaysEnabled;
    systemRan[36] = &rtAlwaysEnabled;
    systemRan[37] = &rtAlwaysEnabled;
    systemRan[38] = &rtAlwaysEnabled;
    systemRan[39] = (sysRanDType *)&KitGewerk2_v14_DW.getIDfromFlash_SubsysRanBC;
    rteiSetModelMappingInfoPtr(KitGewerk2_v14_M->extModeInfo,
      &KitGewerk2_v14_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(KitGewerk2_v14_M->extModeInfo,
                        KitGewerk2_v14_M->Sizes.checksums);
    rteiSetTPtr(KitGewerk2_v14_M->extModeInfo, rtmGetTPtr(KitGewerk2_v14_M));
  }

  KitGewerk2_v14_M->solverInfoPtr = (&KitGewerk2_v14_M->solverInfo);
  KitGewerk2_v14_M->Timing.stepSize = (0.005);
  rtsiSetFixedStepSize(&KitGewerk2_v14_M->solverInfo, 0.005);
  rtsiSetSolverMode(&KitGewerk2_v14_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  KitGewerk2_v14_M->ModelData.blockIO = ((void *) &KitGewerk2_v14_B);
  (void) memset(((void *) &KitGewerk2_v14_B), 0,
                sizeof(B_KitGewerk2_v14_T));

  {
    int_T i;
    for (i = 0; i < 102; i++) {
      KitGewerk2_v14_B.uint16todouble[i] = 0.0;
    }

    for (i = 0; i < 102; i++) {
      KitGewerk2_v14_B.lasterrorfreeresponse[i] = 0.0;
    }

    for (i = 0; i < 56; i++) {
      KitGewerk2_v14_B.Unpack[i] = 0.0;
    }

    for (i = 0; i < 9; i++) {
      KitGewerk2_v14_B.Auswahl6[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      KitGewerk2_v14_B.Auswahl10[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      KitGewerk2_v14_B.Auswahl9[i] = 0.0;
    }

    for (i = 0; i < 68; i++) {
      KitGewerk2_v14_B.WegpunktlistezumTesten[i] = 0.0;
    }

    for (i = 0; i < 48; i++) {
      KitGewerk2_v14_B.message[i] = 0.0;
    }

    for (i = 0; i < 9; i++) {
      KitGewerk2_v14_B.distance_measuring_sensors_out[i] = 0.0;
    }

    for (i = 0; i < 102; i++) {
      KitGewerk2_v14_B.error_free_resp_out[i] = 0.0;
    }

    for (i = 0; i < 9; i++) {
      KitGewerk2_v14_B.dms_out[i] = 0.0;
    }

    for (i = 0; i < 15; i++) {
      KitGewerk2_v14_B.robotino_response[i] = 0.0;
    }

    for (i = 0; i < 200; i++) {
      KitGewerk2_v14_B.A_WPL[i] = 0.0;
    }

    for (i = 0; i < 200; i++) {
      KitGewerk2_v14_B.A_stern_test[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      KitGewerk2_v14_B.Constant3[i] = 0.0;
    }

    for (i = 0; i < 200; i++) {
      KitGewerk2_v14_B.Wegpunkte[i] = 0.0;
    }

    for (i = 0; i < 200; i++) {
      KitGewerk2_v14_B.SFunction_o2[i] = 0.0;
    }

    KitGewerk2_v14_B.RateTransition = serialfifoground;
    KitGewerk2_v14_B.RateTransition2 = serialfifoground;
    KitGewerk2_v14_B.RateTransition1 = serialfifoground;
    KitGewerk2_v14_B.RateTransition_g = serialfifoground;
    KitGewerk2_v14_B.RateTransition2_m = serialfifoground;
    KitGewerk2_v14_B.RateTransition1_g = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite1_o1 = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite2_o1 = serialfifoground;
    KitGewerk2_v14_B.RateTransition3 = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite1_o1_o = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite2_o1_k = serialfifoground;
    KitGewerk2_v14_B.RateTransition3_e = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite2 = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite1 = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite2_a = serialfifoground;
    KitGewerk2_v14_B.FIFOwrite1_c = serialfifoground;
    KitGewerk2_v14_B.stopmarker[0] = 0.0;
    KitGewerk2_v14_B.stopmarker[1] = 0.0;
    KitGewerk2_v14_B.stopmarker[2] = 0.0;
    KitGewerk2_v14_B.Receive_o2 = 0.0;
    KitGewerk2_v14_B.DataTypeConversion3 = 0.0;
    KitGewerk2_v14_B.Step = 0.0;
    KitGewerk2_v14_B.DataTypeConversion4 = 0.0;
    KitGewerk2_v14_B.DataTypeConversion3_j = 0.0;
    KitGewerk2_v14_B.DataTypeConversion2 = 0.0;
    KitGewerk2_v14_B.Sum = 0.0;
    KitGewerk2_v14_B.Gain = 0.0;
    KitGewerk2_v14_B.DataTypeConversion1 = 0.0;
    KitGewerk2_v14_B.DataTypeConversion = 0.0;
    KitGewerk2_v14_B.Add = 0.0;
    KitGewerk2_v14_B.Gain_b = 0.0;
    KitGewerk2_v14_B.RateTransitiondownsamplingto500 = 0.0;
    KitGewerk2_v14_B.Auswahl1 = 0.0;
    KitGewerk2_v14_B.Auswahl2 = 0.0;
    KitGewerk2_v14_B.Auswahl3 = 0.0;
    KitGewerk2_v14_B.Auswahl4 = 0.0;
    KitGewerk2_v14_B.Auswahl5 = 0.0;
    KitGewerk2_v14_B.Auswahl7 = 0.0;
    KitGewerk2_v14_B.DataTypeConversion1_i = 0.0;
    KitGewerk2_v14_B.Auswahl1_h[0] = 0.0;
    KitGewerk2_v14_B.Auswahl1_h[1] = 0.0;
    KitGewerk2_v14_B.Auswahl1_h[2] = 0.0;
    KitGewerk2_v14_B.Auswahl2_e[0] = 0.0;
    KitGewerk2_v14_B.Auswahl2_e[1] = 0.0;
    KitGewerk2_v14_B.Auswahl2_e[2] = 0.0;
    KitGewerk2_v14_B.Auswahl3_m[0] = 0.0;
    KitGewerk2_v14_B.Auswahl3_m[1] = 0.0;
    KitGewerk2_v14_B.Auswahl3_m[2] = 0.0;
    KitGewerk2_v14_B.Auswahl4_i[0] = 0.0;
    KitGewerk2_v14_B.Auswahl4_i[1] = 0.0;
    KitGewerk2_v14_B.Auswahl4_i[2] = 0.0;
    KitGewerk2_v14_B.Auswahl5_m = 0.0;
    KitGewerk2_v14_B.Auswahl6_k = 0.0;
    KitGewerk2_v14_B.Auswahl7_b = 0.0;
    KitGewerk2_v14_B.Auswahl8 = 0.0;
    KitGewerk2_v14_B.Gain_o = 0.0;
    KitGewerk2_v14_B.constant3 = 0.0;
    KitGewerk2_v14_B.constant4 = 0.0;
    KitGewerk2_v14_B.constant5 = 0.0;
    KitGewerk2_v14_B.Unpack_o = 0.0;
    KitGewerk2_v14_B.enable_out[0] = 0.0;
    KitGewerk2_v14_B.enable_out[1] = 0.0;
    KitGewerk2_v14_B.direction_motor0_out = 0.0;
    KitGewerk2_v14_B.velocity_motor0_out = 0.0;
    KitGewerk2_v14_B.direction_motor1_out = 0.0;
    KitGewerk2_v14_B.velocity_motor1_out = 0.0;
    KitGewerk2_v14_B.direction_motor2_out = 0.0;
    KitGewerk2_v14_B.velocity_motor2_out = 0.0;
    KitGewerk2_v14_B.stop_out = 0.0;
    KitGewerk2_v14_B.stop_flag_out[0] = 0.0;
    KitGewerk2_v14_B.stop_flag_out[1] = 0.0;
    KitGewerk2_v14_B.stop_flag_out[2] = 0.0;
    KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[0] = 0.0;
    KitGewerk2_v14_B.TmpSignalConversionAtSFunctionI[1] = 0.0;
    KitGewerk2_v14_B.direction_motor0_out_p = 0.0;
    KitGewerk2_v14_B.velocity_motor0_out_d = 0.0;
    KitGewerk2_v14_B.direction_motor1_out_d = 0.0;
    KitGewerk2_v14_B.velocity_motor1_out_f = 0.0;
    KitGewerk2_v14_B.direction_motor2_out_k = 0.0;
    KitGewerk2_v14_B.velocity_motor2_out_n = 0.0;
    KitGewerk2_v14_B.di03_bump_out = 0.0;
    KitGewerk2_v14_B.bumper_out[0] = 0.0;
    KitGewerk2_v14_B.bumper_out[1] = 0.0;
    KitGewerk2_v14_B.bumper_out[2] = 0.0;
    KitGewerk2_v14_B.v_x_out = 0.0;
    KitGewerk2_v14_B.v_y_out = 0.0;
    KitGewerk2_v14_B.v_theta_out = 0.0;
    KitGewerk2_v14_B.light_barrier = 0.0;
    KitGewerk2_v14_B.slider = 0.0;
    KitGewerk2_v14_B.Output_SOC = 0.0;
    KitGewerk2_v14_B.Laden = 0.0;
    KitGewerk2_v14_B.SOC = 0.0;
    KitGewerk2_v14_B.y = 0.0;
    KitGewerk2_v14_B.y_k = 0.0;
    KitGewerk2_v14_B.Output_Flag = 0.0;
    KitGewerk2_v14_B.Output_Flag_d = 0.0;
    KitGewerk2_v14_B.d_Y_soll = 0.0;
    KitGewerk2_v14_B.d_X_soll = 0.0;
    KitGewerk2_v14_B.d_Phi_soll = 0.0;
    KitGewerk2_v14_B.d_V_Max_soll = 0.0;
    KitGewerk2_v14_B.Constant1[0] = 0.0;
    KitGewerk2_v14_B.Constant1[1] = 0.0;
    KitGewerk2_v14_B.Constant2[0] = 0.0;
    KitGewerk2_v14_B.Constant2[1] = 0.0;
    KitGewerk2_v14_B.Receivefromall_o2 = 0.0;
    KitGewerk2_v14_B.Receivefromall_o2_a = 0.0;
    KitGewerk2_v14_B.Receivefromall_o2_m = 0.0;
    KitGewerk2_v14_B.Receivefromall_o2_ae = 0.0;
    KitGewerk2_v14_B.wout = 0.0;
    KitGewerk2_v14_B.wout_p = 0.0;
    KitGewerk2_v14_B.wout_m = 0.0;
  }

  /* parameters */
  KitGewerk2_v14_M->ModelData.defaultParam = ((real_T *)&KitGewerk2_v14_P);

  /* states (dwork) */
  KitGewerk2_v14_M->ModelData.dwork = ((void *) &KitGewerk2_v14_DW);
  (void) memset((void *)&KitGewerk2_v14_DW, 0,
                sizeof(DW_KitGewerk2_v14_T));

  {
    int_T i;
    for (i = 0; i < 102; i++) {
      KitGewerk2_v14_DW.lasterrorfreeresponse_PreviousI[i] = 0.0;
    }
  }

  KitGewerk2_v14_DW.stopmarker_PreviousInput[0] = 0.0;
  KitGewerk2_v14_DW.stopmarker_PreviousInput[1] = 0.0;
  KitGewerk2_v14_DW.stopmarker_PreviousInput[2] = 0.0;
  KitGewerk2_v14_DW.Sum_DWORK1 = 0.0;

  /* external outputs */
  KitGewerk2_v14_M->ModelData.outputs = (&KitGewerk2_v14_Y);

  {
    int_T i;
    for (i = 0; i < 102; i++) {
      KitGewerk2_v14_Y.Robotinorawdata[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 15; i++) {
      KitGewerk2_v14_Y.Robotinoprocesseddata[i] = 0.0;
    }
  }

  {
    int_T i;
    for (i = 0; i < 56; i++) {
      KitGewerk2_v14_Y.UDPdata[i] = 0.0;
    }
  }

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    KitGewerk2_v14_M->SpecialInfo.mappingInfo = (&dtInfo);
    KitGewerk2_v14_M->SpecialInfo.xpcData = ((void*) &dtInfo);
    dtInfo.numDataTypes = 17;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  KitGewerk2_v14_InitializeDataMapInfo(KitGewerk2_v14_M);

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &KitGewerk2_v14_M->NonInlinedSFcns.sfcnInfo;
    KitGewerk2_v14_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(KitGewerk2_v14_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &KitGewerk2_v14_M->Sizes.numSampTimes);
    KitGewerk2_v14_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (KitGewerk2_v14_M)[0]);
    KitGewerk2_v14_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (KitGewerk2_v14_M)[1]);
    KitGewerk2_v14_M->NonInlinedSFcns.taskTimePtrs[2] = &(rtmGetTPtr
      (KitGewerk2_v14_M)[2]);
    KitGewerk2_v14_M->NonInlinedSFcns.taskTimePtrs[3] = &(rtmGetTPtr
      (KitGewerk2_v14_M)[3]);
    KitGewerk2_v14_M->NonInlinedSFcns.taskTimePtrs[4] = &(rtmGetTPtr
      (KitGewerk2_v14_M)[4]);
    rtssSetTPtrPtr(sfcnInfo,KitGewerk2_v14_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(KitGewerk2_v14_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(KitGewerk2_v14_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (KitGewerk2_v14_M));
    rtssSetStepSizePtr(sfcnInfo, &KitGewerk2_v14_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(KitGewerk2_v14_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &KitGewerk2_v14_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &KitGewerk2_v14_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &KitGewerk2_v14_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &KitGewerk2_v14_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &KitGewerk2_v14_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &KitGewerk2_v14_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &KitGewerk2_v14_M->solverInfoPtr);
  }

  KitGewerk2_v14_M->Sizes.numSFcns = (31);

  /* register each child */
  {
    (void) memset((void *)&KitGewerk2_v14_M->NonInlinedSFcns.childSFunctions[0],
                  0,
                  31*sizeof(SimStruct));
    KitGewerk2_v14_M->childSfunctions =
      (&KitGewerk2_v14_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 31; i++) {
        KitGewerk2_v14_M->childSfunctions[i] =
          (&KitGewerk2_v14_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S14>/Receive from all (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[0]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            KitGewerk2_v14_B.Receivefromall_o1_g));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &KitGewerk2_v14_B.Receivefromall_o2_ae));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive from all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Receivefromall_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Receivefromall_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Receivefromall_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Receivefromall_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Receivefromall_P5_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Receivefromall_IWORK_h[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Receivefromall_PWORK_m);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Receivefromall_IWORK_h[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Receivefromall_PWORK_m);
      }

      /* registration */
      xpcudpbytereceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S14>/Send to all (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[1]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               KitGewerk2_v14_B.RateTransitiondownsamplingto5_o);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 4);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send to all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 4/Send to all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Sendtoall_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Sendtoall_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Sendtoall_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Sendtoall_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Sendtoall_P5_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Sendtoall_IWORK_o[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Sendtoall_PWORK_b);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Sendtoall_IWORK_o[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Sendtoall_PWORK_b);
      }

      /* registration */
      xpcudpbytesend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 4);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S13>/Receive from all (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[2]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            KitGewerk2_v14_B.Receivefromall_o1_j));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &KitGewerk2_v14_B.Receivefromall_o2_m));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive from all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P1_Size_i);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P2_Size_f);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P3_Size_g);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P4_Size_m);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P5_Size_l);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Receivefromall_IWORK_e[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Receivefromall_PWORK_j);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Receivefromall_IWORK_e[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Receivefromall_PWORK_j);
      }

      /* registration */
      xpcudpbytereceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S13>/Send to all (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[3]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               KitGewerk2_v14_B.RateTransitiondownsamplingto5_o);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 4);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send to all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 3/Send to all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Sendtoall_P1_Size_j);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Sendtoall_P2_Size_i);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Sendtoall_P3_Size_m);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Sendtoall_P4_Size_p);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Sendtoall_P5_Size_p);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Sendtoall_IWORK_j[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Sendtoall_PWORK_f);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Sendtoall_IWORK_j[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Sendtoall_PWORK_f);
      }

      /* registration */
      xpcudpbytesend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 4);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S12>/Receive from all (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[4]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            KitGewerk2_v14_B.Receivefromall_o1_p));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &KitGewerk2_v14_B.Receivefromall_o2_a));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive from all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P1_Size_g);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P2_Size_c);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P3_Size_gk);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P4_Size_c);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P5_Size_g);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Receivefromall_IWORK_i[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Receivefromall_PWORK_g);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Receivefromall_IWORK_i[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Receivefromall_PWORK_g);
      }

      /* registration */
      xpcudpbytereceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S12>/Send to all (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[5]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               KitGewerk2_v14_B.RateTransitiondownsamplingto5_o);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 4);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send to all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 2/Send to all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Sendtoall_P1_Size_c);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Sendtoall_P2_Size_l);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Sendtoall_P3_Size_n);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Sendtoall_P4_Size_o);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Sendtoall_P5_Size_n);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Sendtoall_IWORK_m[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Sendtoall_PWORK_j);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn5.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Sendtoall_IWORK_m[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Sendtoall_PWORK_j);
      }

      /* registration */
      xpcudpbytesend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 4);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S11>/Receive from all (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[6]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[6]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            KitGewerk2_v14_B.Receivefromall_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &KitGewerk2_v14_B.Receivefromall_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive from all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P1_Size_b);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P2_Size_o);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P3_Size_b);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P4_Size_e);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       KitGewerk2_v14_P.Receivefromall_P5_Size_gi);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Receivefromall_IWORK[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Receivefromall_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn6.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Receivefromall_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Receivefromall_PWORK);
      }

      /* registration */
      xpcudpbytereceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S11>/Send to all (xpcudpbytesend) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[7]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               KitGewerk2_v14_B.RateTransitiondownsamplingto5_o);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 4);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send to all");
      ssSetPath(rts,
                "KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 1/Send to all");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Sendtoall_P1_Size_e);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Sendtoall_P2_Size_f);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Sendtoall_P3_Size_h);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Sendtoall_P4_Size_e);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Sendtoall_P5_Size_l);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Sendtoall_IWORK[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Sendtoall_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn7.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Sendtoall_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Sendtoall_PWORK);
      }

      /* registration */
      xpcudpbytesend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.5);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 4);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S21>/S-Function (bahnplaner_v22) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[8]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[8]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, KitGewerk2_v14_B.Constant2);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 2);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, KitGewerk2_v14_B.Constant1);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 2);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, KitGewerk2_v14_B.Constant3);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 6);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 200);
          ssSetOutputPortSignal(rts, 0, ((real_T *) KitGewerk2_v14_B.Wegpunkte));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 200);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            KitGewerk2_v14_B.SFunction_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
                "KitGewerk2_v14/Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Subsystem/S-Function");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.SFunction_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn8.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.SFunction_PWORK);
      }

      /* registration */
      bahnplaner_v22(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S37>/FIFO write 1 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[9];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[9]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[9]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[9]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[9]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, KitGewerk2_v14_B.ReadHWFIFO1_c);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 65);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite1_c));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P5_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite1_IWORK_e[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite1_PWORK_o);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn9.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite1_IWORK_e[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite1_PWORK_o);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -2.0);
      sfcnTsMap[0] = 3;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 65);
      ssSetInputPortDataType(rts, 0, SS_UINT32);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S39>/FIFO read 1 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[10];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn10.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn10.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn10.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[10]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[10]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[10]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[10]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn10.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition_g);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &KitGewerk2_v14_B.ReadIntStatusFC1_o2_c);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, &KitGewerk2_v14_B.Constant1_o);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn10.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 61);
          ssSetOutputPortSignal(rts, 0, ((uint32_T *)
            KitGewerk2_v14_B.FIFOread1_o1_a));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *)
            &KitGewerk2_v14_B.FIFOread1_o2_i));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn10.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread1_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread1_P8_Size);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -2.0);
      sfcnTsMap[0] = 3;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S38>/FIFO write 2 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[11];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[11]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[11]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[11]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[11]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, KitGewerk2_v14_B.ReadHWFIFO2_o);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 65);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite2_a));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P5_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite2_IWORK_h[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite2_PWORK_e);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn11.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite2_IWORK_h[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite2_PWORK_e);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -2.0);
      sfcnTsMap[0] = 3;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 65);
      ssSetInputPortDataType(rts, 0, SS_UINT32);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S40>/FIFO read 2 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[12];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn12.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn12.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn12.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[12]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[12]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[12]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[12]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn12.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition2_m);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &KitGewerk2_v14_B.ReadIntStatusFC1_o2_c);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, &KitGewerk2_v14_B.Constant2_k);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn12.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 61);
          ssSetOutputPortSignal(rts, 0, ((uint32_T *)
            KitGewerk2_v14_B.FIFOread2_o1_a));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *)
            &KitGewerk2_v14_B.FIFOread2_o2_k));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn12.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread2_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread2_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread2_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread2_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread2_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread2_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread2_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread2_P8_Size);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -2.0);
      sfcnTsMap[0] = 3;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S52>/FIFO write 1 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[13];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[13]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[13]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[13]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[13]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, KitGewerk2_v14_B.ReadHWFIFO1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 65);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite1));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P1_Size_f);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P2_Size_i);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P3_Size_m);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P4_Size_l);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P5_Size_b);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite1_IWORK_o[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite1_PWORK_h);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn13.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite1_IWORK_o[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite1_PWORK_h);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -3.0);
      sfcnTsMap[0] = 4;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 65);
      ssSetInputPortDataType(rts, 0, SS_UINT32);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S54>/FIFO read 1 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[14];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn14.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn14.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn14.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[14]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[14]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[14]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[14]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn14.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &KitGewerk2_v14_B.ReadIntStatusFC1_o2);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, &KitGewerk2_v14_B.Constant1_d);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn14.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 61);
          ssSetOutputPortSignal(rts, 0, ((uint32_T *)
            KitGewerk2_v14_B.FIFOread1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *)
            &KitGewerk2_v14_B.FIFOread1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn14.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread1_P1_Size_k);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread1_P2_Size_f);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread1_P3_Size_k);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread1_P4_Size_o);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread1_P5_Size_d);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread1_P6_Size_f);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread1_P7_Size_b);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread1_P8_Size_k);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -3.0);
      sfcnTsMap[0] = 4;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S53>/FIFO write 2 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[15];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[15]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[15]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[15]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[15]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, KitGewerk2_v14_B.ReadHWFIFO2);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 65);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite2));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P1_Size_d);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P3_Size_e);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P4_Size_p);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P5_Size_f);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite2_IWORK_m[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite2_PWORK_i);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn15.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite2_IWORK_m[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite2_PWORK_i);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -3.0);
      sfcnTsMap[0] = 4;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 65);
      ssSetInputPortDataType(rts, 0, SS_UINT32);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S55>/FIFO read 2 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[16];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn16.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn16.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn16.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[16]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[16]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[16]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[16]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn16.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition2);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &KitGewerk2_v14_B.ReadIntStatusFC1_o2);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, &KitGewerk2_v14_B.Constant2_h);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn16.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 61);
          ssSetOutputPortSignal(rts, 0, ((uint32_T *)
            KitGewerk2_v14_B.FIFOread2_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *)
            &KitGewerk2_v14_B.FIFOread2_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn16.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread2_P1_Size_j);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread2_P2_Size_n);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread2_P3_Size_h);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread2_P4_Size_d);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread2_P5_Size_i);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread2_P6_Size_h);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread2_P7_Size_b);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread2_P8_Size_j);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, -1.0);
      ssSetOffsetTime(rts, 0, -3.0);
      sfcnTsMap[0] = 4;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S57>/From File (xpcfromfile) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[17];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[17]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[17]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[17]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[17]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 8);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) KitGewerk2_v14_B.FromFile));
        }
      }

      /* path info */
      ssSetModelName(rts, "From File");
      ssSetPath(rts, "KitGewerk2_v14/getRobotinoID/getIDfromFlash/From File");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FromFile_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FromFile_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FromFile_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FromFile_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FromFile_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FromFile_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FromFile_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FromFile_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn17.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FromFile_IWORK[0]);
      }

      /* registration */
      xpcfromfile(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S47>/FIFO read 1 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[18];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn18.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn18.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn18.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[18]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[18]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[18]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[18]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn18.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn18.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 102);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *) KitGewerk2_v14_B.FIFOread1));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/FIFO read 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn18.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread1_P1_Size_d);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread1_P2_Size_k);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread1_P3_Size_i);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread1_P4_Size_b);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread1_P5_Size_o);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread1_P6_Size_e);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread1_P7_Size_g);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread1_P8_Size_o);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S8>/Receive (xpcudpbytereceive) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[19];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[19]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[19]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[19]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[19]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 448);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) KitGewerk2_v14_B.Receive_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &KitGewerk2_v14_B.Receive_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive");
      ssSetPath(rts, "KitGewerk2_v14/UDP interface/Receive");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Receive_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Receive_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Receive_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Receive_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Receive_P5_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Receive_IWORK[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.Receive_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn19.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Receive_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.Receive_PWORK);
      }

      /* registration */
      xpcudpbytereceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S34>/FIFO read 1 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[20];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn20.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn20.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn20.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[20]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[20]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[20]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[20]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn20.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition1_g);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn20.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 4);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *)
            KitGewerk2_v14_B.FIFOread1_j));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn20.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread1_P1_Size_h);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread1_P2_Size_o);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread1_P3_Size_a);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread1_P4_Size_f);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread1_P5_Size_e);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread1_P6_Size_l);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread1_P7_Size_c);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread1_P8_Size_f);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S34>/FIFO write 1 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[21];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[21]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[21]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[21]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[21]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.DataTypeConversion5_i);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((boolean_T *)
            &KitGewerk2_v14_B.FIFOwrite1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P1_Size_o);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P2_Size_d);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P3_Size_i);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P4_Size_p);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P5_Size_n);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite1_IWORK[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn21.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite1_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite1_PWORK);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 1);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S34>/FIFO write 2 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[22];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[22]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[22]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[22]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[22]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, (uint8_T*)&KitGewerk2_v14_U8GND);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite2_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((boolean_T *)
            &KitGewerk2_v14_B.FIFOwrite2_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P1_Size_a);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P2_Size_n);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P3_Size_j);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P4_Size_i);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P5_Size_fb);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite2_IWORK[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite2_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn22.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite2_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite2_PWORK);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 1);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S34>/FIFO read 2 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[23];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn23.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn23.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn23.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[23]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[23]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[23]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[23]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn23.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition3);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn23.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 102);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            KitGewerk2_v14_B.FIFOread2_c));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn23.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread2_P1_Size_b);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread2_P2_Size_b);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread2_P3_Size_i);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread2_P4_Size_a);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread2_P5_Size_m);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread2_P6_Size_h1);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread2_P7_Size_g);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread2_P8_Size_o);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S34>/Setup1 (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[24];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn24.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn24.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn24.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[24]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[24]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[24]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[24]);
      }

      /* path info */
      ssSetModelName(rts, "Setup1");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn24.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Setup1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Setup1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Setup1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Setup1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Setup1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.Setup1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.Setup1_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.Setup1_P8_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Setup1_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn24.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn24.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Setup1_IWORK[0]);
      }

      /* registration */
      sersetupbase(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S34>/Setup2 (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[25];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn25.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn25.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn25.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[25]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[25]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[25]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[25]);
      }

      /* path info */
      ssSetModelName(rts, "Setup2");
      ssSetPath(rts,
                "KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn25.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Setup2_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Setup2_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Setup2_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Setup2_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Setup2_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.Setup2_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.Setup2_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.Setup2_P8_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Setup2_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn25.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn25.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Setup2_IWORK[0]);
      }

      /* registration */
      sersetupbase(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S47>/FIFO write 1 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[26];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[26]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[26]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[26]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[26]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, KitGewerk2_v14_B.doubletouint16);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 48);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite1_o1_o));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((boolean_T *)
            &KitGewerk2_v14_B.FIFOwrite1_o2_n));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 1");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/FIFO write 1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P1_Size_b);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P2_Size_k);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P3_Size_g);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P4_Size_f);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite1_P5_Size_j);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite1_IWORK_f[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite1_PWORK_i);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn26.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite1_IWORK_f[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite1_PWORK_i);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 48);
      ssSetInputPortDataType(rts, 0, SS_UINT16);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S47>/FIFO write 2 (fifowrite) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[27];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[27]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[27]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[27]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[27]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, (uint16_T*)&KitGewerk2_v14_U16GND);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((serialfifoptr *)
            &KitGewerk2_v14_B.FIFOwrite2_o1_k));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((boolean_T *)
            &KitGewerk2_v14_B.FIFOwrite2_o2_j));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO write 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/FIFO write 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P1_Size_dz);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P2_Size_c);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P3_Size_b);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P4_Size_c);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOwrite2_P5_Size_o);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.FIFOwrite2_IWORK_j[0]);
      ssSetPWork(rts, (void **) &KitGewerk2_v14_DW.FIFOwrite2_PWORK_a);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn27.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.FIFOwrite2_IWORK_j[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &KitGewerk2_v14_DW.FIFOwrite2_PWORK_a);
      }

      /* registration */
      fifowrite(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 1);
      ssSetInputPortDataType(rts, 0, SS_UINT16);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S47>/FIFO read 2 (fiforead) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[28];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn28.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn28.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn28.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[28]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[28]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[28]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[28]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn28.inputPortInfo[0]);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &KitGewerk2_v14_B.RateTransition3_e);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn28.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 102);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *) KitGewerk2_v14_B.FIFOread2));
        }
      }

      /* path info */
      ssSetModelName(rts, "FIFO read 2");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/FIFO read 2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn28.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.FIFOread2_P1_Size_c);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.FIFOread2_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.FIFOread2_P3_Size_o);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.FIFOread2_P4_Size_o);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.FIFOread2_P5_Size_h);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.FIFOread2_P6_Size_a);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.FIFOread2_P7_Size_g0);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.FIFOread2_P8_Size_b);
      }

      /* registration */
      fiforead(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S47>/Setup1 (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[29];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn29.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn29.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn29.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[29]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[29]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[29]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[29]);
      }

      /* path info */
      ssSetModelName(rts, "Setup1");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/Setup1");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn29.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Setup1_P1_Size_m);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Setup1_P2_Size_c);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Setup1_P3_Size_c);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Setup1_P4_Size_k);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Setup1_P5_Size_m);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.Setup1_P6_Size_o);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.Setup1_P7_Size_c);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.Setup1_P8_Size_l);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Setup1_IWORK_l[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn29.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn29.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Setup1_IWORK_l[0]);
      }

      /* registration */
      sersetupbase(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: KitGewerk2_v14/<S47>/Setup2 (sersetupbase) */
    {
      SimStruct *rts = KitGewerk2_v14_M->childSfunctions[30];

      /* timing info */
      time_T *sfcnPeriod = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn30.sfcnPeriod;
      time_T *sfcnOffset = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn30.sfcnOffset;
      int_T *sfcnTsMap = KitGewerk2_v14_M->NonInlinedSFcns.Sfcn30.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &KitGewerk2_v14_M->NonInlinedSFcns.blkInfo2[30]);
      }

      ssSetRTWSfcnInfo(rts, KitGewerk2_v14_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods2[30]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &KitGewerk2_v14_M->NonInlinedSFcns.methods3[30]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &KitGewerk2_v14_M->NonInlinedSFcns.statesInfo2[30]);
      }

      /* path info */
      ssSetModelName(rts, "Setup2");
      ssSetPath(rts,
                "KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/Setup2");
      ssSetRTModel(rts,KitGewerk2_v14_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn30.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)KitGewerk2_v14_P.Setup2_P1_Size_e);
        ssSetSFcnParam(rts, 1, (mxArray*)KitGewerk2_v14_P.Setup2_P2_Size_b);
        ssSetSFcnParam(rts, 2, (mxArray*)KitGewerk2_v14_P.Setup2_P3_Size_k);
        ssSetSFcnParam(rts, 3, (mxArray*)KitGewerk2_v14_P.Setup2_P4_Size_g);
        ssSetSFcnParam(rts, 4, (mxArray*)KitGewerk2_v14_P.Setup2_P5_Size_o);
        ssSetSFcnParam(rts, 5, (mxArray*)KitGewerk2_v14_P.Setup2_P6_Size_m);
        ssSetSFcnParam(rts, 6, (mxArray*)KitGewerk2_v14_P.Setup2_P7_Size_c);
        ssSetSFcnParam(rts, 7, (mxArray*)KitGewerk2_v14_P.Setup2_P8_Size_k);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &KitGewerk2_v14_DW.Setup2_IWORK_m[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn30.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &KitGewerk2_v14_M->NonInlinedSFcns.Sfcn30.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &KitGewerk2_v14_DW.Setup2_IWORK_m[0]);
      }

      /* registration */
      sersetupbase(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Initialize Sizes */
  KitGewerk2_v14_M->Sizes.numContStates = (0);/* Number of continuous states */
  KitGewerk2_v14_M->Sizes.numY = (173);/* Number of model outputs */
  KitGewerk2_v14_M->Sizes.numU = (0);  /* Number of model inputs */
  KitGewerk2_v14_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  KitGewerk2_v14_M->Sizes.numSampTimes = (3);/* Number of sample times */
  KitGewerk2_v14_M->Sizes.numBlocks = (250);/* Number of blocks */
  KitGewerk2_v14_M->Sizes.numBlockIO = (192);/* Number of block outputs */
  KitGewerk2_v14_M->Sizes.numBlockPrms = (1099);/* Sum of parameter "widths" */
  return KitGewerk2_v14_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
