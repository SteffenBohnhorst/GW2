/*
 * KitGewerk2_v14_capi.c
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "KitGewerk2_v14.h"
#include "rtw_capi.h"
#include "KitGewerk2_v14_private.h"

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 1, "Begrenzung",
    "wout", 0, 0, 0, 0, 0 },

  { 1, 2, "Begrenzung1",
    "wout", 0, 0, 0, 0, 0 },

  { 2, 3, "Begrenzung2",
    "wout", 0, 0, 0, 0, 0 },

  { 3, 0, "constant3",
    "", 0, 0, 0, 0, 0 },

  { 4, 0, "constant4",
    "", 0, 0, 0, 0, 0 },

  { 5, 0, "constant5",
    "", 0, 0, 0, 0, 0 },

  { 6, 0, "Data Type Conversion",
    "", 0, 0, 0, 0, 0 },

  { 7, 0, "Data Type Conversion1",
    "", 0, 1, 0, 0, 0 },

  { 8, 0, "Gain",
    "", 0, 0, 0, 0, 0 },

  { 9, 0, "Add",
    "", 0, 0, 0, 0, 0 },

  { 10, 0, "Communication Block/Data Type Conversion1",
    "", 0, 1, 0, 0, 0 },

  { 11, 0, "Communication Block/Data Type Conversion2",
    "", 0, 1, 0, 0, 0 },

  { 12, 0, "Communication Block/Data Type Conversion3",
    "", 0, 1, 0, 0, 0 },

  { 13, 0, "Communication Block/Data Type Conversion4",
    "", 0, 1, 0, 0, 0 },

  { 14, 0, "Communication Block/Data Type Conversion5",
    "", 0, 1, 0, 0, 0 },

  { 15, 0, "Communication Block/Data Type Conversion6",
    "", 0, 2, 0, 0, 0 },

  { 16, 0, "Communication Block/Data Type Conversion7",
    "", 0, 1, 0, 0, 0 },

  { 17, 0, "Communication Block/Data Type Conversion8",
    "", 0, 1, 0, 0, 0 },

  { 18, 0, "Communication Block/Data Type Conversion9",
    "", 0, 1, 0, 0, 0 },

  { 19, 0, "Communication Block/Pack",
    "", 0, 1, 1, 0, 0 },

  { 20, 0, "Communication Block/Unpack/p1",
    "", 0, 1, 0, 0, 0 },

  { 21, 0, "Communication Block/Unpack/p2",
    "", 1, 1, 0, 0, 0 },

  { 22, 0, "Communication Block/Unpack/p3",
    "", 2, 1, 0, 0, 0 },

  { 23, 0, "Communication Block/Unpack/p4",
    "", 3, 1, 0, 0, 0 },

  { 24, 0, "Communication Block/Unpack/p5",
    "", 4, 1, 0, 0, 0 },

  { 25, 9, "Gewerk_2/Chart/p1",
    "A_WPL", 0, 0, 2, 0, 0 },

  { 26, 9, "Gewerk_2/Chart/p2",
    "B_Stop", 1, 2, 0, 0, 0 },

  { 27, 9, "Gewerk_2/Chart/p3",
    "B_WP_weiter", 2, 2, 0, 0, 0 },

  { 28, 9, "Gewerk_2/Chart/p4",
    "B_Greifer", 3, 2, 0, 0, 0 },

  { 29, 9, "Gewerk_2/Chart/p5",
    "B_WPL_cnt_reset", 4, 2, 0, 0, 0 },

  { 30, 9, "Gewerk_2/Chart/p6",
    "UI_to_GW1", 5, 1, 0, 0, 0 },

  { 31, 9, "Gewerk_2/Chart/p7",
    "A_stern_test", 6, 0, 3, 0, 0 },

  { 32, 10, "Gewerk_2/Kollisionserkennung",
    "b_stop", 0, 2, 0, 0, 0 },

  { 33, 11, "Gewerk_2/MATLAB Function/p1",
    "d_Y_soll", 0, 0, 0, 0, 0 },

  { 34, 11, "Gewerk_2/MATLAB Function/p2",
    "d_X_soll", 1, 0, 0, 0, 0 },

  { 35, 11, "Gewerk_2/MATLAB Function/p3",
    "d_Phi_soll", 2, 0, 0, 0, 0 },

  { 36, 11, "Gewerk_2/MATLAB Function/p4",
    "d_V_Max_soll", 3, 0, 0, 0, 0 },

  { 37, 0, "Gewerk_2/Constant",
    "", 0, 2, 0, 0, 0 },

  { 38, 0, "Gewerk_2/Constant2",
    "", 0, 2, 0, 0, 0 },

  { 39, 0, "Gewerk_2/Constant4",
    "", 0, 1, 0, 0, 0 },

  { 40, 0, "Gewerk_2/Constant5",
    "", 0, 2, 0, 0, 0 },

  { 41, 0, "Gewerk_2/Constant7",
    "", 0, 2, 0, 0, 0 },

  { 42, 0, "Gewerk_2/Wegpunktliste zum Testen",
    "", 0, 0, 4, 0, 0 },

  { 43, 0, "Gewerk_2/Data Type Conversion",
    "", 0, 2, 0, 0, 0 },

  { 44, 0, "Gewerk_2/Data Type Conversion1",
    "", 0, 0, 0, 0, 0 },

  { 45, 0, "Gewerk_2/Relational Operator",
    "", 0, 2, 0, 0, 0 },

  { 46, 0, "Gewerk_2/Counter/p1",
    "", 0, 3, 0, 0, 0 },

  { 47, 0, "Gewerk_2/Counter/p2",
    "", 1, 2, 0, 0, 0 },

  { 48, 12, "Power Management Gewerk 4/Output_Flag-Comparison: Blei oder Li-ION",
    "Output_Flag", 0, 0, 0, 0, 0 },

  { 49, 24, "Power Management Gewerk 4/SOC-Comparison: Blei oder Li-ION",
    "Output_SOC", 0, 0, 0, 0, 0 },

  { 50, 25, "Robotino/assemble robotino response",
    "robotino_response", 0, 0, 5, 0, 0 },

  { 51, 26, "Robotino/distance converter",
    "dms_out", 0, 0, 6, 0, 0 },

  { 52, 27, "Robotino/light barrier & slider/p1",
    "light_barrier", 0, 0, 0, 0, 0 },

  { 53, 27, "Robotino/light barrier & slider/p2",
    "slider", 1, 0, 0, 0, 0 },

  { 54, 28, "Robotino/receive direction, unit & velocity converter/p1",
    "v_x_out", 0, 0, 0, 0, 0 },

  { 55, 28, "Robotino/receive direction, unit & velocity converter/p2",
    "v_y_out", 1, 0, 0, 0, 0 },

  { 56, 28, "Robotino/receive direction, unit & velocity converter/p3",
    "v_theta_out", 2, 0, 0, 0, 0 },

  { 57, 37, "Robotino/transmit velocity, unit & direction converter/p1",
    "direction_motor0_out", 0, 0, 0, 0, 0 },

  { 58, 37, "Robotino/transmit velocity, unit & direction converter/p2",
    "velocity_motor0_out", 1, 0, 0, 0, 0 },

  { 59, 37, "Robotino/transmit velocity, unit & direction converter/p3",
    "direction_motor1_out", 2, 0, 0, 0, 0 },

  { 60, 37, "Robotino/transmit velocity, unit & direction converter/p4",
    "velocity_motor1_out", 3, 0, 0, 0, 0 },

  { 61, 37, "Robotino/transmit velocity, unit & direction converter/p5",
    "direction_motor2_out", 4, 0, 0, 0, 0 },

  { 62, 37, "Robotino/transmit velocity, unit & direction converter/p6",
    "velocity_motor2_out", 5, 0, 0, 0, 0 },

  { 63, 0, "Robotino/Gain",
    "", 0, 0, 0, 0, 0 },

  { 64, 38, "UDP interface/stop signals",
    "enable_out", 0, 0, 7, 0, 0 },

  { 65, 0, "UDP interface/Receive/p1",
    "", 0, 1, 8, 0, 0 },

  { 66, 0, "UDP interface/Receive/p2",
    "", 1, 0, 0, 0, 0 },

  { 67, 0, "UDP interface/Unpack",
    "", 0, 0, 9, 0, 0 },

  { 68, 0, "getRobotinoID/Step",
    "", 0, 0, 0, 0, 1 },

  { 69, 0, "Communication Block/Robotino UDP transceiver/Multiport Switch",
    "", 0, 1, 10, 0, 2 },

  { 70, 0,
    "Communication Block/Robotino UDP transceiver/Rate Transition down-sampling to 500 ms",
    "", 0, 1, 1, 0, 2 },

  { 71, 0,
    "Communication Block/Robotino UDP transceiver/Rate Transition down-sampling to 500ms",
    "", 0, 0, 0, 0, 2 },

  { 72, 0,
    "Communication Block/Robotino UDP transceiver/Rate Transition up-sampling to fundamental sample time",
    "", 0, 1, 10, 0, 0 },

  { 73, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl1",
    "", 0, 0, 0, 0, 0 },

  { 74, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl2",
    "", 0, 0, 0, 0, 0 },

  { 75, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl3",
    "", 0, 0, 0, 0, 0 },

  { 76, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl4",
    "", 0, 0, 0, 0, 0 },

  { 77, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl5",
    "", 0, 0, 0, 0, 0 },

  { 78, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl6",
    "", 0, 0, 11, 0, 0 },

  { 79, 0, "Gewerk_2/Ausg�nge Robotino/Auswahl7",
    "", 0, 0, 0, 0, 0 },

  { 80, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl1",
    "", 0, 0, 12, 0, 0 },

  { 81, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl10",
    "", 0, 0, 13, 0, 0 },

  { 82, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl2",
    "", 0, 0, 12, 0, 0 },

  { 83, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl3",
    "", 0, 0, 12, 0, 0 },

  { 84, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl4",
    "", 0, 0, 12, 0, 0 },

  { 85, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl5",
    "", 0, 0, 0, 0, 0 },

  { 86, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl6",
    "", 0, 0, 0, 0, 0 },

  { 87, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl7",
    "", 0, 0, 0, 0, 0 },

  { 88, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl8",
    "", 0, 0, 0, 0, 0 },

  { 89, 0, "Gewerk_2/Ausg�nge UDP Interface1/Auswahl9",
    "", 0, 0, 14, 0, 0 },

  { 90, 23,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Microcontroller Data/p1",
    "SOC", 0, 1, 0, 0, 0 },

  { 91, 23,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Microcontroller Data/p2",
    "FLAG", 1, 1, 0, 0, 0 },

  { 92, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Data Type Conversion",
    "", 0, 1, 0, 0, 0 },

  { 93, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Data Type Conversion1",
    "", 0, 1, 0, 0, 0 },

  { 94, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Data Type Conversion2",
    "", 0, 1, 1, 0, 0 },

  { 95, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Data Type Conversion3",
    "", 0, 0, 0, 0, 0 },

  { 96, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Data Type Conversion4",
    "", 0, 0, 0, 0, 0 },

  { 97, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Data Type Conversion5",
    "", 0, 1, 0, 0, 0 },

  { 98, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Previous Flag",
    "", 0, 1, 0, 0, 0 },

  { 99, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Previous SOC",
    "", 0, 1, 0, 0, 0 },

  { 100, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p1",
    "direction_motor0_out", 0, 0, 0, 0, 0 },

  { 101, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p2",
    "velocity_motor0_out", 1, 0, 0, 0, 0 },

  { 102, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p3",
    "direction_motor1_out", 2, 0, 0, 0, 0 },

  { 103, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p4",
    "velocity_motor1_out", 3, 0, 0, 0, 0 },

  { 104, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p5",
    "direction_motor2_out", 4, 0, 0, 0, 0 },

  { 105, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p6",
    "velocity_motor2_out", 5, 0, 0, 0, 0 },

  { 106, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p7",
    "distance_measuring_sensors_out", 6, 0, 6, 0, 0 },

  { 107, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p8",
    "di03_bump_out", 7, 0, 0, 0, 0 },

  { 108, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p9",
    "bumper_out", 8, 0, 12, 0, 0 },

  { 109, 34,
    "Robotino/serial communication/error filter & protocol disassembler/p10",
    "error_free_resp_out", 9, 0, 15, 0, 0 },

  { 110, 35,
    "Robotino/serial communication/protocol adder & optional velocity adaption",
    "message", 0, 0, 16, 0, 0 },

  { 111, 36, "Robotino/serial communication/stop by bumper/p1",
    "stop_out", 0, 0, 0, 0, 0 },

  { 112, 36, "Robotino/serial communication/stop by bumper/p2",
    "stop_flag_out", 1, 0, 12, 0, 0 },

  { 113, 0, "Robotino/serial communication/double to uint16",
    "", 0, 4, 16, 0, 0 },

  { 114, 0, "Robotino/serial communication/uint16 to double",
    "", 0, 0, 15, 0, 0 },

  { 115, 0, "Robotino/serial communication/last error free response",
    "", 0, 0, 15, 0, 0 },

  { 116, 0, "Robotino/serial communication/stop marker",
    "", 0, 0, 12, 0, 0 },

  { 117, 39, "getRobotinoID/getIDfromFlash/From File",
    "", 0, 1, 14, 0, 3 },

  { 118, 39, "getRobotinoID/getIDfromFlash/Unpack",
    "", 0, 0, 0, 0, 3 },

  { 119, 4,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all/p1",
    "", 0, 1, 10, 0, 2 },

  { 120, 4,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all/p2",
    "", 1, 0, 0, 0, 2 },

  { 121, 5,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all/p1",
    "", 0, 1, 10, 0, 2 },

  { 122, 5,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all/p2",
    "", 1, 0, 0, 0, 2 },

  { 123, 6,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all/p1",
    "", 0, 1, 10, 0, 2 },

  { 124, 6,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all/p2",
    "", 1, 0, 0, 0, 2 },

  { 125, 7,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all/p1",
    "", 0, 1, 10, 0, 2 },

  { 126, 7,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all/p2",
    "", 1, 0, 0, 0, 2 },

  { 127, 8, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Constant1",
    "", 0, 0, 17, 0, 3 },

  { 128, 8, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Constant2",
    "", 0, 0, 17, 0, 3 },

  { 129, 8, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Constant3",
    "", 0, 0, 18, 0, 3 },

  { 130, 13,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Flag Communication Simulation",
    "Output_Flag", 0, 0, 0, 0, 0 },

  { 131, 14,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/MATLAB Function",
    "y", 0, 0, 0, 0, 0 },

  { 132, 15,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/MATLAB Function1",
    "y", 0, 0, 0, 0, 0 },

  { 133, 16,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Relais ansteuern1",
    "SOC", 0, 0, 0, 0, 0 },

  { 134, 17,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Unterscheidung Blei Gel Roboter an der virtuellen Ladestation",
    "Laden", 0, 0, 0, 0, 0 },

  { 135, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Data Type Conversion1",
    "", 0, 0, 0, 0, 0 },

  { 136, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Data Type Conversion2",
    "", 0, 0, 0, 0, 0 },

  { 137, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Data Type Conversion3",
    "", 0, 0, 0, 0, 0 },

  { 138, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Gain",
    "", 0, 0, 0, 0, 0 },

  { 139, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Gain1",
    "", 0, 5, 0, 1, 0 },

  { 140, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Memory",
    "", 0, 4, 0, 0, 0 },

  { 141, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Memory1",
    "", 0, 5, 0, 0, 0 },

  { 142, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Charging Counter",
    "", 0, 4, 0, 0, 0 },

  { 143, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Discharging Counter",
    "", 0, 5, 0, 0, 0 },

  { 144, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Sum",
    "", 0, 0, 0, 0, 0 },

  { 145, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Rate Transition",
    "", 0, 6, 0, 0, 4 },

  { 146, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Rate Transition1",
    "", 0, 6, 0, 0, 0 },

  { 147, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Rate Transition2",
    "", 0, 6, 0, 0, 4 },

  { 148, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Rate Transition3",
    "", 0, 6, 0, 0, 0 },

  { 149, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "", 0, 4, 1, 0, 0 },

  { 150, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "", 0, 1, 15, 0, 0 },

  { 151, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1/p1",
    "", 0, 6, 0, 0, 0 },

  { 152, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1/p2",
    "", 1, 2, 0, 0, 0 },

  { 153, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2/p1",
    "", 0, 6, 0, 0, 0 },

  { 154, 0,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2/p2",
    "", 1, 2, 0, 0, 0 },

  { 155, 0, "Robotino/serial communication/Baseboard Serial/Rate Transition",
    "", 0, 6, 0, 0, 5 },

  { 156, 0, "Robotino/serial communication/Baseboard Serial/Rate Transition1",
    "", 0, 6, 0, 0, 0 },

  { 157, 0, "Robotino/serial communication/Baseboard Serial/Rate Transition2",
    "", 0, 6, 0, 0, 5 },

  { 158, 0, "Robotino/serial communication/Baseboard Serial/Rate Transition3",
    "", 0, 6, 0, 0, 0 },

  { 159, 0, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "", 0, 4, 15, 0, 0 },

  { 160, 0, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "", 0, 4, 15, 0, 0 },

  { 161, 0, "Robotino/serial communication/Baseboard Serial/FIFO write 1/p1",
    "", 0, 6, 0, 0, 0 },

  { 162, 0, "Robotino/serial communication/Baseboard Serial/FIFO write 1/p2",
    "", 1, 2, 0, 0, 0 },

  { 163, 0, "Robotino/serial communication/Baseboard Serial/FIFO write 2/p1",
    "", 0, 6, 0, 0, 0 },

  { 164, 0, "Robotino/serial communication/Baseboard Serial/FIFO write 2/p2",
    "", 1, 2, 0, 0, 0 },

  { 165, 8, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Subsystem/S-Function/p1",
    "Wegpunkte", 0, 0, 3, 0, 3 },

  { 166, 8, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Subsystem/S-Function/p2",
    "", 1, 0, 3, 0, 3 },

  { 167, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Compare To Zero/Compare",
    "", 0, 1, 0, 0, 0 },

  { 168, 0,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Compare To Zero1/Compare",
    "", 0, 2, 0, 0, 0 },

  { 169, 22,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Read Int Status FC1/p1",
    "", 0, 5, 0, 0, 4 },

  { 170, 33,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Read Int Status FC1/p1",
    "", 0, 5, 0, 0, 5 },

  { 171, 18,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1",
    "", 0, 6, 0, 0, 4 },

  { 172, 18,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/Read HW FIFO1",
    "", 0, 5, 19, 0, 4 },

  { 173, 19,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2",
    "", 0, 6, 0, 0, 4 },

  { 174, 19,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/Read HW FIFO2",
    "", 0, 5, 19, 0, 4 },

  { 175, 20,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/Constant1",
    "", 0, 5, 0, 0, 4 },

  { 176, 20,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1/p1",
    "", 0, 5, 20, 0, 4 },

  { 177, 20,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1/p2",
    "", 1, 5, 0, 0, 4 },

  { 178, 21,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/Constant2",
    "", 0, 5, 0, 0, 4 },

  { 179, 21,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2/p1",
    "", 0, 5, 20, 0, 4 },

  { 180, 21,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2/p2",
    "", 1, 5, 0, 0, 4 },

  { 181, 29,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1",
    "", 0, 6, 0, 0, 5 },

  { 182, 29,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/Read HW FIFO1",
    "", 0, 5, 19, 0, 5 },

  { 183, 30,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2",
    "", 0, 6, 0, 0, 5 },

  { 184, 30,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/Read HW FIFO2",
    "", 0, 5, 19, 0, 5 },

  { 185, 31,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/Constant1",
    "", 0, 5, 0, 0, 5 },

  { 186, 31,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1/p1",
    "", 0, 5, 20, 0, 5 },

  { 187, 31,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1/p2",
    "", 1, 5, 0, 0, 5 },

  { 188, 32,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/Constant2",
    "", 0, 5, 0, 0, 5 },

  { 189, 32,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2/p1",
    "", 0, 5, 20, 0, 5 },

  { 190, 32,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2/p2",
    "", 1, 5, 0, 0, 5 },

  {
    0, 0, NULL, NULL, 0, 0, 0, 0, 0
  }
};

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 191, "Constant",
    "Value", 0, 0, 0 },

  { 192, "Constant1",
    "Value", 2, 0, 0 },

  { 193, "Constant2",
    "Value", 1, 0, 0 },

  { 194, "Constant3",
    "Value", 1, 0, 0 },

  { 195, "Constant4",
    "Value", 0, 0, 0 },

  { 196, "constant",
    "Value", 0, 0, 0 },

  { 197, "constant1",
    "Value", 0, 0, 0 },

  { 198, "constant2",
    "Value", 2, 0, 0 },

  { 199, "constant3",
    "Value", 0, 0, 0 },

  { 200, "constant4",
    "Value", 0, 0, 0 },

  { 201, "constant5",
    "Value", 0, 0, 0 },

  { 202, "Gain",
    "Gain", 0, 0, 0 },

  { 203, "Gewerk_2/Bremsabstand",
    "Value", 0, 0, 0 },

  { 204, "Gewerk_2/Constant",
    "Value", 2, 0, 0 },

  { 205, "Gewerk_2/Constant2",
    "Value", 2, 0, 0 },

  { 206, "Gewerk_2/Constant4",
    "Value", 1, 0, 0 },

  { 207, "Gewerk_2/Constant5",
    "Value", 2, 0, 0 },

  { 208, "Gewerk_2/Constant7",
    "Value", 2, 0, 0 },

  { 209, "Gewerk_2/Wegpunktliste zum Testen",
    "Value", 0, 4, 0 },

  { 210, "Gewerk_2/Counter",
    "InitialCount", 1, 0, 0 },

  { 211, "Gewerk_2/Counter",
    "HitValue", 1, 0, 0 },

  { 212, "Robotino/Grabber velocity",
    "Value", 0, 0, 0 },

  { 213, "Robotino/Gain",
    "Gain", 0, 0, 0 },

  { 214, "UDP interface/Receive",
    "P1", 0, 21, 0 },

  { 215, "UDP interface/Receive",
    "P2", 0, 0, 0 },

  { 216, "UDP interface/Receive",
    "P3", 0, 0, 0 },

  { 217, "UDP interface/Receive",
    "P4", 0, 0, 0 },

  { 218, "UDP interface/Receive",
    "P5", 0, 0, 0 },

  { 219, "getRobotinoID/Step",
    "Time", 0, 0, 0 },

  { 220, "getRobotinoID/Step",
    "Before", 0, 0, 0 },

  { 221, "getRobotinoID/Step",
    "After", 0, 0, 0 },

  { 222,
    "Communication Block/Robotino UDP transceiver/Rate Transition up-sampling to fundamental sample time",
    "X0", 1, 0, 0 },

  { 223, "Gewerk_2/Ausg�nge Robotino/Konstante f�r Kollision ",
    "Value", 0, 0, 0 },

  { 224, "Gewerk_2/Ausg�nge Robotino/Konstante f�r den Lichtschranke",
    "Value", 0, 0, 0 },

  { 225, "Gewerk_2/Ausg�nge Robotino/Konstante f�r den L�ngsgeschwindigkeit",
    "Value", 0, 0, 0 },

  { 226, "Gewerk_2/Ausg�nge Robotino/Konstante f�r den Quergeschwindigkeit1",
    "Value", 0, 0, 0 },

  { 227, "Gewerk_2/Ausg�nge Robotino/Konstante f�r den Rotationegeschwindigkeit",
    "Value", 0, 0, 0 },

  { 228, "Gewerk_2/Ausg�nge Robotino/Konstante f�r den Schieber",
    "Value", 0, 0, 0 },

  { 229, "Gewerk_2/Ausg�nge Robotino/Konstante f�r die Abstandssensoren",
    "Value", 0, 22, 0 },

  { 230, "Gewerk_2/Ausg�nge UDP Interface1/Camera Variablen Konst.",
    "Value", 0, 23, 0 },

  { 231, "Gewerk_2/Ausg�nge UDP Interface1/Fahrerlaubnis Kons.",
    "Value", 0, 0, 0 },

  { 232, "Gewerk_2/Ausg�nge UDP Interface1/Kamera X Y Roboter 1",
    "Value", 0, 24, 0 },

  { 233, "Gewerk_2/Ausg�nge UDP Interface1/Kamera X Y Roboter 2",
    "Value", 0, 24, 0 },

  { 234, "Gewerk_2/Ausg�nge UDP Interface1/Kamera X Y Roboter 3",
    "Value", 0, 24, 0 },

  { 235, "Gewerk_2/Ausg�nge UDP Interface1/Kamera X Y Roboter 4",
    "Value", 0, 24, 0 },

  { 236, "Gewerk_2/Ausg�nge UDP Interface1/Zeitstempel",
    "Value", 0, 0, 0 },

  { 237, "Gewerk_2/Ausg�nge UDP Interface1/Zeitstempel1",
    "Value", 0, 0, 0 },

  { 238, "Gewerk_2/Ausg�nge UDP Interface1/Zeitstempel2",
    "Value", 0, 0, 0 },

  { 239, "Gewerk_2/Ausg�nge UDP Interface1/�bermittelung Koordinaten Kons.",
    "Value", 0, 25, 0 },

  { 240,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Previous Flag",
    "X0", 1, 0, 0 },

  { 241,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Previous SOC",
    "X0", 1, 0, 0 },

  { 242, "Robotino/serial communication/last error free response",
    "X0", 0, 26, 0 },

  { 243, "Robotino/serial communication/stop marker",
    "X0", 0, 24, 0 },

  { 244, "getRobotinoID/getIDfromFlash/From File",
    "P1", 0, 27, 0 },

  { 245, "getRobotinoID/getIDfromFlash/From File",
    "P2", 0, 0, 0 },

  { 246, "getRobotinoID/getIDfromFlash/From File",
    "P3", 0, 0, 0 },

  { 247, "getRobotinoID/getIDfromFlash/From File",
    "P4", 0, 0, 0 },

  { 248, "getRobotinoID/getIDfromFlash/From File",
    "P5", 0, 0, 0 },

  { 249, "getRobotinoID/getIDfromFlash/From File",
    "P6", 0, 0, 0 },

  { 250, "getRobotinoID/getIDfromFlash/From File",
    "P7", 0, 0, 0 },

  { 251,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all",
    "P1", 0, 21, 0 },

  { 252,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all",
    "P2", 0, 0, 0 },

  { 253,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all",
    "P3", 0, 0, 0 },

  { 254,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all",
    "P4", 0, 0, 0 },

  { 255,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Receive from all",
    "P5", 0, 0, 0 },

  { 256,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Send to all",
    "P1", 0, 28, 0 },

  { 257,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Send to all",
    "P2", 0, 0, 0 },

  { 258,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Send to all",
    "P3", 0, 0, 0 },

  { 259,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Send to all",
    "P4", 0, 0, 0 },

  { 260,
    "Communication Block/Robotino UDP transceiver/If Robotino 1/Send to all",
    "P5", 0, 0, 0 },

  { 261,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all",
    "P1", 0, 21, 0 },

  { 262,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all",
    "P2", 0, 0, 0 },

  { 263,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all",
    "P3", 0, 0, 0 },

  { 264,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all",
    "P4", 0, 0, 0 },

  { 265,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Receive from all",
    "P5", 0, 0, 0 },

  { 266,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Send to all",
    "P1", 0, 28, 0 },

  { 267,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Send to all",
    "P2", 0, 0, 0 },

  { 268,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Send to all",
    "P3", 0, 0, 0 },

  { 269,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Send to all",
    "P4", 0, 0, 0 },

  { 270,
    "Communication Block/Robotino UDP transceiver/If Robotino 2/Send to all",
    "P5", 0, 0, 0 },

  { 271,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all",
    "P1", 0, 21, 0 },

  { 272,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all",
    "P2", 0, 0, 0 },

  { 273,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all",
    "P3", 0, 0, 0 },

  { 274,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all",
    "P4", 0, 0, 0 },

  { 275,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Receive from all",
    "P5", 0, 0, 0 },

  { 276,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Send to all",
    "P1", 0, 28, 0 },

  { 277,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Send to all",
    "P2", 0, 0, 0 },

  { 278,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Send to all",
    "P3", 0, 0, 0 },

  { 279,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Send to all",
    "P4", 0, 0, 0 },

  { 280,
    "Communication Block/Robotino UDP transceiver/If Robotino 3/Send to all",
    "P5", 0, 0, 0 },

  { 281,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all",
    "P1", 0, 21, 0 },

  { 282,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all",
    "P2", 0, 0, 0 },

  { 283,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all",
    "P3", 0, 0, 0 },

  { 284,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all",
    "P4", 0, 0, 0 },

  { 285,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Receive from all",
    "P5", 0, 0, 0 },

  { 286,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Send to all",
    "P1", 0, 28, 0 },

  { 287,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Send to all",
    "P2", 0, 0, 0 },

  { 288,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Send to all",
    "P3", 0, 0, 0 },

  { 289,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Send to all",
    "P4", 0, 0, 0 },

  { 290,
    "Communication Block/Robotino UDP transceiver/If Robotino 4/Send to all",
    "P5", 0, 0, 0 },

  { 291, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Constant1",
    "Value", 0, 29, 0 },

  { 292, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Constant2",
    "Value", 0, 29, 0 },

  { 293, "Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Constant3",
    "Value", 0, 30, 0 },

  { 294,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Constant2",
    "Value", 0, 0, 0 },

  { 295,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Gain",
    "Gain", 0, 0, 0 },

  { 296,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Gain1",
    "Gain", 4, 0, 2 },

  { 297,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Memory",
    "X0", 4, 0, 0 },

  { 298,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Memory1",
    "X0", 5, 0, 0 },

  { 299,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Charging Counter",
    "InitialCount", 4, 0, 0 },

  { 300,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Discharging Counter",
    "InitialCount", 5, 0, 0 },

  { 301,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P1", 0, 0, 0 },

  { 302,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P2", 0, 0, 0 },

  { 303,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P3", 0, 0, 0 },

  { 304,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P4", 0, 0, 0 },

  { 305,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P5", 0, 0, 0 },

  { 306,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P6", 0, 0, 0 },

  { 307,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P7", 0, 0, 0 },

  { 308,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 1",
    "P8", 0, 0, 0 },

  { 309,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P1", 0, 0, 0 },

  { 310,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P2", 0, 0, 0 },

  { 311,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P3", 0, 0, 0 },

  { 312,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P4", 0, 0, 0 },

  { 313,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P5", 0, 0, 0 },

  { 314,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P6", 0, 0, 0 },

  { 315,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P7", 0, 0, 0 },

  { 316,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO read 2",
    "P8", 0, 0, 0 },

  { 317,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1",
    "P1", 0, 0, 0 },

  { 318,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1",
    "P2", 0, 0, 0 },

  { 319,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1",
    "P3", 0, 0, 0 },

  { 320,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1",
    "P4", 0, 0, 0 },

  { 321,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 1",
    "P5", 0, 25, 0 },

  { 322,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2",
    "P1", 0, 0, 0 },

  { 323,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2",
    "P2", 0, 0, 0 },

  { 324,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2",
    "P3", 0, 0, 0 },

  { 325,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2",
    "P4", 0, 0, 0 },

  { 326,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/FIFO write 2",
    "P5", 0, 25, 0 },

  { 327,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P1", 0, 0, 0 },

  { 328,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P2", 0, 0, 0 },

  { 329,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P3", 0, 0, 0 },

  { 330,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P4", 0, 0, 0 },

  { 331,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P5", 0, 0, 0 },

  { 332,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P6", 0, 0, 0 },

  { 333,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P7", 0, 0, 0 },

  { 334,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup1",
    "P8", 0, 0, 0 },

  { 335,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P1", 0, 0, 0 },

  { 336,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P2", 0, 0, 0 },

  { 337,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P3", 0, 0, 0 },

  { 338,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P4", 0, 0, 0 },

  { 339,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P5", 0, 0, 0 },

  { 340,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P6", 0, 0, 0 },

  { 341,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P7", 0, 0, 0 },

  { 342,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/Setup2",
    "P8", 0, 0, 0 },

  { 343, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P1", 0, 0, 0 },

  { 344, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P2", 0, 0, 0 },

  { 345, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P3", 0, 0, 0 },

  { 346, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P4", 0, 0, 0 },

  { 347, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P5", 0, 0, 0 },

  { 348, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P6", 0, 0, 0 },

  { 349, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P7", 0, 0, 0 },

  { 350, "Robotino/serial communication/Baseboard Serial/FIFO read 1",
    "P8", 0, 0, 0 },

  { 351, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P1", 0, 0, 0 },

  { 352, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P2", 0, 0, 0 },

  { 353, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P3", 0, 0, 0 },

  { 354, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P4", 0, 0, 0 },

  { 355, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P5", 0, 0, 0 },

  { 356, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P6", 0, 0, 0 },

  { 357, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P7", 0, 0, 0 },

  { 358, "Robotino/serial communication/Baseboard Serial/FIFO read 2",
    "P8", 0, 0, 0 },

  { 359, "Robotino/serial communication/Baseboard Serial/FIFO write 1",
    "P1", 0, 0, 0 },

  { 360, "Robotino/serial communication/Baseboard Serial/FIFO write 1",
    "P2", 0, 0, 0 },

  { 361, "Robotino/serial communication/Baseboard Serial/FIFO write 1",
    "P3", 0, 0, 0 },

  { 362, "Robotino/serial communication/Baseboard Serial/FIFO write 1",
    "P4", 0, 0, 0 },

  { 363, "Robotino/serial communication/Baseboard Serial/FIFO write 1",
    "P5", 0, 25, 0 },

  { 364, "Robotino/serial communication/Baseboard Serial/FIFO write 2",
    "P1", 0, 0, 0 },

  { 365, "Robotino/serial communication/Baseboard Serial/FIFO write 2",
    "P2", 0, 0, 0 },

  { 366, "Robotino/serial communication/Baseboard Serial/FIFO write 2",
    "P3", 0, 0, 0 },

  { 367, "Robotino/serial communication/Baseboard Serial/FIFO write 2",
    "P4", 0, 0, 0 },

  { 368, "Robotino/serial communication/Baseboard Serial/FIFO write 2",
    "P5", 0, 25, 0 },

  { 369, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P1", 0, 0, 0 },

  { 370, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P2", 0, 0, 0 },

  { 371, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P3", 0, 0, 0 },

  { 372, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P4", 0, 0, 0 },

  { 373, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P5", 0, 0, 0 },

  { 374, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P6", 0, 0, 0 },

  { 375, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P7", 0, 0, 0 },

  { 376, "Robotino/serial communication/Baseboard Serial/Setup1",
    "P8", 0, 0, 0 },

  { 377, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P1", 0, 0, 0 },

  { 378, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P2", 0, 0, 0 },

  { 379, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P3", 0, 0, 0 },

  { 380, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P4", 0, 0, 0 },

  { 381, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P5", 0, 0, 0 },

  { 382, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P6", 0, 0, 0 },

  { 383, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P7", 0, 0, 0 },

  { 384, "Robotino/serial communication/Baseboard Serial/Setup2",
    "P8", 0, 0, 0 },

  { 385,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Compare To Zero/Constant",
    "Value", 0, 0, 0 },

  { 386,
    "Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Compare To Zero1/Constant",
    "Value", 0, 0, 0 },

  { 387,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/Constant",
    "Value", 5, 0, 0 },

  { 388,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1",
    "P1", 0, 0, 0 },

  { 389,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1",
    "P2", 0, 0, 0 },

  { 390,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1",
    "P3", 0, 0, 0 },

  { 391,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1",
    "P4", 0, 0, 0 },

  { 392,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1/FIFO write 1",
    "P5", 0, 25, 0 },

  { 393,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/Constant",
    "Value", 5, 0, 0 },

  { 394,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2",
    "P1", 0, 0, 0 },

  { 395,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2",
    "P2", 0, 0, 0 },

  { 396,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2",
    "P3", 0, 0, 0 },

  { 397,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2",
    "P4", 0, 0, 0 },

  { 398,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2/FIFO write 2",
    "P5", 0, 25, 0 },

  { 399,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/Constant1",
    "Value", 5, 0, 0 },

  { 400,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P1", 0, 0, 0 },

  { 401,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P2", 0, 0, 0 },

  { 402,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P3", 0, 0, 0 },

  { 403,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P4", 0, 0, 0 },

  { 404,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P5", 0, 0, 0 },

  { 405,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P6", 0, 0, 0 },

  { 406,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P7", 0, 0, 0 },

  { 407,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1/FIFO read 1",
    "P8", 0, 0, 0 },

  { 408,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/Constant2",
    "Value", 5, 0, 0 },

  { 409,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P1", 0, 0, 0 },

  { 410,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P2", 0, 0, 0 },

  { 411,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P3", 0, 0, 0 },

  { 412,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P4", 0, 0, 0 },

  { 413,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P5", 0, 0, 0 },

  { 414,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P6", 0, 0, 0 },

  { 415,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P7", 0, 0, 0 },

  { 416,
    "Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2/FIFO read 2",
    "P8", 0, 0, 0 },

  { 417,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/Constant",
    "Value", 5, 0, 0 },

  { 418,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1",
    "P1", 0, 0, 0 },

  { 419,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1",
    "P2", 0, 0, 0 },

  { 420,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1",
    "P3", 0, 0, 0 },

  { 421,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1",
    "P4", 0, 0, 0 },

  { 422,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1/FIFO write 1",
    "P5", 0, 25, 0 },

  { 423,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/Constant",
    "Value", 5, 0, 0 },

  { 424,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2",
    "P1", 0, 0, 0 },

  { 425,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2",
    "P2", 0, 0, 0 },

  { 426,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2",
    "P3", 0, 0, 0 },

  { 427,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2",
    "P4", 0, 0, 0 },

  { 428,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2/FIFO write 2",
    "P5", 0, 25, 0 },

  { 429,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/Constant1",
    "Value", 5, 0, 0 },

  { 430,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P1", 0, 0, 0 },

  { 431,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P2", 0, 0, 0 },

  { 432,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P3", 0, 0, 0 },

  { 433,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P4", 0, 0, 0 },

  { 434,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P5", 0, 0, 0 },

  { 435,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P6", 0, 0, 0 },

  { 436,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P7", 0, 0, 0 },

  { 437,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1/FIFO read 1",
    "P8", 0, 0, 0 },

  { 438,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/Constant2",
    "Value", 5, 0, 0 },

  { 439,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P1", 0, 0, 0 },

  { 440,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P2", 0, 0, 0 },

  { 441,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P3", 0, 0, 0 },

  { 442,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P4", 0, 0, 0 },

  { 443,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P5", 0, 0, 0 },

  { 444,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P6", 0, 0, 0 },

  { 445,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P7", 0, 0, 0 },

  { 446,
    "Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2/FIFO read 2",
    "P8", 0, 0, 0 },

  {
    0, NULL, NULL, 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 0, NULL, 0, 0, 0 }
};

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &KitGewerk2_v14_B.wout_m,            /* 0: Signal */
  &KitGewerk2_v14_B.wout_p,            /* 1: Signal */
  &KitGewerk2_v14_B.wout,              /* 2: Signal */
  &KitGewerk2_v14_B.constant3,         /* 3: Signal */
  &KitGewerk2_v14_B.constant4,         /* 4: Signal */
  &KitGewerk2_v14_B.constant5,         /* 5: Signal */
  &KitGewerk2_v14_B.DataTypeConversion,/* 6: Signal */
  &KitGewerk2_v14_B.DataTypeConversion1_o,/* 7: Signal */
  &KitGewerk2_v14_B.Gain_b,            /* 8: Signal */
  &KitGewerk2_v14_B.Add,               /* 9: Signal */
  &KitGewerk2_v14_B.DataTypeConversion1_f,/* 10: Signal */
  &KitGewerk2_v14_B.DataTypeConversion2_b,/* 11: Signal */
  &KitGewerk2_v14_B.DataTypeConversion3_k,/* 12: Signal */
  &KitGewerk2_v14_B.DataTypeConversion4_d,/* 13: Signal */
  &KitGewerk2_v14_B.DataTypeConversion5,/* 14: Signal */
  &KitGewerk2_v14_B.DataTypeConversion6,/* 15: Signal */
  &KitGewerk2_v14_B.DataTypeConversion7,/* 16: Signal */
  &KitGewerk2_v14_B.DataTypeConversion8,/* 17: Signal */
  &KitGewerk2_v14_B.DataTypeConversion9,/* 18: Signal */
  &KitGewerk2_v14_B.Pack[0],           /* 19: Signal */
  &KitGewerk2_v14_B.Unpack_o1,         /* 20: Signal */
  &KitGewerk2_v14_B.Unpack_o2,         /* 21: Signal */
  &KitGewerk2_v14_B.Unpack_o3,         /* 22: Signal */
  &KitGewerk2_v14_B.Unpack_o4,         /* 23: Signal */
  &KitGewerk2_v14_B.Unpack_o5,         /* 24: Signal */
  &KitGewerk2_v14_B.A_WPL[0],          /* 25: Signal */
  &KitGewerk2_v14_B.B_Stop,            /* 26: Signal */
  &KitGewerk2_v14_B.B_WP_weiter,       /* 27: Signal */
  &KitGewerk2_v14_B.B_Greifer,         /* 28: Signal */
  &KitGewerk2_v14_B.B_WPL_cnt_reset,   /* 29: Signal */
  &KitGewerk2_v14_B.UI_to_GW1,         /* 30: Signal */
  &KitGewerk2_v14_B.A_stern_test[0],   /* 31: Signal */
  &KitGewerk2_v14_B.b_stop,            /* 32: Signal */
  &KitGewerk2_v14_B.d_Y_soll,          /* 33: Signal */
  &KitGewerk2_v14_B.d_X_soll,          /* 34: Signal */
  &KitGewerk2_v14_B.d_Phi_soll,        /* 35: Signal */
  &KitGewerk2_v14_B.d_V_Max_soll,      /* 36: Signal */
  &KitGewerk2_v14_B.Constant,          /* 37: Signal */
  &KitGewerk2_v14_B.Constant2_f,       /* 38: Signal */
  &KitGewerk2_v14_B.Constant4,         /* 39: Signal */
  &KitGewerk2_v14_B.Constant5,         /* 40: Signal */
  &KitGewerk2_v14_B.Constant7,         /* 41: Signal */
  &KitGewerk2_v14_B.WegpunktlistezumTesten[0],/* 42: Signal */
  &KitGewerk2_v14_B.DataTypeConversion_l,/* 43: Signal */
  &KitGewerk2_v14_B.DataTypeConversion1_i,/* 44: Signal */
  &KitGewerk2_v14_B.RelationalOperator,/* 45: Signal */
  &KitGewerk2_v14_B.Counter_o1,        /* 46: Signal */
  &KitGewerk2_v14_B.Counter_o2,        /* 47: Signal */
  &KitGewerk2_v14_B.Output_Flag_d,     /* 48: Signal */
  &KitGewerk2_v14_B.Output_SOC,        /* 49: Signal */
  &KitGewerk2_v14_B.robotino_response[0],/* 50: Signal */
  &KitGewerk2_v14_B.dms_out[0],        /* 51: Signal */
  &KitGewerk2_v14_B.light_barrier,     /* 52: Signal */
  &KitGewerk2_v14_B.slider,            /* 53: Signal */
  &KitGewerk2_v14_B.v_x_out,           /* 54: Signal */
  &KitGewerk2_v14_B.v_y_out,           /* 55: Signal */
  &KitGewerk2_v14_B.v_theta_out,       /* 56: Signal */
  &KitGewerk2_v14_B.direction_motor0_out,/* 57: Signal */
  &KitGewerk2_v14_B.velocity_motor0_out,/* 58: Signal */
  &KitGewerk2_v14_B.direction_motor1_out,/* 59: Signal */
  &KitGewerk2_v14_B.velocity_motor1_out,/* 60: Signal */
  &KitGewerk2_v14_B.direction_motor2_out,/* 61: Signal */
  &KitGewerk2_v14_B.velocity_motor2_out,/* 62: Signal */
  &KitGewerk2_v14_B.Gain_o,            /* 63: Signal */
  &KitGewerk2_v14_B.enable_out[0],     /* 64: Signal */
  &KitGewerk2_v14_B.Receive_o1[0],     /* 65: Signal */
  &KitGewerk2_v14_B.Receive_o2,        /* 66: Signal */
  &KitGewerk2_v14_B.Unpack[0],         /* 67: Signal */
  &KitGewerk2_v14_B.Step,              /* 68: Signal */
  &KitGewerk2_v14_B.MultiportSwitch[0],/* 69: Signal */
  &KitGewerk2_v14_B.RateTransitiondownsamplingto5_o[0],/* 70: Signal */
  &KitGewerk2_v14_B.RateTransitiondownsamplingto500,/* 71: Signal */
  &KitGewerk2_v14_B.RateTransitionupsamplingtofunda[0],/* 72: Signal */
  &KitGewerk2_v14_B.Auswahl1,          /* 73: Signal */
  &KitGewerk2_v14_B.Auswahl2,          /* 74: Signal */
  &KitGewerk2_v14_B.Auswahl3,          /* 75: Signal */
  &KitGewerk2_v14_B.Auswahl4,          /* 76: Signal */
  &KitGewerk2_v14_B.Auswahl5,          /* 77: Signal */
  &KitGewerk2_v14_B.Auswahl6[0],       /* 78: Signal */
  &KitGewerk2_v14_B.Auswahl7,          /* 79: Signal */
  &KitGewerk2_v14_B.Auswahl1_h[0],     /* 80: Signal */
  &KitGewerk2_v14_B.Auswahl10[0],      /* 81: Signal */
  &KitGewerk2_v14_B.Auswahl2_e[0],     /* 82: Signal */
  &KitGewerk2_v14_B.Auswahl3_m[0],     /* 83: Signal */
  &KitGewerk2_v14_B.Auswahl4_i[0],     /* 84: Signal */
  &KitGewerk2_v14_B.Auswahl5_m,        /* 85: Signal */
  &KitGewerk2_v14_B.Auswahl6_k,        /* 86: Signal */
  &KitGewerk2_v14_B.Auswahl7_b,        /* 87: Signal */
  &KitGewerk2_v14_B.Auswahl8,          /* 88: Signal */
  &KitGewerk2_v14_B.Auswahl9[0],       /* 89: Signal */
  &KitGewerk2_v14_B.SOC_a,             /* 90: Signal */
  &KitGewerk2_v14_B.FLAG,              /* 91: Signal */
  &KitGewerk2_v14_B.DataTypeConversion_c,/* 92: Signal */
  &KitGewerk2_v14_B.DataTypeConversion1_fj,/* 93: Signal */
  &KitGewerk2_v14_B.DataTypeConversion2_d[0],/* 94: Signal */
  &KitGewerk2_v14_B.DataTypeConversion3,/* 95: Signal */
  &KitGewerk2_v14_B.DataTypeConversion4,/* 96: Signal */
  &KitGewerk2_v14_B.DataTypeConversion5_i,/* 97: Signal */
  &KitGewerk2_v14_B.PreviousFlag,      /* 98: Signal */
  &KitGewerk2_v14_B.PreviousSOC,       /* 99: Signal */
  &KitGewerk2_v14_B.direction_motor0_out_p,/* 100: Signal */
  &KitGewerk2_v14_B.velocity_motor0_out_d,/* 101: Signal */
  &KitGewerk2_v14_B.direction_motor1_out_d,/* 102: Signal */
  &KitGewerk2_v14_B.velocity_motor1_out_f,/* 103: Signal */
  &KitGewerk2_v14_B.direction_motor2_out_k,/* 104: Signal */
  &KitGewerk2_v14_B.velocity_motor2_out_n,/* 105: Signal */
  &KitGewerk2_v14_B.distance_measuring_sensors_out[0],/* 106: Signal */
  &KitGewerk2_v14_B.di03_bump_out,     /* 107: Signal */
  &KitGewerk2_v14_B.bumper_out[0],     /* 108: Signal */
  &KitGewerk2_v14_B.error_free_resp_out[0],/* 109: Signal */
  &KitGewerk2_v14_B.message[0],        /* 110: Signal */
  &KitGewerk2_v14_B.stop_out,          /* 111: Signal */
  &KitGewerk2_v14_B.stop_flag_out[0],  /* 112: Signal */
  &KitGewerk2_v14_B.doubletouint16[0], /* 113: Signal */
  &KitGewerk2_v14_B.uint16todouble[0], /* 114: Signal */
  &KitGewerk2_v14_B.lasterrorfreeresponse[0],/* 115: Signal */
  &KitGewerk2_v14_B.stopmarker[0],     /* 116: Signal */
  &KitGewerk2_v14_B.FromFile[0],       /* 117: Signal */
  &KitGewerk2_v14_B.Unpack_o,          /* 118: Signal */
  &KitGewerk2_v14_B.Receivefromall_o1[0],/* 119: Signal */
  &KitGewerk2_v14_B.Receivefromall_o2, /* 120: Signal */
  &KitGewerk2_v14_B.Receivefromall_o1_p[0],/* 121: Signal */
  &KitGewerk2_v14_B.Receivefromall_o2_a,/* 122: Signal */
  &KitGewerk2_v14_B.Receivefromall_o1_j[0],/* 123: Signal */
  &KitGewerk2_v14_B.Receivefromall_o2_m,/* 124: Signal */
  &KitGewerk2_v14_B.Receivefromall_o1_g[0],/* 125: Signal */
  &KitGewerk2_v14_B.Receivefromall_o2_ae,/* 126: Signal */
  &KitGewerk2_v14_B.Constant1[0],      /* 127: Signal */
  &KitGewerk2_v14_B.Constant2[0],      /* 128: Signal */
  &KitGewerk2_v14_B.Constant3[0],      /* 129: Signal */
  &KitGewerk2_v14_B.Output_Flag,       /* 130: Signal */
  &KitGewerk2_v14_B.y_k,               /* 131: Signal */
  &KitGewerk2_v14_B.y,                 /* 132: Signal */
  &KitGewerk2_v14_B.SOC,               /* 133: Signal */
  &KitGewerk2_v14_B.Laden,             /* 134: Signal */
  &KitGewerk2_v14_B.DataTypeConversion1,/* 135: Signal */
  &KitGewerk2_v14_B.DataTypeConversion2,/* 136: Signal */
  &KitGewerk2_v14_B.DataTypeConversion3_j,/* 137: Signal */
  &KitGewerk2_v14_B.Gain,              /* 138: Signal */
  &KitGewerk2_v14_B.Gain1,             /* 139: Signal */
  &KitGewerk2_v14_B.Memory,            /* 140: Signal */
  &KitGewerk2_v14_B.Memory1,           /* 141: Signal */
  &KitGewerk2_v14_B.ChargingCounter,   /* 142: Signal */
  &KitGewerk2_v14_B.DischargingCounter,/* 143: Signal */
  &KitGewerk2_v14_B.Sum,               /* 144: Signal */
  &KitGewerk2_v14_B.RateTransition_g,  /* 145: Signal */
  &KitGewerk2_v14_B.RateTransition1_g, /* 146: Signal */
  &KitGewerk2_v14_B.RateTransition2_m, /* 147: Signal */
  &KitGewerk2_v14_B.RateTransition3,   /* 148: Signal */
  &KitGewerk2_v14_B.FIFOread1_j[0],    /* 149: Signal */
  &KitGewerk2_v14_B.FIFOread2_c[0],    /* 150: Signal */
  &KitGewerk2_v14_B.FIFOwrite1_o1,     /* 151: Signal */
  &KitGewerk2_v14_B.FIFOwrite1_o2,     /* 152: Signal */
  &KitGewerk2_v14_B.FIFOwrite2_o1,     /* 153: Signal */
  &KitGewerk2_v14_B.FIFOwrite2_o2,     /* 154: Signal */
  &KitGewerk2_v14_B.RateTransition,    /* 155: Signal */
  &KitGewerk2_v14_B.RateTransition1,   /* 156: Signal */
  &KitGewerk2_v14_B.RateTransition2,   /* 157: Signal */
  &KitGewerk2_v14_B.RateTransition3_e, /* 158: Signal */
  &KitGewerk2_v14_B.FIFOread1[0],      /* 159: Signal */
  &KitGewerk2_v14_B.FIFOread2[0],      /* 160: Signal */
  &KitGewerk2_v14_B.FIFOwrite1_o1_o,   /* 161: Signal */
  &KitGewerk2_v14_B.FIFOwrite1_o2_n,   /* 162: Signal */
  &KitGewerk2_v14_B.FIFOwrite2_o1_k,   /* 163: Signal */
  &KitGewerk2_v14_B.FIFOwrite2_o2_j,   /* 164: Signal */
  &KitGewerk2_v14_B.Wegpunkte[0],      /* 165: Signal */
  &KitGewerk2_v14_B.SFunction_o2[0],   /* 166: Signal */
  &KitGewerk2_v14_B.Compare,           /* 167: Signal */
  &KitGewerk2_v14_B.Compare_o,         /* 168: Signal */
  &KitGewerk2_v14_B.ReadIntStatusFC1_o2_c,/* 169: Signal */
  &KitGewerk2_v14_B.ReadIntStatusFC1_o2,/* 170: Signal */
  &KitGewerk2_v14_B.FIFOwrite1_c,      /* 171: Signal */
  &KitGewerk2_v14_B.ReadHWFIFO1_c[0],  /* 172: Signal */
  &KitGewerk2_v14_B.FIFOwrite2_a,      /* 173: Signal */
  &KitGewerk2_v14_B.ReadHWFIFO2_o[0],  /* 174: Signal */
  &KitGewerk2_v14_B.Constant1_o,       /* 175: Signal */
  &KitGewerk2_v14_B.FIFOread1_o1_a[0], /* 176: Signal */
  &KitGewerk2_v14_B.FIFOread1_o2_i,    /* 177: Signal */
  &KitGewerk2_v14_B.Constant2_k,       /* 178: Signal */
  &KitGewerk2_v14_B.FIFOread2_o1_a[0], /* 179: Signal */
  &KitGewerk2_v14_B.FIFOread2_o2_k,    /* 180: Signal */
  &KitGewerk2_v14_B.FIFOwrite1,        /* 181: Signal */
  &KitGewerk2_v14_B.ReadHWFIFO1[0],    /* 182: Signal */
  &KitGewerk2_v14_B.FIFOwrite2,        /* 183: Signal */
  &KitGewerk2_v14_B.ReadHWFIFO2[0],    /* 184: Signal */
  &KitGewerk2_v14_B.Constant1_d,       /* 185: Signal */
  &KitGewerk2_v14_B.FIFOread1_o1[0],   /* 186: Signal */
  &KitGewerk2_v14_B.FIFOread1_o2,      /* 187: Signal */
  &KitGewerk2_v14_B.Constant2_h,       /* 188: Signal */
  &KitGewerk2_v14_B.FIFOread2_o1[0],   /* 189: Signal */
  &KitGewerk2_v14_B.FIFOread2_o2,      /* 190: Signal */
  &KitGewerk2_v14_P.Constant_Value_g,  /* 191: Block Parameter */
  &KitGewerk2_v14_P.Constant1_Value_n, /* 192: Block Parameter */
  &KitGewerk2_v14_P.Constant2_Value_p, /* 193: Block Parameter */
  &KitGewerk2_v14_P.Constant3_Value_j, /* 194: Block Parameter */
  &KitGewerk2_v14_P.Constant4_Value,   /* 195: Block Parameter */
  &KitGewerk2_v14_P.constant_Value,    /* 196: Block Parameter */
  &KitGewerk2_v14_P.constant1_Value,   /* 197: Block Parameter */
  &KitGewerk2_v14_P.constant2_Value,   /* 198: Block Parameter */
  &KitGewerk2_v14_P.constant3_Value,   /* 199: Block Parameter */
  &KitGewerk2_v14_P.constant4_Value,   /* 200: Block Parameter */
  &KitGewerk2_v14_P.constant5_Value,   /* 201: Block Parameter */
  &KitGewerk2_v14_P.Gain_Gain_c,       /* 202: Block Parameter */
  &KitGewerk2_v14_P.Bremsabstand_Value,/* 203: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value_m,  /* 204: Block Parameter */
  &KitGewerk2_v14_P.Constant2_Value_b, /* 205: Block Parameter */
  &KitGewerk2_v14_P.Constant4_Value_g, /* 206: Block Parameter */
  &KitGewerk2_v14_P.Constant5_Value,   /* 207: Block Parameter */
  &KitGewerk2_v14_P.Constant7_Value,   /* 208: Block Parameter */
  &KitGewerk2_v14_P.WegpunktlistezumTesten_Value[0],/* 209: Block Parameter */
  &KitGewerk2_v14_P.Counter_InitialCount,/* 210: Block Parameter */
  &KitGewerk2_v14_P.Counter_HitValue,  /* 211: Block Parameter */
  &KitGewerk2_v14_P.Grabbervelocity_Value,/* 212: Block Parameter */
  &KitGewerk2_v14_P.Gain_Gain_k,       /* 213: Block Parameter */
  &KitGewerk2_v14_P.Receive_P1[0],     /* 214: Block Parameter */
  &KitGewerk2_v14_P.Receive_P2,        /* 215: Block Parameter */
  &KitGewerk2_v14_P.Receive_P3,        /* 216: Block Parameter */
  &KitGewerk2_v14_P.Receive_P4,        /* 217: Block Parameter */
  &KitGewerk2_v14_P.Receive_P5,        /* 218: Block Parameter */
  &KitGewerk2_v14_P.Step_Time,         /* 219: Block Parameter */
  &KitGewerk2_v14_P.Step_Y0,           /* 220: Block Parameter */
  &KitGewerk2_v14_P.Step_YFinal,       /* 221: Block Parameter */
  &KitGewerk2_v14_P.RateTransitionupsamplingtofunda,/* 222: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrKollision_Value,/* 223: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrdenLichtschranke_Val,/* 224: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrdenLngsgeschwindigke,/* 225: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrdenQuergeschwindigke,/* 226: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrdenRotationegeschwin,/* 227: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrdenSchieber_Value,/* 228: Block Parameter */
  &KitGewerk2_v14_P.KonstantefrdieAbstandssensoren_[0],/* 229: Block Parameter */
  &KitGewerk2_v14_P.CameraVariablenKonst_Value[0],/* 230: Block Parameter */
  &KitGewerk2_v14_P.FahrerlaubnisKons_Value,/* 231: Block Parameter */
  &KitGewerk2_v14_P.KameraXYRoboter1_Value[0],/* 232: Block Parameter */
  &KitGewerk2_v14_P.KameraXYRoboter2_Value[0],/* 233: Block Parameter */
  &KitGewerk2_v14_P.KameraXYRoboter3_Value[0],/* 234: Block Parameter */
  &KitGewerk2_v14_P.KameraXYRoboter4_Value[0],/* 235: Block Parameter */
  &KitGewerk2_v14_P.Zeitstempel_Value, /* 236: Block Parameter */
  &KitGewerk2_v14_P.Zeitstempel1_Value,/* 237: Block Parameter */
  &KitGewerk2_v14_P.Zeitstempel2_Value,/* 238: Block Parameter */
  &KitGewerk2_v14_P.bermittelungKoordinatenKons_Val[0],/* 239: Block Parameter */
  &KitGewerk2_v14_P.PreviousFlag_X0,   /* 240: Block Parameter */
  &KitGewerk2_v14_P.PreviousSOC_X0,    /* 241: Block Parameter */
  &KitGewerk2_v14_P.lasterrorfreeresponse_X0[0],/* 242: Block Parameter */
  &KitGewerk2_v14_P.stopmarker_X0[0],  /* 243: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P1[0],    /* 244: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P2,       /* 245: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P3,       /* 246: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P4,       /* 247: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P5,       /* 248: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P6,       /* 249: Block Parameter */
  &KitGewerk2_v14_P.FromFile_P7,       /* 250: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P1_i[0],/* 251: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P2_g,/* 252: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P3_o,/* 253: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P4_nt,/* 254: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P5_a,/* 255: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P1_d[0], /* 256: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P2_n,    /* 257: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P3_e,    /* 258: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P4_h,    /* 259: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P5_l,    /* 260: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P1_h[0],/* 261: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P2_ih,/* 262: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P3_e,/* 263: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P4_n,/* 264: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P5_mx,/* 265: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P1_e[0], /* 266: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P2_o,    /* 267: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P3_m,    /* 268: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P4_n,    /* 269: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P5_a,    /* 270: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P1_p[0],/* 271: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P2_i,/* 272: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P3_b,/* 273: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P4_c,/* 274: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P5_m,/* 275: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P1_k[0], /* 276: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P2_d,    /* 277: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P3_k,    /* 278: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P4_b,    /* 279: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P5_k,    /* 280: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P1[0],/* 281: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P2, /* 282: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P3, /* 283: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P4, /* 284: Block Parameter */
  &KitGewerk2_v14_P.Receivefromall_P5, /* 285: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P1[0],   /* 286: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P2,      /* 287: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P3,      /* 288: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P4,      /* 289: Block Parameter */
  &KitGewerk2_v14_P.Sendtoall_P5,      /* 290: Block Parameter */
  &KitGewerk2_v14_P.Constant1_Value[0],/* 291: Block Parameter */
  &KitGewerk2_v14_P.Constant2_Value[0],/* 292: Block Parameter */
  &KitGewerk2_v14_P.Constant3_Value[0],/* 293: Block Parameter */
  &KitGewerk2_v14_P.Constant2_Value_g, /* 294: Block Parameter */
  &KitGewerk2_v14_P.Gain_Gain,         /* 295: Block Parameter */
  &KitGewerk2_v14_P.Gain1_Gain,        /* 296: Block Parameter */
  &KitGewerk2_v14_P.Memory_X0,         /* 297: Block Parameter */
  &KitGewerk2_v14_P.Memory1_X0,        /* 298: Block Parameter */
  &KitGewerk2_v14_P.ChargingCounter_InitialCount,/* 299: Block Parameter */
  &KitGewerk2_v14_P.DischargingCounter_InitialCount,/* 300: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P1_l,    /* 301: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P2_l,    /* 302: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P3_k,    /* 303: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P4_p,    /* 304: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P5_p,    /* 305: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P6_cp,   /* 306: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P7_l,    /* 307: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P8_g3,   /* 308: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P1_h,    /* 309: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P2_a,    /* 310: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P3_l,    /* 311: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P4_f,    /* 312: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P5_m,    /* 313: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P6_n,    /* 314: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P7_b,    /* 315: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P8_a,    /* 316: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P1_e,   /* 317: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P2_b,   /* 318: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P3_e,   /* 319: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P4_b,   /* 320: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P5_n[0],/* 321: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P1_m,   /* 322: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P2_h,   /* 323: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P3_l,   /* 324: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P4_p,   /* 325: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P5_h[0],/* 326: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P1,         /* 327: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P2,         /* 328: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P3,         /* 329: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P4,         /* 330: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P5,         /* 331: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P6,         /* 332: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P7,         /* 333: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P8,         /* 334: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P1,         /* 335: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P2,         /* 336: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P3,         /* 337: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P4,         /* 338: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P5,         /* 339: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P6,         /* 340: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P7,         /* 341: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P8,         /* 342: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P1_o,    /* 343: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P2_f,    /* 344: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P3_h,    /* 345: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P4_b,    /* 346: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P5_k,    /* 347: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P6_c,    /* 348: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P7_a,    /* 349: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P8_c,    /* 350: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P1_hd,   /* 351: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P2_k,    /* 352: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P3_e,    /* 353: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P4_n,    /* 354: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P5_f,    /* 355: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P6_c,    /* 356: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P7_e,    /* 357: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P8_g,    /* 358: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P1_l,   /* 359: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P2_p,   /* 360: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P3_f,   /* 361: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P4_o,   /* 362: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P5_g[0],/* 363: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P1_f,   /* 364: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P2_f,   /* 365: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P3_j,   /* 366: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P4_e,   /* 367: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P5_m[0],/* 368: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P1_e,       /* 369: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P2_d,       /* 370: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P3_e,       /* 371: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P4_l,       /* 372: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P5_d,       /* 373: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P6_a,       /* 374: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P7_h,       /* 375: Block Parameter */
  &KitGewerk2_v14_P.Setup1_P8_d,       /* 376: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P1_m,       /* 377: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P2_k,       /* 378: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P3_i,       /* 379: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P4_n,       /* 380: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P5_h,       /* 381: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P6_f,       /* 382: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P7_a,       /* 383: Block Parameter */
  &KitGewerk2_v14_P.Setup2_P8_f,       /* 384: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value_b,  /* 385: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value,    /* 386: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value_f,  /* 387: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P1,     /* 388: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P2,     /* 389: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P3,     /* 390: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P4,     /* 391: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P5[0],  /* 392: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value_j,  /* 393: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P1,     /* 394: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P2,     /* 395: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P3,     /* 396: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P4,     /* 397: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P5[0],  /* 398: Block Parameter */
  &KitGewerk2_v14_P.Constant1_Value_b, /* 399: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P1,      /* 400: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P2,      /* 401: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P3,      /* 402: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P4,      /* 403: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P5,      /* 404: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P6,      /* 405: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P7,      /* 406: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P8,      /* 407: Block Parameter */
  &KitGewerk2_v14_P.Constant2_Value_a, /* 408: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P1,      /* 409: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P2,      /* 410: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P3,      /* 411: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P4,      /* 412: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P5,      /* 413: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P6,      /* 414: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P7,      /* 415: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P8,      /* 416: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value_d,  /* 417: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P1_p,   /* 418: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P2_k,   /* 419: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P3_g,   /* 420: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P4_f,   /* 421: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite1_P5_p[0],/* 422: Block Parameter */
  &KitGewerk2_v14_P.Constant_Value_ba, /* 423: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P1_o,   /* 424: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P2_l,   /* 425: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P3_d,   /* 426: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P4_d,   /* 427: Block Parameter */
  &KitGewerk2_v14_P.FIFOwrite2_P5_k[0],/* 428: Block Parameter */
  &KitGewerk2_v14_P.Constant1_Value_m, /* 429: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P1_g,    /* 430: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P2_o,    /* 431: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P3_j,    /* 432: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P4_h,    /* 433: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P5_o,    /* 434: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P6_l,    /* 435: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P7_c,    /* 436: Block Parameter */
  &KitGewerk2_v14_P.FIFOread1_P8_g,    /* 437: Block Parameter */
  &KitGewerk2_v14_P.Constant2_Value_i, /* 438: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P1_g,    /* 439: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P2_d,    /* 440: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P3_j,    /* 441: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P4_g,    /* 442: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P5_d,    /* 443: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P6_g,    /* 444: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P7_f,    /* 445: Block Parameter */
  &KitGewerk2_v14_P.FIFOread2_P8_e     /* 446: Block Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

/* Data Type Map - use dataTypeMapIndex to access this structure */
static const rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0 },

  { "unsigned char", "uint8_T", 0, 0, sizeof(uint8_T), SS_UINT8, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0 },

  { "int", "int32_T", 0, 0, sizeof(int32_T), SS_INT32, 0, 0 },

  { "unsigned short", "uint16_T", 0, 0, sizeof(uint16_T), SS_UINT16, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0 },

  { "numeric", "serialfifoptr", 0, 0, sizeof(serialfifoptr), SS_STRUCT, 0, 0 }
};

/* Structure Element Map - use elemMapIndex to access this structure */
static const rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { NULL, 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 12, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 14, 2, 0 },

  { rtwCAPI_VECTOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_VECTOR, 20, 2, 0 },

  { rtwCAPI_VECTOR, 22, 2, 0 },

  { rtwCAPI_VECTOR, 24, 2, 0 },

  { rtwCAPI_VECTOR, 26, 2, 0 },

  { rtwCAPI_VECTOR, 28, 2, 0 },

  { rtwCAPI_VECTOR, 30, 2, 0 },

  { rtwCAPI_VECTOR, 32, 2, 0 },

  { rtwCAPI_VECTOR, 34, 2, 0 },

  { rtwCAPI_VECTOR, 36, 2, 0 },

  { rtwCAPI_VECTOR, 38, 2, 0 },

  { rtwCAPI_VECTOR, 40, 2, 0 },

  { rtwCAPI_VECTOR, 42, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 44, 2, 0 },

  { rtwCAPI_VECTOR, 46, 2, 0 },

  { rtwCAPI_VECTOR, 48, 2, 0 },

  { rtwCAPI_VECTOR, 50, 2, 0 },

  { rtwCAPI_VECTOR, 52, 2, 0 },

  { rtwCAPI_VECTOR, 54, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_VECTOR, 56, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  4,                                   /* 2 */
  1,                                   /* 3 */
  50,                                  /* 4 */
  4,                                   /* 5 */
  200,                                 /* 6 */
  1,                                   /* 7 */
  17,                                  /* 8 */
  4,                                   /* 9 */
  15,                                  /* 10 */
  1,                                   /* 11 */
  1,                                   /* 12 */
  9,                                   /* 13 */
  1,                                   /* 14 */
  2,                                   /* 15 */
  448,                                 /* 16 */
  1,                                   /* 17 */
  56,                                  /* 18 */
  1,                                   /* 19 */
  5,                                   /* 20 */
  1,                                   /* 21 */
  9,                                   /* 22 */
  1,                                   /* 23 */
  3,                                   /* 24 */
  1,                                   /* 25 */
  20,                                  /* 26 */
  1,                                   /* 27 */
  8,                                   /* 28 */
  1,                                   /* 29 */
  102,                                 /* 30 */
  1,                                   /* 31 */
  48,                                  /* 32 */
  1,                                   /* 33 */
  2,                                   /* 34 */
  1,                                   /* 35 */
  6,                                   /* 36 */
  1,                                   /* 37 */
  65,                                  /* 38 */
  1,                                   /* 39 */
  61,                                  /* 40 */
  1,                                   /* 41 */
  1,                                   /* 42 */
  7,                                   /* 43 */
  1,                                   /* 44 */
  8,                                   /* 45 */
  1,                                   /* 46 */
  3,                                   /* 47 */
  1,                                   /* 48 */
  20,                                  /* 49 */
  1,                                   /* 50 */
  102,                                 /* 51 */
  1,                                   /* 52 */
  11,                                  /* 53 */
  1,                                   /* 54 */
  15,                                  /* 55 */
  1,                                   /* 56 */
  6                                    /* 57 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.005, 0.0, 0.5, 1.0, -1.0, -2.0, -3.0
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { NULL, NULL, rtwCAPI_FIX_RESERVED, 0, 0, 0 },

  { (const void *) &rtcapiStoredFloats[3], (const void *) &rtcapiStoredFloats[1],
    rtwCAPI_FIX_UNIFORM_SCALING, 32, -20, 0 },

  { (const void *) &rtcapiStoredFloats[3], (const void *) &rtcapiStoredFloats[1],
    rtwCAPI_FIX_UNIFORM_SCALING, 16, -20, 0 }
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[1],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[1],
    2, 0 },

  { (NULL), (NULL), -1, 0 },

  { (const void *) &rtcapiStoredFloats[4], (const void *) &rtcapiStoredFloats[5],
    3, 0 },

  { (const void *) &rtcapiStoredFloats[4], (const void *) &rtcapiStoredFloats[6],
    4, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 191 },

  { rtBlockParameters, 256,
    rtModelParameters, 0 },

  { NULL, 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 551439995U,
    352028151U,
    2585246182U,
    4036248840U },
  NULL
};

/* Cache pointers into DataMapInfo substructure of RTModel */
void KitGewerk2_v14_InitializeDataMapInfo(RT_MODEL_KitGewerk2_v14_T
  *KitGewerk2_v14_M
  )
{
  /* Set C-API version */
  rtwCAPI_SetVersion(KitGewerk2_v14_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(KitGewerk2_v14_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(KitGewerk2_v14_M->DataMapInfo.mmi, NULL);

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(KitGewerk2_v14_M->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(KitGewerk2_v14_M->DataMapInfo.mmi,
    rtVarDimsAddrMap);

  /* Cache C-API rtp Address and size  into the Real-Time Model Data structure */
  KitGewerk2_v14_M->DataMapInfo.mmi.InstanceMap.rtpAddress = rtmGetDefaultParam
    (KitGewerk2_v14_M);
  KitGewerk2_v14_M->DataMapInfo.mmi.staticMap->rtpSize = sizeof
    (P_KitGewerk2_v14_T);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(KitGewerk2_v14_M->DataMapInfo.mmi, NULL);

  /* Set Reference to submodels */
  rtwCAPI_SetChildMMIArray(KitGewerk2_v14_M->DataMapInfo.mmi, NULL);
  rtwCAPI_SetChildMMIArrayLen(KitGewerk2_v14_M->DataMapInfo.mmi, 0);
}

/* EOF: KitGewerk2_v14_capi.c */
