/*
 * KitGewerk2_v14_dt.h
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(serialfifoptr),
  sizeof(uint16_T),
  sizeof(uint32_T)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "serialfifoptr",
  "uint16_T",
  "uint32_T"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&KitGewerk2_v14_B.RateTransition), 14, 0, 16 },

  { (char_T *)(&KitGewerk2_v14_B.uint16todouble[0]), 0, 0, 1449 },

  { (char_T *)(&KitGewerk2_v14_B.Counter_o1), 6, 0, 1 },

  { (char_T *)(&KitGewerk2_v14_B.Memory1), 7, 0, 516 },

  { (char_T *)(&KitGewerk2_v14_B.Gain1), 16, 0, 1 },

  { (char_T *)(&KitGewerk2_v14_B.FIFOread1[0]), 5, 0, 258 },

  { (char_T *)(&KitGewerk2_v14_B.Receive_o1[0]), 3, 0, 624 },

  { (char_T *)(&KitGewerk2_v14_B.Constant7), 8, 0, 18 }
  ,

  { (char_T *)(&KitGewerk2_v14_DW.lasterrorfreeresponse_PreviousI[0]), 0, 0, 106
  },

  { (char_T *)(&KitGewerk2_v14_DW.Receive_PWORK), 11, 0, 18 },

  { (char_T *)(&KitGewerk2_v14_DW.sfEvent), 6, 0, 1 },

  { (char_T *)(&KitGewerk2_v14_DW.Memory1_PreviousInput), 7, 0, 3 },

  { (char_T *)(&KitGewerk2_v14_DW.Receive_IWORK[0]), 10, 0, 68 },

  { (char_T *)(&KitGewerk2_v14_DW.Memory_PreviousInput), 5, 0, 2 },

  { (char_T *)(&KitGewerk2_v14_DW.RS232ISR_SubsysRanBC), 2, 0, 16 },

  { (char_T *)(&KitGewerk2_v14_DW.RateTransitionupsamplingtofunda[0]), 3, 0, 19
  },

  { (char_T *)(&KitGewerk2_v14_DW.isStable), 8, 0, 2 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  17U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&KitGewerk2_v14_P.DischargingCounter_InitialCount), 7, 0, 1 },

  { (char_T *)(&KitGewerk2_v14_P.ChargingCounter_InitialCount), 5, 0, 1 },

  { (char_T *)(&KitGewerk2_v14_P.Counter_HitValue), 3, 0, 2 },

  { (char_T *)(&KitGewerk2_v14_P.Receivefromall_P1_Size[0]), 0, 0, 1072 },

  { (char_T *)(&KitGewerk2_v14_P.Constant_Value_f), 7, 0, 9 },

  { (char_T *)(&KitGewerk2_v14_P.Memory_X0), 5, 0, 2 },

  { (char_T *)(&KitGewerk2_v14_P.RateTransitionupsamplingtofunda), 3, 0, 6 },

  { (char_T *)(&KitGewerk2_v14_P.Constant7_Value), 8, 0, 6 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  8U,
  rtPTransitions
};

/* [EOF] KitGewerk2_v14_dt.h */
