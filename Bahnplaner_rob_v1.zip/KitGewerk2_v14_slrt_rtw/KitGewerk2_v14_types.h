/*
 * KitGewerk2_v14_types.h
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_KitGewerk2_v14_types_h_
#define RTW_HEADER_KitGewerk2_v14_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_KitGewerk2_v14_T_ P_KitGewerk2_v14_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_KitGewerk2_v14_T RT_MODEL_KitGewerk2_v14_T;

#endif                                 /* RTW_HEADER_KitGewerk2_v14_types_h_ */
