/*
 * KitGewerk2_v14_data.c
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "KitGewerk2_v14.h"
#include "KitGewerk2_v14_private.h"

/* Block parameters (auto storage) */
P_KitGewerk2_v14_T KitGewerk2_v14_P = {
  180002U,                             /* Mask Parameter: DischargingCounter_InitialCount
                                        * Referenced by: '<S26>/Discharging Counter'
                                        */
  0U,                                  /* Mask Parameter: ChargingCounter_InitialCount
                                        * Referenced by: '<S26>/Charging Counter'
                                        */
  49U,                                 /* Mask Parameter: Counter_HitValue
                                        * Referenced by: '<S5>/Counter'
                                        */
  0U,                                  /* Mask Parameter: Counter_InitialCount
                                        * Referenced by: '<S5>/Counter'
                                        */

  /*  Computed Parameter: Receivefromall_P1_Size
   * Referenced by: '<S14>/Receive from all'
   */
  { 1.0, 7.0 },

  /*  Computed Parameter: Receivefromall_P1
   * Referenced by: '<S14>/Receive from all'
   */
  { 48.0, 46.0, 48.0, 46.0, 48.0, 46.0, 48.0 },

  /*  Computed Parameter: Receivefromall_P2_Size
   * Referenced by: '<S14>/Receive from all'
   */
  { 1.0, 1.0 },
  25014.0,                             /* Expression: ipPort
                                        * Referenced by: '<S14>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P3_Size
   * Referenced by: '<S14>/Receive from all'
   */
  { 1.0, 1.0 },
  5.0,                                 /* Expression: width
                                        * Referenced by: '<S14>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P4_Size
   * Referenced by: '<S14>/Receive from all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S14>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P5_Size
   * Referenced by: '<S14>/Receive from all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S14>/Receive from all'
                                        */

  /*  Computed Parameter: Sendtoall_P1_Size
   * Referenced by: '<S14>/Send to all'
   */
  { 1.0, 15.0 },

  /*  Computed Parameter: Sendtoall_P1
   * Referenced by: '<S14>/Send to all'
   */
  { 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0,
    53.0, 53.0 },

  /*  Computed Parameter: Sendtoall_P2_Size
   * Referenced by: '<S14>/Send to all'
   */
  { 1.0, 1.0 },
  25040.0,                             /* Expression: ipPort
                                        * Referenced by: '<S14>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P3_Size
   * Referenced by: '<S14>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: localPort
                                        * Referenced by: '<S14>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P4_Size
   * Referenced by: '<S14>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S14>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P5_Size
   * Referenced by: '<S14>/Send to all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S14>/Send to all'
                                        */

  /*  Computed Parameter: Receivefromall_P1_Size_i
   * Referenced by: '<S13>/Receive from all'
   */
  { 1.0, 7.0 },

  /*  Computed Parameter: Receivefromall_P1_p
   * Referenced by: '<S13>/Receive from all'
   */
  { 48.0, 46.0, 48.0, 46.0, 48.0, 46.0, 48.0 },

  /*  Computed Parameter: Receivefromall_P2_Size_f
   * Referenced by: '<S13>/Receive from all'
   */
  { 1.0, 1.0 },
  25013.0,                             /* Expression: ipPort
                                        * Referenced by: '<S13>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P3_Size_g
   * Referenced by: '<S13>/Receive from all'
   */
  { 1.0, 1.0 },
  5.0,                                 /* Expression: width
                                        * Referenced by: '<S13>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P4_Size_m
   * Referenced by: '<S13>/Receive from all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S13>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P5_Size_l
   * Referenced by: '<S13>/Receive from all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S13>/Receive from all'
                                        */

  /*  Computed Parameter: Sendtoall_P1_Size_j
   * Referenced by: '<S13>/Send to all'
   */
  { 1.0, 15.0 },

  /*  Computed Parameter: Sendtoall_P1_k
   * Referenced by: '<S13>/Send to all'
   */
  { 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0,
    53.0, 53.0 },

  /*  Computed Parameter: Sendtoall_P2_Size_i
   * Referenced by: '<S13>/Send to all'
   */
  { 1.0, 1.0 },
  25030.0,                             /* Expression: ipPort
                                        * Referenced by: '<S13>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P3_Size_m
   * Referenced by: '<S13>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: localPort
                                        * Referenced by: '<S13>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P4_Size_p
   * Referenced by: '<S13>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S13>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P5_Size_p
   * Referenced by: '<S13>/Send to all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S13>/Send to all'
                                        */

  /*  Computed Parameter: Receivefromall_P1_Size_g
   * Referenced by: '<S12>/Receive from all'
   */
  { 1.0, 7.0 },

  /*  Computed Parameter: Receivefromall_P1_h
   * Referenced by: '<S12>/Receive from all'
   */
  { 48.0, 46.0, 48.0, 46.0, 48.0, 46.0, 48.0 },

  /*  Computed Parameter: Receivefromall_P2_Size_c
   * Referenced by: '<S12>/Receive from all'
   */
  { 1.0, 1.0 },
  25012.0,                             /* Expression: ipPort
                                        * Referenced by: '<S12>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P3_Size_gk
   * Referenced by: '<S12>/Receive from all'
   */
  { 1.0, 1.0 },
  5.0,                                 /* Expression: width
                                        * Referenced by: '<S12>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P4_Size_c
   * Referenced by: '<S12>/Receive from all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S12>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P5_Size_g
   * Referenced by: '<S12>/Receive from all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S12>/Receive from all'
                                        */

  /*  Computed Parameter: Sendtoall_P1_Size_c
   * Referenced by: '<S12>/Send to all'
   */
  { 1.0, 15.0 },

  /*  Computed Parameter: Sendtoall_P1_e
   * Referenced by: '<S12>/Send to all'
   */
  { 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0,
    53.0, 53.0 },

  /*  Computed Parameter: Sendtoall_P2_Size_l
   * Referenced by: '<S12>/Send to all'
   */
  { 1.0, 1.0 },
  25020.0,                             /* Expression: ipPort
                                        * Referenced by: '<S12>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P3_Size_n
   * Referenced by: '<S12>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: localPort
                                        * Referenced by: '<S12>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P4_Size_o
   * Referenced by: '<S12>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S12>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P5_Size_n
   * Referenced by: '<S12>/Send to all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S12>/Send to all'
                                        */

  /*  Computed Parameter: Receivefromall_P1_Size_b
   * Referenced by: '<S11>/Receive from all'
   */
  { 1.0, 7.0 },

  /*  Computed Parameter: Receivefromall_P1_i
   * Referenced by: '<S11>/Receive from all'
   */
  { 48.0, 46.0, 48.0, 46.0, 48.0, 46.0, 48.0 },

  /*  Computed Parameter: Receivefromall_P2_Size_o
   * Referenced by: '<S11>/Receive from all'
   */
  { 1.0, 1.0 },
  25011.0,                             /* Expression: ipPort
                                        * Referenced by: '<S11>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P3_Size_b
   * Referenced by: '<S11>/Receive from all'
   */
  { 1.0, 1.0 },
  5.0,                                 /* Expression: width
                                        * Referenced by: '<S11>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P4_Size_e
   * Referenced by: '<S11>/Receive from all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S11>/Receive from all'
                                        */

  /*  Computed Parameter: Receivefromall_P5_Size_gi
   * Referenced by: '<S11>/Receive from all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S11>/Receive from all'
                                        */

  /*  Computed Parameter: Sendtoall_P1_Size_e
   * Referenced by: '<S11>/Send to all'
   */
  { 1.0, 15.0 },

  /*  Computed Parameter: Sendtoall_P1_d
   * Referenced by: '<S11>/Send to all'
   */
  { 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0, 53.0, 53.0, 46.0, 50.0,
    53.0, 53.0 },

  /*  Computed Parameter: Sendtoall_P2_Size_f
   * Referenced by: '<S11>/Send to all'
   */
  { 1.0, 1.0 },
  25010.0,                             /* Expression: ipPort
                                        * Referenced by: '<S11>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P3_Size_h
   * Referenced by: '<S11>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: localPort
                                        * Referenced by: '<S11>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P4_Size_e
   * Referenced by: '<S11>/Send to all'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S11>/Send to all'
                                        */

  /*  Computed Parameter: Sendtoall_P5_Size_l
   * Referenced by: '<S11>/Send to all'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S11>/Send to all'
                                        */

  /*  Expression: [3 1]
   * Referenced by: '<S20>/Constant1'
   */
  { 3.0, 1.0 },

  /*  Expression: [1 1]
   * Referenced by: '<S20>/Constant2'
   */
  { 1.0, 1.0 },

  /*  Expression: [1 2 1 3 1 4]
   * Referenced by: '<S20>/Constant3'
   */
  { 1.0, 2.0, 1.0, 3.0, 1.0, 4.0 },

  /*  Computed Parameter: FIFOwrite1_P1_Size
   * Referenced by: '<S37>/FIFO write 1'
   */
  { 1.0, 1.0 },
  10240.0,                             /* Expression: size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P2_Size
   * Referenced by: '<S37>/FIFO write 1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P3_Size
   * Referenced by: '<S37>/FIFO write 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P4_Size
   * Referenced by: '<S37>/FIFO write 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: present
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P5_Size
   * Referenced by: '<S37>/FIFO write 1'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite1_P5
   * Referenced by: '<S37>/FIFO write 1'
   */
  { 82.0, 67.0, 86.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    49.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 51.0 },

  /*  Computed Parameter: FIFOread1_P1_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  60.0,                                /* Expression: maxsize
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P2_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P3_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P4_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  13.0,                                /* Expression: delimiter
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P5_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P6_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P7_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enable
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P8_Size
   * Referenced by: '<S39>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enableout
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOwrite2_P1_Size
   * Referenced by: '<S38>/FIFO write 2'
   */
  { 1.0, 1.0 },
  1024.0,                              /* Expression: size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P2_Size
   * Referenced by: '<S38>/FIFO write 2'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P3_Size
   * Referenced by: '<S38>/FIFO write 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P4_Size
   * Referenced by: '<S38>/FIFO write 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: present
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P5_Size
   * Referenced by: '<S38>/FIFO write 2'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite2_P5
   * Referenced by: '<S38>/FIFO write 2'
   */
  { 82.0, 67.0, 86.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    50.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 51.0 },

  /*  Computed Parameter: FIFOread2_P1_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  60.0,                                /* Expression: maxsize
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P2_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P3_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P4_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  13.0,                                /* Expression: delimiter
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P5_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P6_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P7_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enable
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P8_Size
   * Referenced by: '<S40>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enableout
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOwrite1_P1_Size_f
   * Referenced by: '<S52>/FIFO write 1'
   */
  { 1.0, 1.0 },
  10240.0,                             /* Expression: size
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P2_Size_i
   * Referenced by: '<S52>/FIFO write 1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P3_Size_m
   * Referenced by: '<S52>/FIFO write 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P4_Size_l
   * Referenced by: '<S52>/FIFO write 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: present
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P5_Size_b
   * Referenced by: '<S52>/FIFO write 1'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite1_P5_p
   * Referenced by: '<S52>/FIFO write 1'
   */
  { 82.0, 67.0, 86.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    49.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 52.0 },

  /*  Computed Parameter: FIFOread1_P1_Size_k
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  60.0,                                /* Expression: maxsize
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P2_Size_f
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P3_Size_k
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P4_Size_o
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  13.0,                                /* Expression: delimiter
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P5_Size_d
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P6_Size_f
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P7_Size_b
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enable
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P8_Size_k
   * Referenced by: '<S54>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enableout
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOwrite2_P1_Size_d
   * Referenced by: '<S53>/FIFO write 2'
   */
  { 1.0, 1.0 },
  10240.0,                             /* Expression: size
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P2_Size_a
   * Referenced by: '<S53>/FIFO write 2'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P3_Size_e
   * Referenced by: '<S53>/FIFO write 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P4_Size_p
   * Referenced by: '<S53>/FIFO write 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: present
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P5_Size_f
   * Referenced by: '<S53>/FIFO write 2'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite2_P5_k
   * Referenced by: '<S53>/FIFO write 2'
   */
  { 82.0, 67.0, 86.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    50.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 52.0 },

  /*  Computed Parameter: FIFOread2_P1_Size_j
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  60.0,                                /* Expression: maxsize
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P2_Size_n
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P3_Size_h
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P4_Size_d
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  13.0,                                /* Expression: delimiter
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P5_Size_i
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P6_Size_h
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P7_Size_b
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enable
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P8_Size_j
   * Referenced by: '<S55>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: enableout
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */

  /*  Computed Parameter: FromFile_P1_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 11.0 },

  /*  Computed Parameter: FromFile_P1
   * Referenced by: '<S57>/From File'
   */
  { 114.0, 111.0, 98.0, 111.0, 116.0, 105.0, 110.0, 111.0, 46.0, 105.0, 100.0 },

  /*  Computed Parameter: FromFile_P2_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 1.0 },
  8.0,                                 /* Expression: dataSize
                                        * Referenced by: '<S57>/From File'
                                        */

  /*  Computed Parameter: FromFile_P3_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 1.0 },
  2000.0,                              /* Expression: bufSize
                                        * Referenced by: '<S57>/From File'
                                        */

  /*  Computed Parameter: FromFile_P4_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 1.0 },
  512.0,                               /* Expression: readSize
                                        * Referenced by: '<S57>/From File'
                                        */

  /*  Computed Parameter: FromFile_P5_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: EOFOption
                                        * Referenced by: '<S57>/From File'
                                        */

  /*  Computed Parameter: FromFile_P6_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampTime
                                        * Referenced by: '<S57>/From File'
                                        */

  /*  Computed Parameter: FromFile_P7_Size
   * Referenced by: '<S57>/From File'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: show2ports
                                        * Referenced by: '<S57>/From File'
                                        */

  /*  Computed Parameter: FIFOread1_P1_Size_d
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  101.0,                               /* Expression: maxsize
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P2_Size_k
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P3_Size_i
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P4_Size_b
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  99.0,                                /* Expression: delimiter
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P5_Size_o
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P6_Size_e
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P7_Size_g
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enable
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P8_Size_o
   * Referenced by: '<S47>/FIFO read 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enableout
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */

  /*  Expression: [zeros(1,102)]
   * Referenced by: '<S45>/last error free response'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /*  Expression: [zeros(1,3)]
   * Referenced by: '<S45>/stop marker'
   */
  { 0.0, 0.0, 0.0 },

  /*  Computed Parameter: Receive_P1_Size
   * Referenced by: '<S8>/Receive'
   */
  { 1.0, 7.0 },

  /*  Computed Parameter: Receive_P1
   * Referenced by: '<S8>/Receive'
   */
  { 48.0, 46.0, 48.0, 46.0, 48.0, 46.0, 48.0 },

  /*  Computed Parameter: Receive_P2_Size
   * Referenced by: '<S8>/Receive'
   */
  { 1.0, 1.0 },
  25000.0,                             /* Expression: ipPort
                                        * Referenced by: '<S8>/Receive'
                                        */

  /*  Computed Parameter: Receive_P3_Size
   * Referenced by: '<S8>/Receive'
   */
  { 1.0, 1.0 },
  448.0,                               /* Expression: width
                                        * Referenced by: '<S8>/Receive'
                                        */

  /*  Computed Parameter: Receive_P4_Size
   * Referenced by: '<S8>/Receive'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S8>/Receive'
                                        */

  /*  Computed Parameter: Receive_P5_Size
   * Referenced by: '<S8>/Receive'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: vblLen
                                        * Referenced by: '<S8>/Receive'
                                        */

  /*  Computed Parameter: FIFOread1_P1_Size_h
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  3.0,                                 /* Expression: maxsize
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P2_Size_o
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P3_Size_a
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P4_Size_f
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  10.0,                                /* Expression: delimiter
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P5_Size_e
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P6_Size_l
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P7_Size_c
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enable
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */

  /*  Computed Parameter: FIFOread1_P8_Size_f
   * Referenced by: '<S34>/FIFO read 1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enableout
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  0.01,                                /* Expression: 0.01
                                        * Referenced by: '<S9>/Step'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S9>/Step'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S9>/Step'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S28>/Constant'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S27>/Constant'
                                        */
  -2.0,                                /* Expression: -2
                                        * Referenced by: '<S26>/Constant2'
                                        */
  0.00055555555555555556,              /* Expression: 1/1800
                                        * Referenced by: '<S26>/Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  400.0,                               /* Expression: 400
                                        * Referenced by: '<S5>/Bremsabstand'
                                        */

  /*  Expression: [6:14]
   * Referenced by: '<S15>/Konstante f�r die Abstandssensoren'
   */
  { 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Constant4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/constant1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S15>/Konstante f�r den Lichtschranke'
                                        */
  2.0,                                 /* Expression: 2
                                        * Referenced by: '<S15>/Konstante f�r den Schieber'
                                        */
  3.0,                                 /* Expression: 3
                                        * Referenced by: '<S15>/Konstante f�r den L�ngsgeschwindigkeit'
                                        */
  4.0,                                 /* Expression: 4
                                        * Referenced by: '<S15>/Konstante f�r den Quergeschwindigkeit1'
                                        */
  5.0,                                 /* Expression: 5
                                        * Referenced by: '<S15>/Konstante f�r den Rotationegeschwindigkeit'
                                        */
  15.0,                                /* Expression: 15
                                        * Referenced by: '<S15>/Konstante f�r Kollision '
                                        */

  /*  Expression: [1:3]
   * Referenced by: '<S16>/Kamera X Y Roboter 1'
   */
  { 1.0, 2.0, 3.0 },

  /*  Expression: [37:56]
   * Referenced by: '<S16>/�bermittelung Koordinaten Kons.'
   */
  { 37.0, 38.0, 39.0, 40.0, 41.0, 42.0, 43.0, 44.0, 45.0, 46.0, 47.0, 48.0, 49.0,
    50.0, 51.0, 52.0, 53.0, 54.0, 55.0, 56.0 },

  /*  Expression: [4:6]
   * Referenced by: '<S16>/Kamera X Y Roboter 2'
   */
  { 4.0, 5.0, 6.0 },

  /*  Expression: [7:9]
   * Referenced by: '<S16>/Kamera X Y Roboter 3'
   */
  { 7.0, 8.0, 9.0 },

  /*  Expression: [10:12]
   * Referenced by: '<S16>/Kamera X Y Roboter 4'
   */
  { 10.0, 11.0, 12.0 },
  25.0,                                /* Expression: 25
                                        * Referenced by: '<S16>/Zeitstempel'
                                        */
  26.0,                                /* Expression: 26
                                        * Referenced by: '<S16>/Zeitstempel1'
                                        */
  27.0,                                /* Expression: 27
                                        * Referenced by: '<S16>/Zeitstempel2'
                                        */
  28.0,                                /* Expression: 28
                                        * Referenced by: '<S16>/Fahrerlaubnis Kons.'
                                        */

  /*  Expression: [29:36]
   * Referenced by: '<S16>/Camera Variablen Konst.'
   */
  { 29.0, 30.0, 31.0, 32.0, 33.0, 34.0, 35.0, 36.0 },

  /*  Expression: [4775 1800 180 300 ; 3745 1800 180 300; 2540 2100 180 300; 2160 2100 180 300; 1678 1894 180 300; 1373 1846 180 300; 1155 1627 180 300; 1106 1321 180 300; 1246 1046 180 300; 1522 906 180 300; 1827 954 180 300; 2300 954 180 300; 2800 1500 180 300; 3300 1000 180 300; 3800 1500 180 300; 4300 1000 180 300; 4800 1500 180 300 ]
   * Referenced by: '<S5>/Wegpunktliste zum Testen'
   */
  { 4775.0, 3745.0, 2540.0, 2160.0, 1678.0, 1373.0, 1155.0, 1106.0, 1246.0,
    1522.0, 1827.0, 2300.0, 2800.0, 3300.0, 3800.0, 4300.0, 4800.0, 1800.0,
    1800.0, 2100.0, 2100.0, 1894.0, 1846.0, 1627.0, 1321.0, 1046.0, 906.0, 954.0,
    954.0, 1500.0, 1000.0, 1500.0, 1000.0, 1500.0, 180.0, 180.0, 180.0, 180.0,
    180.0, 180.0, 180.0, 180.0, 180.0, 180.0, 180.0, 180.0, 180.0, 180.0, 180.0,
    180.0, 180.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0,
    300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0, 300.0 },

  /*  Computed Parameter: FIFOwrite1_P1_Size_o
   * Referenced by: '<S34>/FIFO write 1'
   */
  { 1.0, 1.0 },
  10240.0,                             /* Expression: size
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P2_Size_d
   * Referenced by: '<S34>/FIFO write 1'
   */
  { 1.0, 1.0 },
  6.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P3_Size_i
   * Referenced by: '<S34>/FIFO write 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P4_Size_p
   * Referenced by: '<S34>/FIFO write 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: present
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P5_Size_n
   * Referenced by: '<S34>/FIFO write 1'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite1_P5_n
   * Referenced by: '<S34>/FIFO write 1'
   */
  { 88.0, 77.0, 84.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    49.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 51.0 },

  /*  Computed Parameter: FIFOwrite2_P1_Size_a
   * Referenced by: '<S34>/FIFO write 2'
   */
  { 1.0, 1.0 },
  1024.0,                              /* Expression: size
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P2_Size_n
   * Referenced by: '<S34>/FIFO write 2'
   */
  { 1.0, 1.0 },
  6.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P3_Size_j
   * Referenced by: '<S34>/FIFO write 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P4_Size_i
   * Referenced by: '<S34>/FIFO write 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: present
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P5_Size_fb
   * Referenced by: '<S34>/FIFO write 2'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite2_P5_h
   * Referenced by: '<S34>/FIFO write 2'
   */
  { 88.0, 77.0, 84.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    50.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 51.0 },

  /*  Computed Parameter: FIFOread2_P1_Size_b
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  101.0,                               /* Expression: maxsize
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P2_Size_b
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P3_Size_i
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P4_Size_a
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  10.0,                                /* Expression: delimiter
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P5_Size_m
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  6.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P6_Size_h1
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P7_Size_g
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enable
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P8_Size_o
   * Referenced by: '<S34>/FIFO read 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enableout
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */

  /*  Computed Parameter: Setup1_P1_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  760.0,                               /* Expression: addr
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P2_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  5.0,                                 /* Expression: baud
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P3_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: width
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P4_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: nstop
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P5_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: parity
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P6_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: fmode
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P7_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: ctsmode
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P8_Size
   * Referenced by: '<S34>/Setup1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: rlevel
                                        * Referenced by: '<S34>/Setup1'
                                        */

  /*  Computed Parameter: Setup2_P1_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: addr
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P2_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  8.0,                                 /* Expression: baud
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P3_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: width
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P4_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: nstop
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P5_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: parity
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P6_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: fmode
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P7_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: ctsmode
                                        * Referenced by: '<S34>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P8_Size
   * Referenced by: '<S34>/Setup2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: rlevel
                                        * Referenced by: '<S34>/Setup2'
                                        */
  2.0,                                 /* Expression: 2
                                        * Referenced by: '<S7>/Gain'
                                        */
  255.0,                               /* Expression: 255
                                        * Referenced by: '<S7>/Grabber velocity'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/constant'
                                        */

  /*  Computed Parameter: FIFOwrite1_P1_Size_b
   * Referenced by: '<S47>/FIFO write 1'
   */
  { 1.0, 1.0 },
  10240.0,                             /* Expression: size
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P2_Size_k
   * Referenced by: '<S47>/FIFO write 1'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P3_Size_g
   * Referenced by: '<S47>/FIFO write 1'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P4_Size_f
   * Referenced by: '<S47>/FIFO write 1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: present
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */

  /*  Computed Parameter: FIFOwrite1_P5_Size_j
   * Referenced by: '<S47>/FIFO write 1'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite1_P5_g
   * Referenced by: '<S47>/FIFO write 1'
   */
  { 88.0, 77.0, 84.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    49.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 52.0 },

  /*  Computed Parameter: FIFOwrite2_P1_Size_dz
   * Referenced by: '<S47>/FIFO write 2'
   */
  { 1.0, 1.0 },
  10240.0,                             /* Expression: size
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P2_Size_c
   * Referenced by: '<S47>/FIFO write 2'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: inputtype
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P3_Size_b
   * Referenced by: '<S47>/FIFO write 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P4_Size_c
   * Referenced by: '<S47>/FIFO write 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: present
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */

  /*  Computed Parameter: FIFOwrite2_P5_Size_o
   * Referenced by: '<S47>/FIFO write 2'
   */
  { 1.0, 20.0 },

  /*  Computed Parameter: FIFOwrite2_P5_m
   * Referenced by: '<S47>/FIFO write 2'
   */
  { 88.0, 77.0, 84.0, 32.0, 99.0, 104.0, 97.0, 110.0, 110.0, 101.0, 108.0, 32.0,
    50.0, 44.0, 32.0, 73.0, 82.0, 81.0, 32.0, 52.0 },

  /*  Computed Parameter: FIFOread2_P1_Size_c
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  101.0,                               /* Expression: maxsize
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P2_Size_a
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: minsize
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P3_Size_o
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: usedelimiter
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P4_Size_o
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  99.0,                                /* Expression: delimiter
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P5_Size_h
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: outputtype
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P6_Size_a
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  -1.0,                                /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P7_Size_g0
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enable
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: FIFOread2_P8_Size_b
   * Referenced by: '<S47>/FIFO read 2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: enableout
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */

  /*  Computed Parameter: Setup1_P1_Size_m
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  1016.0,                              /* Expression: addr
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P2_Size_c
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: baud
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P3_Size_c
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: width
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P4_Size_k
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: nstop
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P5_Size_m
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: parity
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P6_Size_o
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: fmode
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P7_Size_c
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: ctsmode
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup1_P8_Size_l
   * Referenced by: '<S47>/Setup1'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: rlevel
                                        * Referenced by: '<S47>/Setup1'
                                        */

  /*  Computed Parameter: Setup2_P1_Size_e
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: addr
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P2_Size_b
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: baud
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P3_Size_k
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: width
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P4_Size_g
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: nstop
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P5_Size_o
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  1.0,                                 /* Expression: parity
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P6_Size_m
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  2.0,                                 /* Expression: fmode
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P7_Size_c
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  0.0,                                 /* Expression: ctsmode
                                        * Referenced by: '<S47>/Setup2'
                                        */

  /*  Computed Parameter: Setup2_P8_Size_k
   * Referenced by: '<S47>/Setup2'
   */
  { 1.0, 1.0 },
  4.0,                                 /* Expression: rlevel
                                        * Referenced by: '<S47>/Setup2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/constant3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/constant4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/constant5'
                                        */
  1U,                                  /* Computed Parameter: Constant_Value_f
                                        * Referenced by: '<S37>/Constant'
                                        */
  1U,                                  /* Computed Parameter: Constant1_Value_b
                                        * Referenced by: '<S39>/Constant1'
                                        */
  1U,                                  /* Computed Parameter: Constant_Value_j
                                        * Referenced by: '<S38>/Constant'
                                        */
  1U,                                  /* Computed Parameter: Constant2_Value_a
                                        * Referenced by: '<S40>/Constant2'
                                        */
  1U,                                  /* Computed Parameter: Constant_Value_d
                                        * Referenced by: '<S52>/Constant'
                                        */
  1U,                                  /* Computed Parameter: Constant1_Value_m
                                        * Referenced by: '<S54>/Constant1'
                                        */
  1U,                                  /* Computed Parameter: Constant_Value_ba
                                        * Referenced by: '<S53>/Constant'
                                        */
  1U,                                  /* Computed Parameter: Constant2_Value_i
                                        * Referenced by: '<S55>/Constant2'
                                        */
  0U,                                  /* Computed Parameter: Memory1_X0
                                        * Referenced by: '<S26>/Memory1'
                                        */
  0U,                                  /* Computed Parameter: Memory_X0
                                        * Referenced by: '<S26>/Memory'
                                        */
  34953U,                              /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S26>/Gain1'
                                        */
  0U,                                  /* Computed Parameter: RateTransitionupsamplingtofunda
                                        * Referenced by: '<S10>/Rate Transition up-sampling to fundamental sample time'
                                        */
  2U,                                  /* Computed Parameter: Constant4_Value_g
                                        * Referenced by: '<S5>/Constant4'
                                        */
  0U,                                  /* Computed Parameter: PreviousFlag_X0
                                        * Referenced by: '<S24>/Previous Flag'
                                        */
  0U,                                  /* Computed Parameter: PreviousSOC_X0
                                        * Referenced by: '<S24>/Previous SOC'
                                        */
  0U,                                  /* Computed Parameter: Constant2_Value_p
                                        * Referenced by: '<Root>/Constant2'
                                        */
  100U,                                /* Computed Parameter: Constant3_Value_j
                                        * Referenced by: '<Root>/Constant3'
                                        */
  1,                                   /* Computed Parameter: Constant7_Value
                                        * Referenced by: '<S5>/Constant7'
                                        */
  1,                                   /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S5>/Constant5'
                                        */
  1,                                   /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<S5>/Constant'
                                        */
  1,                                   /* Computed Parameter: Constant2_Value_b
                                        * Referenced by: '<S5>/Constant2'
                                        */
  1,                                   /* Computed Parameter: Constant1_Value_n
                                        * Referenced by: '<Root>/Constant1'
                                        */
  0                                    /* Computed Parameter: constant2_Value
                                        * Referenced by: '<Root>/constant2'
                                        */
};
