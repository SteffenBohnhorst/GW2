/*
 * KitGewerk2_v14.h
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_KitGewerk2_v14_h_
#define RTW_HEADER_KitGewerk2_v14_h_
#include <stddef.h>
#include <string.h>
#include <math.h>
#include "rtw_modelmap.h"
#ifndef KitGewerk2_v14_COMMON_INCLUDES_
# define KitGewerk2_v14_COMMON_INCLUDES_
#include <serialdefines.h>
#include <xpctarget.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "dt_info.h"
#include "ext_work.h"
#endif                                 /* KitGewerk2_v14_COMMON_INCLUDES_ */

#include "KitGewerk2_v14_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rt_zcfcn.h"
#include "rt_defines.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlkStateChangeFlag
# define rtmGetBlkStateChangeFlag(rtm) ((rtm)->ModelData.blkStateChange)
#endif

#ifndef rtmSetBlkStateChangeFlag
# define rtmSetBlkStateChangeFlag(rtm, val) ((rtm)->ModelData.blkStateChange = (val))
#endif

#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->ModelData.blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->ModelData.blockIO = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm)          ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val)     ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm)       ((rtm)->ModelData.constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val)  ((rtm)->ModelData.constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->ModelData.contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->ModelData.contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->ModelData.contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->ModelData.contStates = (val))
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->ModelData.defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->ModelData.defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->ModelData.derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->ModelData.derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm)  ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm)    ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
# define rtmSetFinalTime(rtm, val)     ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm)  ()
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ()
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ()
#endif

#ifndef rtmGetMdlRefGlobalTID
# define rtmGetMdlRefGlobalTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefGlobalTID
# define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
# define rtmGetMdlRefTriggerTID(rtm)   ()
#endif

#ifndef rtmSetMdlRefTriggerTID
# define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm)   ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm)          ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val)     ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
# define rtmGetNonInlinedSFcns(rtm)    ((rtm)->NonInlinedSFcns)
#endif

#ifndef rtmSetNonInlinedSFcns
# define rtmSetNonInlinedSFcns(rtm, val) ((rtm)->NonInlinedSFcns = (val))
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm)         ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val)    ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm)     ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm)          ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val)     ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm)      ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm)           ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val)      ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm)      ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm)   ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm)     ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm)      ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm)      ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm)     ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm)               ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val)          ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm)               ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val)          ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ()
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ()
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ()
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ()
#endif

#ifndef rtmGetOffsetTimeArray
# define rtmGetOffsetTimeArray(rtm)    ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
# define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm)      ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm)            ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val)       ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ()
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm)               ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val)          ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm)  ((rtm)->Timing.RateInteraction)
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ((rtm)->Timing.RateInteraction = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsArray
# define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
# define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm)     ((rtm)->ModelData.prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->ModelData.prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm)   ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val)    ((rtm)->rtwLogInfo = (val))
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm)        ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val)   ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm)      ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
# define rtmGetRTWSolverInfoPtr(rtm)   ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
# define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm)     ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->ModelData.dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->ModelData.dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm)         ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val)    ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
# define rtmGetSampleHitArray(rtm)     ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
# define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm)       ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val)  ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
# define rtmGetSampleTimeArray(rtm)    ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
# define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm)      ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
# define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
# define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm)            ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val)       ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm)        ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val)   ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm)          ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val)     ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm)           ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val)      ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm)  ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
# define rtmGetTaskCounters(rtm)       ((rtm)->Timing.TaskCounters)
#endif

#ifndef rtmSetTaskCounters
# define rtmSetTaskCounters(rtm, val)  ((rtm)->Timing.TaskCounters = (val))
#endif

#ifndef rtmGetTaskTimeArray
# define rtmGetTaskTimeArray(rtm)      ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
# define rtmSetTaskTimeArray(rtm, val) ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm)            ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val)       ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm)         ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val)    ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->ModelData.inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->ModelData.inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->ModelData.outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->ModelData.outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->ModelData.zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->ModelData.zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
# define rtmGetZCSignalValues(rtm)     ((rtm)->ModelData.zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
# define rtmSetZCSignalValues(rtm, val) ((rtm)->ModelData.zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
# define rtmGet_TimeOfLastOutput(rtm)  ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
# define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->ModelData.derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->ModelData.derivs = (val))
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx)   ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx)         ((rtm)->ModelData.dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val)    ((rtm)->ModelData.dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx)    ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx)     ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx)    ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
# define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
# define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) ((tid) <= 1)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) (((rtm)->Timing.sampleTimeTaskIDPtr[sti] == (tid)))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val)                                       /* Do Nothing */
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm)             ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val)        ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti)      (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)
#define rtModel_KitGewerk2_v14         RT_MODEL_KitGewerk2_v14_T

/* Definition for use in the target main file */
#define KitGewerk2_v14_rtModel         RT_MODEL_KitGewerk2_v14_T

/* user code (top of export header file) */
#include "xpcdatatypes.h"

/* Block signals (auto storage) */
typedef struct {
  serialfifoptr RateTransition;        /* '<S47>/Rate Transition' */
  serialfifoptr RateTransition2;       /* '<S47>/Rate Transition2' */
  serialfifoptr RateTransition1;       /* '<S47>/Rate Transition1' */
  serialfifoptr RateTransition_g;      /* '<S34>/Rate Transition' */
  serialfifoptr RateTransition2_m;     /* '<S34>/Rate Transition2' */
  serialfifoptr RateTransition1_g;     /* '<S34>/Rate Transition1' */
  serialfifoptr FIFOwrite1_o1;         /* '<S34>/FIFO write 1' */
  serialfifoptr FIFOwrite2_o1;         /* '<S34>/FIFO write 2' */
  serialfifoptr RateTransition3;       /* '<S34>/Rate Transition3' */
  serialfifoptr FIFOwrite1_o1_o;       /* '<S47>/FIFO write 1' */
  serialfifoptr FIFOwrite2_o1_k;       /* '<S47>/FIFO write 2' */
  serialfifoptr RateTransition3_e;     /* '<S47>/Rate Transition3' */
  serialfifoptr FIFOwrite2;            /* '<S53>/FIFO write 2' */
  serialfifoptr FIFOwrite1;            /* '<S52>/FIFO write 1' */
  serialfifoptr FIFOwrite2_a;          /* '<S38>/FIFO write 2' */
  serialfifoptr FIFOwrite1_c;          /* '<S37>/FIFO write 1' */
  real_T uint16todouble[102];          /* '<S45>/uint16 to double' */
  real_T lasterrorfreeresponse[102];   /* '<S45>/last error free response' */
  real_T stopmarker[3];                /* '<S45>/stop marker' */
  real_T Receive_o2;                   /* '<S8>/Receive' */
  real_T Unpack[56];                   /* '<S8>/Unpack' */
  real_T DataTypeConversion3;          /* '<S24>/Data Type Conversion3' */
  real_T Step;                         /* '<S9>/Step' */
  real_T DataTypeConversion4;          /* '<S24>/Data Type Conversion4' */
  real_T DataTypeConversion3_j;        /* '<S26>/Data Type Conversion3' */
  real_T DataTypeConversion2;          /* '<S26>/Data Type Conversion2' */
  real_T Sum;                          /* '<S26>/Sum' */
  real_T Gain;                         /* '<S26>/Gain' */
  real_T DataTypeConversion1;          /* '<S26>/Data Type Conversion1' */
  real_T Auswahl6[9];                  /* '<S15>/Auswahl6' */
  real_T DataTypeConversion;           /* '<Root>/Data Type Conversion' */
  real_T Add;                          /* '<Root>/Add' */
  real_T Gain_b;                       /* '<Root>/Gain' */
  real_T RateTransitiondownsamplingto500;/* '<S10>/Rate Transition down-sampling to 500ms' */
  real_T Auswahl1;                     /* '<S15>/Auswahl1' */
  real_T Auswahl2;                     /* '<S15>/Auswahl2' */
  real_T Auswahl3;                     /* '<S15>/Auswahl3' */
  real_T Auswahl4;                     /* '<S15>/Auswahl4' */
  real_T Auswahl5;                     /* '<S15>/Auswahl5' */
  real_T Auswahl7;                     /* '<S15>/Auswahl7' */
  real_T DataTypeConversion1_i;        /* '<S5>/Data Type Conversion1' */
  real_T Auswahl1_h[3];                /* '<S16>/Auswahl1' */
  real_T Auswahl10[20];                /* '<S16>/Auswahl10' */
  real_T Auswahl2_e[3];                /* '<S16>/Auswahl2' */
  real_T Auswahl3_m[3];                /* '<S16>/Auswahl3' */
  real_T Auswahl4_i[3];                /* '<S16>/Auswahl4' */
  real_T Auswahl5_m;                   /* '<S16>/Auswahl5' */
  real_T Auswahl6_k;                   /* '<S16>/Auswahl6' */
  real_T Auswahl7_b;                   /* '<S16>/Auswahl7' */
  real_T Auswahl8;                     /* '<S16>/Auswahl8' */
  real_T Auswahl9[8];                  /* '<S16>/Auswahl9' */
  real_T WegpunktlistezumTesten[68];   /* '<S5>/Wegpunktliste zum Testen' */
  real_T Gain_o;                       /* '<S7>/Gain' */
  real_T constant3;                    /* '<Root>/constant3' */
  real_T constant4;                    /* '<Root>/constant4' */
  real_T constant5;                    /* '<Root>/constant5' */
  real_T Unpack_o;                     /* '<S57>/Unpack' */
  real_T enable_out[2];                /* '<S8>/stop signals' */
  real_T direction_motor0_out;         /* '<S7>/transmit velocity, unit & direction converter' */
  real_T velocity_motor0_out;          /* '<S7>/transmit velocity, unit & direction converter' */
  real_T direction_motor1_out;         /* '<S7>/transmit velocity, unit & direction converter' */
  real_T velocity_motor1_out;          /* '<S7>/transmit velocity, unit & direction converter' */
  real_T direction_motor2_out;         /* '<S7>/transmit velocity, unit & direction converter' */
  real_T velocity_motor2_out;          /* '<S7>/transmit velocity, unit & direction converter' */
  real_T stop_out;                     /* '<S45>/stop by bumper' */
  real_T stop_flag_out[3];             /* '<S45>/stop by bumper' */
  real_T TmpSignalConversionAtSFunctionI[2];/* '<S45>/protocol adder & optional velocity adaption' */
  real_T message[48];                  /* '<S45>/protocol adder & optional velocity adaption' */
  real_T direction_motor0_out_p;       /* '<S45>/error filter & protocol disassembler' */
  real_T velocity_motor0_out_d;        /* '<S45>/error filter & protocol disassembler' */
  real_T direction_motor1_out_d;       /* '<S45>/error filter & protocol disassembler' */
  real_T velocity_motor1_out_f;        /* '<S45>/error filter & protocol disassembler' */
  real_T direction_motor2_out_k;       /* '<S45>/error filter & protocol disassembler' */
  real_T velocity_motor2_out_n;        /* '<S45>/error filter & protocol disassembler' */
  real_T distance_measuring_sensors_out[9];/* '<S45>/error filter & protocol disassembler' */
  real_T di03_bump_out;                /* '<S45>/error filter & protocol disassembler' */
  real_T bumper_out[3];                /* '<S45>/error filter & protocol disassembler' */
  real_T error_free_resp_out[102];     /* '<S45>/error filter & protocol disassembler' */
  real_T v_x_out;                      /* '<S7>/receive direction, unit & velocity converter' */
  real_T v_y_out;                      /* '<S7>/receive direction, unit & velocity converter' */
  real_T v_theta_out;                  /* '<S7>/receive direction, unit & velocity converter' */
  real_T light_barrier;                /* '<S7>/light barrier & slider' */
  real_T slider;                       /* '<S7>/light barrier & slider' */
  real_T dms_out[9];                   /* '<S7>/distance converter' */
  real_T robotino_response[15];        /* '<S7>/assemble robotino response' */
  real_T Output_SOC;                   /* '<S6>/SOC-Comparison: Blei oder Li-ION' */
  real_T Laden;                        /* '<S26>/Unterscheidung Blei Gel Roboter an der virtuellen Ladestation' */
  real_T SOC;                          /* '<S26>/Relais ansteuern1' */
  real_T y;                            /* '<S26>/MATLAB Function1' */
  real_T y_k;                          /* '<S26>/MATLAB Function' */
  real_T Output_Flag;                  /* '<S26>/Flag Communication Simulation' */
  real_T Output_Flag_d;                /* '<S6>/Output_Flag-Comparison: Blei oder Li-ION' */
  real_T d_Y_soll;                     /* '<S5>/MATLAB Function' */
  real_T d_X_soll;                     /* '<S5>/MATLAB Function' */
  real_T d_Phi_soll;                   /* '<S5>/MATLAB Function' */
  real_T d_V_Max_soll;                 /* '<S5>/MATLAB Function' */
  real_T A_WPL[200];                   /* '<S5>/Chart' */
  real_T A_stern_test[200];            /* '<S5>/Chart' */
  real_T Constant1[2];                 /* '<S20>/Constant1' */
  real_T Constant2[2];                 /* '<S20>/Constant2' */
  real_T Constant3[6];                 /* '<S20>/Constant3' */
  real_T Wegpunkte[200];               /* '<S21>/S-Function' */
  real_T SFunction_o2[200];            /* '<S21>/S-Function' */
  real_T Receivefromall_o2;            /* '<S11>/Receive from all' */
  real_T Receivefromall_o2_a;          /* '<S12>/Receive from all' */
  real_T Receivefromall_o2_m;          /* '<S13>/Receive from all' */
  real_T Receivefromall_o2_ae;         /* '<S14>/Receive from all' */
  real_T wout;                         /* '<Root>/Begrenzung2' */
  real_T wout_p;                       /* '<Root>/Begrenzung1' */
  real_T wout_m;                       /* '<Root>/Begrenzung' */
  int32_T Counter_o1;                  /* '<S5>/Counter' */
  uint32_T Memory1;                    /* '<S26>/Memory1' */
  uint32_T DischargingCounter;         /* '<S26>/Discharging Counter' */
  uint32_T ReadIntStatusFC1_o2;        /* '<S51>/Read Int Status FC1' */
  uint32_T Constant2_h;                /* '<S55>/Constant2' */
  uint32_T FIFOread2_o1[61];           /* '<S55>/FIFO read 2' */
  uint32_T FIFOread2_o2;               /* '<S55>/FIFO read 2' */
  uint32_T ReadHWFIFO2[65];            /* '<S53>/Read HW FIFO2' */
  uint32_T Constant1_d;                /* '<S54>/Constant1' */
  uint32_T FIFOread1_o1[61];           /* '<S54>/FIFO read 1' */
  uint32_T FIFOread1_o2;               /* '<S54>/FIFO read 1' */
  uint32_T ReadHWFIFO1[65];            /* '<S52>/Read HW FIFO1' */
  uint32_T ReadIntStatusFC1_o2_c;      /* '<S36>/Read Int Status FC1' */
  uint32_T Constant2_k;                /* '<S40>/Constant2' */
  uint32_T FIFOread2_o1_a[61];         /* '<S40>/FIFO read 2' */
  uint32_T FIFOread2_o2_k;             /* '<S40>/FIFO read 2' */
  uint32_T ReadHWFIFO2_o[65];          /* '<S38>/Read HW FIFO2' */
  uint32_T Constant1_o;                /* '<S39>/Constant1' */
  uint32_T FIFOread1_o1_a[61];         /* '<S39>/FIFO read 1' */
  uint32_T FIFOread1_o2_i;             /* '<S39>/FIFO read 1' */
  uint32_T ReadHWFIFO1_c[65];          /* '<S37>/Read HW FIFO1' */
  uint32_T Gain1;                      /* '<S26>/Gain1' */
  uint16_T FIFOread1[102];             /* '<S47>/FIFO read 1' */
  uint16_T FIFOread1_j[4];             /* '<S34>/FIFO read 1' */
  uint16_T Memory;                     /* '<S26>/Memory' */
  uint16_T ChargingCounter;            /* '<S26>/Charging Counter' */
  uint16_T doubletouint16[48];         /* '<S45>/double to uint16' */
  uint16_T FIFOread2[102];             /* '<S47>/FIFO read 2' */
  uint8_T Receive_o1[448];             /* '<S8>/Receive' */
  uint8_T RateTransitionupsamplingtofunda[5];/* '<S10>/Rate Transition up-sampling to fundamental sample time' */
  uint8_T Unpack_o1;                   /* '<S4>/Unpack' */
  uint8_T Unpack_o2;                   /* '<S4>/Unpack' */
  uint8_T Unpack_o3;                   /* '<S4>/Unpack' */
  uint8_T Unpack_o4;                   /* '<S4>/Unpack' */
  uint8_T Unpack_o5;                   /* '<S4>/Unpack' */
  uint8_T DataTypeConversion2_b;       /* '<S4>/Data Type Conversion2' */
  uint8_T DataTypeConversion4_d;       /* '<S4>/Data Type Conversion4' */
  uint8_T DataTypeConversion1_f;       /* '<S4>/Data Type Conversion1' */
  uint8_T Constant4;                   /* '<S5>/Constant4' */
  uint8_T DataTypeConversion3_k;       /* '<S4>/Data Type Conversion3' */
  uint8_T DataTypeConversion2_d[4];    /* '<S24>/Data Type Conversion2' */
  uint8_T PreviousFlag;                /* '<S24>/Previous Flag' */
  uint8_T DataTypeConversion_c;        /* '<S24>/Data Type Conversion' */
  uint8_T PreviousSOC;                 /* '<S24>/Previous SOC' */
  uint8_T DataTypeConversion1_fj;      /* '<S24>/Data Type Conversion1' */
  uint8_T Compare;                     /* '<S27>/Compare' */
  uint8_T DataTypeConversion5;         /* '<S4>/Data Type Conversion5' */
  uint8_T DataTypeConversion7;         /* '<S4>/Data Type Conversion7' */
  uint8_T DataTypeConversion1_o;       /* '<Root>/Data Type Conversion1' */
  uint8_T DataTypeConversion8;         /* '<S4>/Data Type Conversion8' */
  uint8_T DataTypeConversion9;         /* '<S4>/Data Type Conversion9' */
  uint8_T Pack[4];                     /* '<S4>/Pack' */
  uint8_T RateTransitiondownsamplingto5_o[4];/* '<S10>/Rate Transition down-sampling to 500 ms' */
  uint8_T MultiportSwitch[5];          /* '<S10>/Multiport Switch' */
  uint8_T DataTypeConversion5_i;       /* '<S24>/Data Type Conversion5' */
  uint8_T FIFOread2_c[102];            /* '<S34>/FIFO read 2' */
  uint8_T FromFile[8];                 /* '<S57>/From File' */
  uint8_T SOC_a;                       /* '<S24>/Microcontroller Data' */
  uint8_T FLAG;                        /* '<S24>/Microcontroller Data' */
  uint8_T UI_to_GW1;                   /* '<S5>/Chart' */
  uint8_T Receivefromall_o1[5];        /* '<S11>/Receive from all' */
  uint8_T Receivefromall_o1_p[5];      /* '<S12>/Receive from all' */
  uint8_T Receivefromall_o1_j[5];      /* '<S13>/Receive from all' */
  uint8_T Receivefromall_o1_g[5];      /* '<S14>/Receive from all' */
  boolean_T Constant7;                 /* '<S5>/Constant7' */
  boolean_T Constant5;                 /* '<S5>/Constant5' */
  boolean_T Constant;                  /* '<S5>/Constant' */
  boolean_T Constant2_f;               /* '<S5>/Constant2' */
  boolean_T Compare_o;                 /* '<S28>/Compare' */
  boolean_T DataTypeConversion_l;      /* '<S5>/Data Type Conversion' */
  boolean_T RelationalOperator;        /* '<S5>/Relational Operator' */
  boolean_T DataTypeConversion6;       /* '<S4>/Data Type Conversion6' */
  boolean_T Counter_o2;                /* '<S5>/Counter' */
  boolean_T FIFOwrite1_o2;             /* '<S34>/FIFO write 1' */
  boolean_T FIFOwrite2_o2;             /* '<S34>/FIFO write 2' */
  boolean_T FIFOwrite1_o2_n;           /* '<S47>/FIFO write 1' */
  boolean_T FIFOwrite2_o2_j;           /* '<S47>/FIFO write 2' */
  boolean_T b_stop;                    /* '<S5>/Kollisionserkennung' */
  boolean_T B_Stop;                    /* '<S5>/Chart' */
  boolean_T B_WP_weiter;               /* '<S5>/Chart' */
  boolean_T B_Greifer;                 /* '<S5>/Chart' */
  boolean_T B_WPL_cnt_reset;           /* '<S5>/Chart' */
} B_KitGewerk2_v14_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T lasterrorfreeresponse_PreviousI[102];/* '<S45>/last error free response' */
  real_T stopmarker_PreviousInput[3];  /* '<S45>/stop marker' */
  real_T Sum_DWORK1;                   /* '<S26>/Sum' */
  void *Receive_PWORK;                 /* '<S8>/Receive' */
  void *FIFOwrite1_PWORK;              /* '<S34>/FIFO write 1' */
  void *FIFOwrite2_PWORK;              /* '<S34>/FIFO write 2' */
  void *FIFOwrite1_PWORK_i;            /* '<S47>/FIFO write 1' */
  void *FIFOwrite2_PWORK_a;            /* '<S47>/FIFO write 2' */
  void *FIFOwrite2_PWORK_i;            /* '<S53>/FIFO write 2' */
  void *FIFOwrite1_PWORK_h;            /* '<S52>/FIFO write 1' */
  void *FIFOwrite2_PWORK_e;            /* '<S38>/FIFO write 2' */
  void *FIFOwrite1_PWORK_o;            /* '<S37>/FIFO write 1' */
  void *SFunction_PWORK;               /* '<S21>/S-Function' */
  void *Receivefromall_PWORK;          /* '<S11>/Receive from all' */
  void *Sendtoall_PWORK;               /* '<S11>/Send to all' */
  void *Receivefromall_PWORK_g;        /* '<S12>/Receive from all' */
  void *Sendtoall_PWORK_j;             /* '<S12>/Send to all' */
  void *Receivefromall_PWORK_j;        /* '<S13>/Receive from all' */
  void *Sendtoall_PWORK_f;             /* '<S13>/Send to all' */
  void *Receivefromall_PWORK_m;        /* '<S14>/Receive from all' */
  void *Sendtoall_PWORK_b;             /* '<S14>/Send to all' */
  int32_T sfEvent;                     /* '<S5>/Chart' */
  uint32_T Memory1_PreviousInput;      /* '<S26>/Memory1' */
  uint32_T DischargingCounter_Count;   /* '<S26>/Discharging Counter' */
  uint32_T Counter_ClkEphState;        /* '<S5>/Counter' */
  int_T Receive_IWORK[2];              /* '<S8>/Receive' */
  int_T FIFOwrite1_IWORK[3];           /* '<S34>/FIFO write 1' */
  int_T EnableTX1_IWORK;               /* '<S34>/Enable TX 1' */
  int_T FIFOwrite2_IWORK[3];           /* '<S34>/FIFO write 2' */
  int_T EnableTX2_IWORK;               /* '<S34>/Enable TX 2' */
  int_T Setup1_IWORK[3];               /* '<S34>/Setup1' */
  int_T Setup2_IWORK[3];               /* '<S34>/Setup2' */
  int_T FIFOwrite1_IWORK_f[3];         /* '<S47>/FIFO write 1' */
  int_T EnableTX1_IWORK_l;             /* '<S47>/Enable TX 1' */
  int_T FIFOwrite2_IWORK_j[3];         /* '<S47>/FIFO write 2' */
  int_T EnableTX2_IWORK_p;             /* '<S47>/Enable TX 2' */
  int_T Setup1_IWORK_l[3];             /* '<S47>/Setup1' */
  int_T Setup2_IWORK_m[3];             /* '<S47>/Setup2' */
  int_T FromFile_IWORK[2];             /* '<S57>/From File' */
  int_T WriteHWFIFO2_IWORK;            /* '<S55>/Write HW FIFO2' */
  int_T ReadHWFIFO2_IWORK;             /* '<S53>/Read HW FIFO2' */
  int_T FIFOwrite2_IWORK_m[3];         /* '<S53>/FIFO write 2' */
  int_T WriteHWFIFO1_IWORK;            /* '<S54>/Write HW FIFO1' */
  int_T ReadHWFIFO1_IWORK;             /* '<S52>/Read HW FIFO1' */
  int_T FIFOwrite1_IWORK_o[3];         /* '<S52>/FIFO write 1' */
  int_T WriteHWFIFO2_IWORK_i;          /* '<S40>/Write HW FIFO2' */
  int_T ReadHWFIFO2_IWORK_h;           /* '<S38>/Read HW FIFO2' */
  int_T FIFOwrite2_IWORK_h[3];         /* '<S38>/FIFO write 2' */
  int_T WriteHWFIFO1_IWORK_b;          /* '<S39>/Write HW FIFO1' */
  int_T ReadHWFIFO1_IWORK_i;           /* '<S37>/Read HW FIFO1' */
  int_T FIFOwrite1_IWORK_e[3];         /* '<S37>/FIFO write 1' */
  int_T Receivefromall_IWORK[2];       /* '<S11>/Receive from all' */
  int_T Sendtoall_IWORK[2];            /* '<S11>/Send to all' */
  int_T Receivefromall_IWORK_i[2];     /* '<S12>/Receive from all' */
  int_T Sendtoall_IWORK_m[2];          /* '<S12>/Send to all' */
  int_T Receivefromall_IWORK_e[2];     /* '<S13>/Receive from all' */
  int_T Sendtoall_IWORK_j[2];          /* '<S13>/Send to all' */
  int_T Receivefromall_IWORK_h[2];     /* '<S14>/Receive from all' */
  int_T Sendtoall_IWORK_o[2];          /* '<S14>/Send to all' */
  uint16_T Memory_PreviousInput;       /* '<S26>/Memory' */
  uint16_T ChargingCounter_Count;      /* '<S26>/Charging Counter' */
  int8_T RS232ISR_SubsysRanBC;         /* '<S47>/RS232 ISR' */
  int8_T RS232ISR_SubsysRanBC_d;       /* '<S34>/RS232 ISR' */
  int8_T getIDfromFlash_SubsysRanBC;   /* '<S9>/getIDfromFlash' */
  int8_T IfRobotino4_SubsysRanBC;      /* '<S10>/If Robotino 4' */
  int8_T IfRobotino3_SubsysRanBC;      /* '<S10>/If Robotino 3' */
  int8_T IfRobotino2_SubsysRanBC;      /* '<S10>/If Robotino 2' */
  int8_T IfRobotino1_SubsysRanBC;      /* '<S10>/If Robotino 1' */
  int8_T Receive1_SubsysRanBC;         /* '<S51>/Receive 1' */
  int8_T Transmit1_SubsysRanBC;        /* '<S51>/Transmit 1' */
  int8_T Receive2_SubsysRanBC;         /* '<S51>/Receive 2' */
  int8_T Transmit2_SubsysRanBC;        /* '<S51>/Transmit 2' */
  int8_T Receive1_SubsysRanBC_o;       /* '<S36>/Receive 1' */
  int8_T Transmit1_SubsysRanBC_k;      /* '<S36>/Transmit 1' */
  int8_T Receive2_SubsysRanBC_n;       /* '<S36>/Receive 2' */
  int8_T Transmit2_SubsysRanBC_l;      /* '<S36>/Transmit 2' */
  int8_T Fahrt_zum_Warteplatzsimfcn_Subs;/* '<S17>/Fahrt_zum_Warteplatz.simfcn' */
  uint8_T RateTransitionupsamplingtofunda[5];/* '<S10>/Rate Transition up-sampling to fundamental sample time' */
  uint8_T PreviousFlag_PreviousInput;  /* '<S24>/Previous Flag' */
  uint8_T PreviousSOC_PreviousInput;   /* '<S24>/Previous SOC' */
  uint8_T Counter_Count;               /* '<S5>/Counter' */
  uint8_T is_active_c15_KitGewerk2_v14;/* '<S5>/Chart' */
  uint8_T is_c15_KitGewerk2_v14;       /* '<S5>/Chart' */
  uint8_T is_Routinen_Stationen;       /* '<S5>/Chart' */
  uint8_T is_Werkstueck_aufnehmen;     /* '<S5>/Chart' */
  uint8_T is_Werkstueck_ablegen;       /* '<S5>/Chart' */
  uint8_T is_A_stern_fahrt;            /* '<S5>/Chart' */
  uint8_T is_Routinen_Ladestationen;   /* '<S5>/Chart' */
  uint8_T UI_Auftrnr;                  /* '<S5>/Chart' */
  uint8_T UI_Startstation;             /* '<S5>/Chart' */
  uint8_T UI_Endstation;               /* '<S5>/Chart' */
  uint8_T temporalCounter_i1;          /* '<S5>/Chart' */
  boolean_T isStable;                  /* '<S5>/Chart' */
  boolean_T B_Endst;                   /* '<S5>/Chart' */
} DW_KitGewerk2_v14_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState getIDfromFlash_Trig_ZCE;  /* '<S9>/getIDfromFlash' */
} PrevZCX_KitGewerk2_v14_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T Robotinorawdata[102];         /* '<Root>/Robotino raw data' */
  real_T Robotinoprocesseddata[15];    /* '<Root>/Robotino processed data' */
  real_T UDPdata[56];                  /* '<Root>/UDP data' */
} ExtY_KitGewerk2_v14_T;

/* Backward compatible GRT Identifiers */
#define rtB                            KitGewerk2_v14_B
#define BlockIO                        B_KitGewerk2_v14_T
#define rtY                            KitGewerk2_v14_Y
#define ExternalOutputs                ExtY_KitGewerk2_v14_T
#define rtP                            KitGewerk2_v14_P
#define Parameters                     P_KitGewerk2_v14_T
#define rtDWork                        KitGewerk2_v14_DW
#define D_Work                         DW_KitGewerk2_v14_T
#define rtPrevZCSigState               KitGewerk2_v14_PrevZCX
#define PrevZCSigStates                PrevZCX_KitGewerk2_v14_T

/* Parameters (auto storage) */
struct P_KitGewerk2_v14_T_ {
  uint32_T DischargingCounter_InitialCount;/* Mask Parameter: DischargingCounter_InitialCount
                                            * Referenced by: '<S26>/Discharging Counter'
                                            */
  uint16_T ChargingCounter_InitialCount;/* Mask Parameter: ChargingCounter_InitialCount
                                         * Referenced by: '<S26>/Charging Counter'
                                         */
  uint8_T Counter_HitValue;            /* Mask Parameter: Counter_HitValue
                                        * Referenced by: '<S5>/Counter'
                                        */
  uint8_T Counter_InitialCount;        /* Mask Parameter: Counter_InitialCount
                                        * Referenced by: '<S5>/Counter'
                                        */
  real_T Receivefromall_P1_Size[2];    /* Computed Parameter: Receivefromall_P1_Size
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P1[7];         /* Computed Parameter: Receivefromall_P1
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P2_Size[2];    /* Computed Parameter: Receivefromall_P2_Size
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P2;            /* Expression: ipPort
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P3_Size[2];    /* Computed Parameter: Receivefromall_P3_Size
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P3;            /* Expression: width
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P4_Size[2];    /* Computed Parameter: Receivefromall_P4_Size
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P4;            /* Expression: sampletime
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P5_Size[2];    /* Computed Parameter: Receivefromall_P5_Size
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Receivefromall_P5;            /* Expression: vblLen
                                        * Referenced by: '<S14>/Receive from all'
                                        */
  real_T Sendtoall_P1_Size[2];         /* Computed Parameter: Sendtoall_P1_Size
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P1[15];             /* Computed Parameter: Sendtoall_P1
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P2_Size[2];         /* Computed Parameter: Sendtoall_P2_Size
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P2;                 /* Expression: ipPort
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P3_Size[2];         /* Computed Parameter: Sendtoall_P3_Size
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P3;                 /* Expression: localPort
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P4_Size[2];         /* Computed Parameter: Sendtoall_P4_Size
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P4;                 /* Expression: sampletime
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P5_Size[2];         /* Computed Parameter: Sendtoall_P5_Size
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Sendtoall_P5;                 /* Expression: vblLen
                                        * Referenced by: '<S14>/Send to all'
                                        */
  real_T Receivefromall_P1_Size_i[2];  /* Computed Parameter: Receivefromall_P1_Size_i
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P1_p[7];       /* Computed Parameter: Receivefromall_P1_p
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P2_Size_f[2];  /* Computed Parameter: Receivefromall_P2_Size_f
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P2_i;          /* Expression: ipPort
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P3_Size_g[2];  /* Computed Parameter: Receivefromall_P3_Size_g
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P3_b;          /* Expression: width
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P4_Size_m[2];  /* Computed Parameter: Receivefromall_P4_Size_m
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P4_c;          /* Expression: sampletime
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P5_Size_l[2];  /* Computed Parameter: Receivefromall_P5_Size_l
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Receivefromall_P5_m;          /* Expression: vblLen
                                        * Referenced by: '<S13>/Receive from all'
                                        */
  real_T Sendtoall_P1_Size_j[2];       /* Computed Parameter: Sendtoall_P1_Size_j
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P1_k[15];           /* Computed Parameter: Sendtoall_P1_k
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P2_Size_i[2];       /* Computed Parameter: Sendtoall_P2_Size_i
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P2_d;               /* Expression: ipPort
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P3_Size_m[2];       /* Computed Parameter: Sendtoall_P3_Size_m
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P3_k;               /* Expression: localPort
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P4_Size_p[2];       /* Computed Parameter: Sendtoall_P4_Size_p
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P4_b;               /* Expression: sampletime
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P5_Size_p[2];       /* Computed Parameter: Sendtoall_P5_Size_p
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Sendtoall_P5_k;               /* Expression: vblLen
                                        * Referenced by: '<S13>/Send to all'
                                        */
  real_T Receivefromall_P1_Size_g[2];  /* Computed Parameter: Receivefromall_P1_Size_g
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P1_h[7];       /* Computed Parameter: Receivefromall_P1_h
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P2_Size_c[2];  /* Computed Parameter: Receivefromall_P2_Size_c
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P2_ih;         /* Expression: ipPort
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P3_Size_gk[2]; /* Computed Parameter: Receivefromall_P3_Size_gk
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P3_e;          /* Expression: width
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P4_Size_c[2];  /* Computed Parameter: Receivefromall_P4_Size_c
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P4_n;          /* Expression: sampletime
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P5_Size_g[2];  /* Computed Parameter: Receivefromall_P5_Size_g
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Receivefromall_P5_mx;         /* Expression: vblLen
                                        * Referenced by: '<S12>/Receive from all'
                                        */
  real_T Sendtoall_P1_Size_c[2];       /* Computed Parameter: Sendtoall_P1_Size_c
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P1_e[15];           /* Computed Parameter: Sendtoall_P1_e
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P2_Size_l[2];       /* Computed Parameter: Sendtoall_P2_Size_l
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P2_o;               /* Expression: ipPort
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P3_Size_n[2];       /* Computed Parameter: Sendtoall_P3_Size_n
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P3_m;               /* Expression: localPort
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P4_Size_o[2];       /* Computed Parameter: Sendtoall_P4_Size_o
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P4_n;               /* Expression: sampletime
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P5_Size_n[2];       /* Computed Parameter: Sendtoall_P5_Size_n
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Sendtoall_P5_a;               /* Expression: vblLen
                                        * Referenced by: '<S12>/Send to all'
                                        */
  real_T Receivefromall_P1_Size_b[2];  /* Computed Parameter: Receivefromall_P1_Size_b
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P1_i[7];       /* Computed Parameter: Receivefromall_P1_i
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P2_Size_o[2];  /* Computed Parameter: Receivefromall_P2_Size_o
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P2_g;          /* Expression: ipPort
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P3_Size_b[2];  /* Computed Parameter: Receivefromall_P3_Size_b
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P3_o;          /* Expression: width
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P4_Size_e[2];  /* Computed Parameter: Receivefromall_P4_Size_e
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P4_nt;         /* Expression: sampletime
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P5_Size_gi[2]; /* Computed Parameter: Receivefromall_P5_Size_gi
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Receivefromall_P5_a;          /* Expression: vblLen
                                        * Referenced by: '<S11>/Receive from all'
                                        */
  real_T Sendtoall_P1_Size_e[2];       /* Computed Parameter: Sendtoall_P1_Size_e
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P1_d[15];           /* Computed Parameter: Sendtoall_P1_d
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P2_Size_f[2];       /* Computed Parameter: Sendtoall_P2_Size_f
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P2_n;               /* Expression: ipPort
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P3_Size_h[2];       /* Computed Parameter: Sendtoall_P3_Size_h
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P3_e;               /* Expression: localPort
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P4_Size_e[2];       /* Computed Parameter: Sendtoall_P4_Size_e
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P4_h;               /* Expression: sampletime
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P5_Size_l[2];       /* Computed Parameter: Sendtoall_P5_Size_l
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Sendtoall_P5_l;               /* Expression: vblLen
                                        * Referenced by: '<S11>/Send to all'
                                        */
  real_T Constant1_Value[2];           /* Expression: [3 1]
                                        * Referenced by: '<S20>/Constant1'
                                        */
  real_T Constant2_Value[2];           /* Expression: [1 1]
                                        * Referenced by: '<S20>/Constant2'
                                        */
  real_T Constant3_Value[6];           /* Expression: [1 2 1 3 1 4]
                                        * Referenced by: '<S20>/Constant3'
                                        */
  real_T FIFOwrite1_P1_Size[2];        /* Computed Parameter: FIFOwrite1_P1_Size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P1;                /* Expression: size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_Size[2];        /* Computed Parameter: FIFOwrite1_P2_Size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2;                /* Expression: inputtype
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_Size[2];        /* Computed Parameter: FIFOwrite1_P3_Size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3;                /* Expression: sampletime
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_Size[2];        /* Computed Parameter: FIFOwrite1_P4_Size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4;                /* Expression: present
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_Size[2];        /* Computed Parameter: FIFOwrite1_P5_Size
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5[20];            /* Computed Parameter: FIFOwrite1_P5
                                        * Referenced by: '<S37>/FIFO write 1'
                                        */
  real_T FIFOread1_P1_Size[2];         /* Computed Parameter: FIFOread1_P1_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P1;                 /* Expression: maxsize
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_Size[2];         /* Computed Parameter: FIFOread1_P2_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P2;                 /* Expression: minsize
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_Size[2];         /* Computed Parameter: FIFOread1_P3_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P3;                 /* Expression: usedelimiter
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_Size[2];         /* Computed Parameter: FIFOread1_P4_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P4;                 /* Expression: delimiter
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_Size[2];         /* Computed Parameter: FIFOread1_P5_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P5;                 /* Expression: outputtype
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_Size[2];         /* Computed Parameter: FIFOread1_P6_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P6;                 /* Expression: sampletime
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_Size[2];         /* Computed Parameter: FIFOread1_P7_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P7;                 /* Expression: enable
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_Size[2];         /* Computed Parameter: FIFOread1_P8_Size
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOread1_P8;                 /* Expression: enableout
                                        * Referenced by: '<S39>/FIFO read 1'
                                        */
  real_T FIFOwrite2_P1_Size[2];        /* Computed Parameter: FIFOwrite2_P1_Size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P1;                /* Expression: size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_Size[2];        /* Computed Parameter: FIFOwrite2_P2_Size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2;                /* Expression: inputtype
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_Size[2];        /* Computed Parameter: FIFOwrite2_P3_Size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3;                /* Expression: sampletime
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_Size[2];        /* Computed Parameter: FIFOwrite2_P4_Size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4;                /* Expression: present
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_Size[2];        /* Computed Parameter: FIFOwrite2_P5_Size
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5[20];            /* Computed Parameter: FIFOwrite2_P5
                                        * Referenced by: '<S38>/FIFO write 2'
                                        */
  real_T FIFOread2_P1_Size[2];         /* Computed Parameter: FIFOread2_P1_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P1;                 /* Expression: maxsize
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_Size[2];         /* Computed Parameter: FIFOread2_P2_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P2;                 /* Expression: minsize
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_Size[2];         /* Computed Parameter: FIFOread2_P3_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P3;                 /* Expression: usedelimiter
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_Size[2];         /* Computed Parameter: FIFOread2_P4_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P4;                 /* Expression: delimiter
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_Size[2];         /* Computed Parameter: FIFOread2_P5_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P5;                 /* Expression: outputtype
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_Size[2];         /* Computed Parameter: FIFOread2_P6_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P6;                 /* Expression: sampletime
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_Size[2];         /* Computed Parameter: FIFOread2_P7_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P7;                 /* Expression: enable
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_Size[2];         /* Computed Parameter: FIFOread2_P8_Size
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOread2_P8;                 /* Expression: enableout
                                        * Referenced by: '<S40>/FIFO read 2'
                                        */
  real_T FIFOwrite1_P1_Size_f[2];      /* Computed Parameter: FIFOwrite1_P1_Size_f
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P1_p;              /* Expression: size
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_Size_i[2];      /* Computed Parameter: FIFOwrite1_P2_Size_i
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_k;              /* Expression: inputtype
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_Size_m[2];      /* Computed Parameter: FIFOwrite1_P3_Size_m
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_g;              /* Expression: sampletime
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_Size_l[2];      /* Computed Parameter: FIFOwrite1_P4_Size_l
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_f;              /* Expression: present
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_Size_b[2];      /* Computed Parameter: FIFOwrite1_P5_Size_b
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_p[20];          /* Computed Parameter: FIFOwrite1_P5_p
                                        * Referenced by: '<S52>/FIFO write 1'
                                        */
  real_T FIFOread1_P1_Size_k[2];       /* Computed Parameter: FIFOread1_P1_Size_k
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P1_g;               /* Expression: maxsize
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_Size_f[2];       /* Computed Parameter: FIFOread1_P2_Size_f
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_o;               /* Expression: minsize
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_Size_k[2];       /* Computed Parameter: FIFOread1_P3_Size_k
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_j;               /* Expression: usedelimiter
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_Size_o[2];       /* Computed Parameter: FIFOread1_P4_Size_o
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_h;               /* Expression: delimiter
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_Size_d[2];       /* Computed Parameter: FIFOread1_P5_Size_d
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_o;               /* Expression: outputtype
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_Size_f[2];       /* Computed Parameter: FIFOread1_P6_Size_f
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_l;               /* Expression: sampletime
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_Size_b[2];       /* Computed Parameter: FIFOread1_P7_Size_b
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_c;               /* Expression: enable
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_Size_k[2];       /* Computed Parameter: FIFOread1_P8_Size_k
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_g;               /* Expression: enableout
                                        * Referenced by: '<S54>/FIFO read 1'
                                        */
  real_T FIFOwrite2_P1_Size_d[2];      /* Computed Parameter: FIFOwrite2_P1_Size_d
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P1_o;              /* Expression: size
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_Size_a[2];      /* Computed Parameter: FIFOwrite2_P2_Size_a
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_l;              /* Expression: inputtype
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_Size_e[2];      /* Computed Parameter: FIFOwrite2_P3_Size_e
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_d;              /* Expression: sampletime
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_Size_p[2];      /* Computed Parameter: FIFOwrite2_P4_Size_p
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_d;              /* Expression: present
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_Size_f[2];      /* Computed Parameter: FIFOwrite2_P5_Size_f
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_k[20];          /* Computed Parameter: FIFOwrite2_P5_k
                                        * Referenced by: '<S53>/FIFO write 2'
                                        */
  real_T FIFOread2_P1_Size_j[2];       /* Computed Parameter: FIFOread2_P1_Size_j
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P1_g;               /* Expression: maxsize
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_Size_n[2];       /* Computed Parameter: FIFOread2_P2_Size_n
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_d;               /* Expression: minsize
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_Size_h[2];       /* Computed Parameter: FIFOread2_P3_Size_h
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_j;               /* Expression: usedelimiter
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_Size_d[2];       /* Computed Parameter: FIFOread2_P4_Size_d
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_g;               /* Expression: delimiter
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_Size_i[2];       /* Computed Parameter: FIFOread2_P5_Size_i
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_d;               /* Expression: outputtype
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_Size_h[2];       /* Computed Parameter: FIFOread2_P6_Size_h
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_g;               /* Expression: sampletime
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_Size_b[2];       /* Computed Parameter: FIFOread2_P7_Size_b
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_f;               /* Expression: enable
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_Size_j[2];       /* Computed Parameter: FIFOread2_P8_Size_j
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_e;               /* Expression: enableout
                                        * Referenced by: '<S55>/FIFO read 2'
                                        */
  real_T FromFile_P1_Size[2];          /* Computed Parameter: FromFile_P1_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P1[11];              /* Computed Parameter: FromFile_P1
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P2_Size[2];          /* Computed Parameter: FromFile_P2_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P2;                  /* Expression: dataSize
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P3_Size[2];          /* Computed Parameter: FromFile_P3_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P3;                  /* Expression: bufSize
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P4_Size[2];          /* Computed Parameter: FromFile_P4_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P4;                  /* Expression: readSize
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P5_Size[2];          /* Computed Parameter: FromFile_P5_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P5;                  /* Expression: EOFOption
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P6_Size[2];          /* Computed Parameter: FromFile_P6_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P6;                  /* Expression: sampTime
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P7_Size[2];          /* Computed Parameter: FromFile_P7_Size
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FromFile_P7;                  /* Expression: show2ports
                                        * Referenced by: '<S57>/From File'
                                        */
  real_T FIFOread1_P1_Size_d[2];       /* Computed Parameter: FIFOread1_P1_Size_d
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P1_o;               /* Expression: maxsize
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_Size_k[2];       /* Computed Parameter: FIFOread1_P2_Size_k
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_f;               /* Expression: minsize
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_Size_i[2];       /* Computed Parameter: FIFOread1_P3_Size_i
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_h;               /* Expression: usedelimiter
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_Size_b[2];       /* Computed Parameter: FIFOread1_P4_Size_b
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_b;               /* Expression: delimiter
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_Size_o[2];       /* Computed Parameter: FIFOread1_P5_Size_o
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_k;               /* Expression: outputtype
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_Size_e[2];       /* Computed Parameter: FIFOread1_P6_Size_e
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_c;               /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_Size_g[2];       /* Computed Parameter: FIFOread1_P7_Size_g
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_a;               /* Expression: enable
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_Size_o[2];       /* Computed Parameter: FIFOread1_P8_Size_o
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_c;               /* Expression: enableout
                                        * Referenced by: '<S47>/FIFO read 1'
                                        */
  real_T lasterrorfreeresponse_X0[102];/* Expression: [zeros(1,102)]
                                        * Referenced by: '<S45>/last error free response'
                                        */
  real_T stopmarker_X0[3];             /* Expression: [zeros(1,3)]
                                        * Referenced by: '<S45>/stop marker'
                                        */
  real_T Receive_P1_Size[2];           /* Computed Parameter: Receive_P1_Size
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P1[7];                /* Computed Parameter: Receive_P1
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P2_Size[2];           /* Computed Parameter: Receive_P2_Size
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P2;                   /* Expression: ipPort
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P3_Size[2];           /* Computed Parameter: Receive_P3_Size
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P3;                   /* Expression: width
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P4_Size[2];           /* Computed Parameter: Receive_P4_Size
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P4;                   /* Expression: sampletime
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P5_Size[2];           /* Computed Parameter: Receive_P5_Size
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T Receive_P5;                   /* Expression: vblLen
                                        * Referenced by: '<S8>/Receive'
                                        */
  real_T FIFOread1_P1_Size_h[2];       /* Computed Parameter: FIFOread1_P1_Size_h
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P1_l;               /* Expression: maxsize
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_Size_o[2];       /* Computed Parameter: FIFOread1_P2_Size_o
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P2_l;               /* Expression: minsize
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_Size_a[2];       /* Computed Parameter: FIFOread1_P3_Size_a
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P3_k;               /* Expression: usedelimiter
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_Size_f[2];       /* Computed Parameter: FIFOread1_P4_Size_f
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P4_p;               /* Expression: delimiter
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_Size_e[2];       /* Computed Parameter: FIFOread1_P5_Size_e
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P5_p;               /* Expression: outputtype
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_Size_l[2];       /* Computed Parameter: FIFOread1_P6_Size_l
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P6_cp;              /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_Size_c[2];       /* Computed Parameter: FIFOread1_P7_Size_c
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P7_l;               /* Expression: enable
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_Size_f[2];       /* Computed Parameter: FIFOread1_P8_Size_f
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T FIFOread1_P8_g3;              /* Expression: enableout
                                        * Referenced by: '<S34>/FIFO read 1'
                                        */
  real_T Step_Time;                    /* Expression: 0.01
                                        * Referenced by: '<S9>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<S9>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 1
                                        * Referenced by: '<S9>/Step'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S28>/Constant'
                                        */
  real_T Constant_Value_b;             /* Expression: 0
                                        * Referenced by: '<S27>/Constant'
                                        */
  real_T Constant2_Value_g;            /* Expression: -2
                                        * Referenced by: '<S26>/Constant2'
                                        */
  real_T Gain_Gain;                    /* Expression: 1/1800
                                        * Referenced by: '<S26>/Gain'
                                        */
  real_T Constant_Value_g;             /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Bremsabstand_Value;           /* Expression: 400
                                        * Referenced by: '<S5>/Bremsabstand'
                                        */
  real_T KonstantefrdieAbstandssensoren_[9];/* Expression: [6:14]
                                             * Referenced by: '<S15>/Konstante f�r die Abstandssensoren'
                                             */
  real_T Gain_Gain_c;                  /* Expression: 0
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/Constant4'
                                        */
  real_T constant1_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/constant1'
                                        */
  real_T KonstantefrdenLichtschranke_Val;/* Expression: 1
                                          * Referenced by: '<S15>/Konstante f�r den Lichtschranke'
                                          */
  real_T KonstantefrdenSchieber_Value; /* Expression: 2
                                        * Referenced by: '<S15>/Konstante f�r den Schieber'
                                        */
  real_T KonstantefrdenLngsgeschwindigke;/* Expression: 3
                                          * Referenced by: '<S15>/Konstante f�r den L�ngsgeschwindigkeit'
                                          */
  real_T KonstantefrdenQuergeschwindigke;/* Expression: 4
                                          * Referenced by: '<S15>/Konstante f�r den Quergeschwindigkeit1'
                                          */
  real_T KonstantefrdenRotationegeschwin;/* Expression: 5
                                          * Referenced by: '<S15>/Konstante f�r den Rotationegeschwindigkeit'
                                          */
  real_T KonstantefrKollision_Value;   /* Expression: 15
                                        * Referenced by: '<S15>/Konstante f�r Kollision '
                                        */
  real_T KameraXYRoboter1_Value[3];    /* Expression: [1:3]
                                        * Referenced by: '<S16>/Kamera X Y Roboter 1'
                                        */
  real_T bermittelungKoordinatenKons_Val[20];/* Expression: [37:56]
                                              * Referenced by: '<S16>/�bermittelung Koordinaten Kons.'
                                              */
  real_T KameraXYRoboter2_Value[3];    /* Expression: [4:6]
                                        * Referenced by: '<S16>/Kamera X Y Roboter 2'
                                        */
  real_T KameraXYRoboter3_Value[3];    /* Expression: [7:9]
                                        * Referenced by: '<S16>/Kamera X Y Roboter 3'
                                        */
  real_T KameraXYRoboter4_Value[3];    /* Expression: [10:12]
                                        * Referenced by: '<S16>/Kamera X Y Roboter 4'
                                        */
  real_T Zeitstempel_Value;            /* Expression: 25
                                        * Referenced by: '<S16>/Zeitstempel'
                                        */
  real_T Zeitstempel1_Value;           /* Expression: 26
                                        * Referenced by: '<S16>/Zeitstempel1'
                                        */
  real_T Zeitstempel2_Value;           /* Expression: 27
                                        * Referenced by: '<S16>/Zeitstempel2'
                                        */
  real_T FahrerlaubnisKons_Value;      /* Expression: 28
                                        * Referenced by: '<S16>/Fahrerlaubnis Kons.'
                                        */
  real_T CameraVariablenKonst_Value[8];/* Expression: [29:36]
                                        * Referenced by: '<S16>/Camera Variablen Konst.'
                                        */
  real_T WegpunktlistezumTesten_Value[68];/* Expression: [4775 1800 180 300 ; 3745 1800 180 300; 2540 2100 180 300; 2160 2100 180 300; 1678 1894 180 300; 1373 1846 180 300; 1155 1627 180 300; 1106 1321 180 300; 1246 1046 180 300; 1522 906 180 300; 1827 954 180 300; 2300 954 180 300; 2800 1500 180 300; 3300 1000 180 300; 3800 1500 180 300; 4300 1000 180 300; 4800 1500 180 300 ]
                                           * Referenced by: '<S5>/Wegpunktliste zum Testen'
                                           */
  real_T FIFOwrite1_P1_Size_o[2];      /* Computed Parameter: FIFOwrite1_P1_Size_o
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P1_e;              /* Expression: size
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_Size_d[2];      /* Computed Parameter: FIFOwrite1_P2_Size_d
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_b;              /* Expression: inputtype
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_Size_i[2];      /* Computed Parameter: FIFOwrite1_P3_Size_i
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_e;              /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_Size_p[2];      /* Computed Parameter: FIFOwrite1_P4_Size_p
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_b;              /* Expression: present
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_Size_n[2];      /* Computed Parameter: FIFOwrite1_P5_Size_n
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_n[20];          /* Computed Parameter: FIFOwrite1_P5_n
                                        * Referenced by: '<S34>/FIFO write 1'
                                        */
  real_T FIFOwrite2_P1_Size_a[2];      /* Computed Parameter: FIFOwrite2_P1_Size_a
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P1_m;              /* Expression: size
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_Size_n[2];      /* Computed Parameter: FIFOwrite2_P2_Size_n
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_h;              /* Expression: inputtype
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_Size_j[2];      /* Computed Parameter: FIFOwrite2_P3_Size_j
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_l;              /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_Size_i[2];      /* Computed Parameter: FIFOwrite2_P4_Size_i
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_p;              /* Expression: present
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_Size_fb[2];     /* Computed Parameter: FIFOwrite2_P5_Size_fb
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_h[20];          /* Computed Parameter: FIFOwrite2_P5_h
                                        * Referenced by: '<S34>/FIFO write 2'
                                        */
  real_T FIFOread2_P1_Size_b[2];       /* Computed Parameter: FIFOread2_P1_Size_b
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P1_h;               /* Expression: maxsize
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_Size_b[2];       /* Computed Parameter: FIFOread2_P2_Size_b
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_a;               /* Expression: minsize
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_Size_i[2];       /* Computed Parameter: FIFOread2_P3_Size_i
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_l;               /* Expression: usedelimiter
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_Size_a[2];       /* Computed Parameter: FIFOread2_P4_Size_a
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_f;               /* Expression: delimiter
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_Size_m[2];       /* Computed Parameter: FIFOread2_P5_Size_m
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_m;               /* Expression: outputtype
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_Size_h1[2];      /* Computed Parameter: FIFOread2_P6_Size_h1
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_n;               /* Expression: sampletime
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_Size_g[2];       /* Computed Parameter: FIFOread2_P7_Size_g
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_b;               /* Expression: enable
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_Size_o[2];       /* Computed Parameter: FIFOread2_P8_Size_o
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_a;               /* Expression: enableout
                                        * Referenced by: '<S34>/FIFO read 2'
                                        */
  real_T Setup1_P1_Size[2];            /* Computed Parameter: Setup1_P1_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P1;                    /* Expression: addr
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P2_Size[2];            /* Computed Parameter: Setup1_P2_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P2;                    /* Expression: baud
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P3_Size[2];            /* Computed Parameter: Setup1_P3_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P3;                    /* Expression: width
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P4_Size[2];            /* Computed Parameter: Setup1_P4_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P4;                    /* Expression: nstop
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P5_Size[2];            /* Computed Parameter: Setup1_P5_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P5;                    /* Expression: parity
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P6_Size[2];            /* Computed Parameter: Setup1_P6_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P6;                    /* Expression: fmode
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P7_Size[2];            /* Computed Parameter: Setup1_P7_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P7;                    /* Expression: ctsmode
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P8_Size[2];            /* Computed Parameter: Setup1_P8_Size
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup1_P8;                    /* Expression: rlevel
                                        * Referenced by: '<S34>/Setup1'
                                        */
  real_T Setup2_P1_Size[2];            /* Computed Parameter: Setup2_P1_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P1;                    /* Expression: addr
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P2_Size[2];            /* Computed Parameter: Setup2_P2_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P2;                    /* Expression: baud
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P3_Size[2];            /* Computed Parameter: Setup2_P3_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P3;                    /* Expression: width
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P4_Size[2];            /* Computed Parameter: Setup2_P4_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P4;                    /* Expression: nstop
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P5_Size[2];            /* Computed Parameter: Setup2_P5_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P5;                    /* Expression: parity
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P6_Size[2];            /* Computed Parameter: Setup2_P6_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P6;                    /* Expression: fmode
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P7_Size[2];            /* Computed Parameter: Setup2_P7_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P7;                    /* Expression: ctsmode
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P8_Size[2];            /* Computed Parameter: Setup2_P8_Size
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Setup2_P8;                    /* Expression: rlevel
                                        * Referenced by: '<S34>/Setup2'
                                        */
  real_T Gain_Gain_k;                  /* Expression: 2
                                        * Referenced by: '<S7>/Gain'
                                        */
  real_T Grabbervelocity_Value;        /* Expression: 255
                                        * Referenced by: '<S7>/Grabber velocity'
                                        */
  real_T constant_Value;               /* Expression: 1
                                        * Referenced by: '<Root>/constant'
                                        */
  real_T FIFOwrite1_P1_Size_b[2];      /* Computed Parameter: FIFOwrite1_P1_Size_b
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P1_l;              /* Expression: size
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_Size_k[2];      /* Computed Parameter: FIFOwrite1_P2_Size_k
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P2_p;              /* Expression: inputtype
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_Size_g[2];      /* Computed Parameter: FIFOwrite1_P3_Size_g
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P3_f;              /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_Size_f[2];      /* Computed Parameter: FIFOwrite1_P4_Size_f
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P4_o;              /* Expression: present
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_Size_j[2];      /* Computed Parameter: FIFOwrite1_P5_Size_j
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite1_P5_g[20];          /* Computed Parameter: FIFOwrite1_P5_g
                                        * Referenced by: '<S47>/FIFO write 1'
                                        */
  real_T FIFOwrite2_P1_Size_dz[2];     /* Computed Parameter: FIFOwrite2_P1_Size_dz
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P1_f;              /* Expression: size
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_Size_c[2];      /* Computed Parameter: FIFOwrite2_P2_Size_c
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P2_f;              /* Expression: inputtype
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_Size_b[2];      /* Computed Parameter: FIFOwrite2_P3_Size_b
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P3_j;              /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_Size_c[2];      /* Computed Parameter: FIFOwrite2_P4_Size_c
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P4_e;              /* Expression: present
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_Size_o[2];      /* Computed Parameter: FIFOwrite2_P5_Size_o
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOwrite2_P5_m[20];          /* Computed Parameter: FIFOwrite2_P5_m
                                        * Referenced by: '<S47>/FIFO write 2'
                                        */
  real_T FIFOread2_P1_Size_c[2];       /* Computed Parameter: FIFOread2_P1_Size_c
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P1_hd;              /* Expression: maxsize
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_Size_a[2];       /* Computed Parameter: FIFOread2_P2_Size_a
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P2_k;               /* Expression: minsize
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_Size_o[2];       /* Computed Parameter: FIFOread2_P3_Size_o
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P3_e;               /* Expression: usedelimiter
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_Size_o[2];       /* Computed Parameter: FIFOread2_P4_Size_o
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P4_n;               /* Expression: delimiter
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_Size_h[2];       /* Computed Parameter: FIFOread2_P5_Size_h
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P5_f;               /* Expression: outputtype
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_Size_a[2];       /* Computed Parameter: FIFOread2_P6_Size_a
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P6_c;               /* Expression: sampletime
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_Size_g0[2];      /* Computed Parameter: FIFOread2_P7_Size_g0
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P7_e;               /* Expression: enable
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_Size_b[2];       /* Computed Parameter: FIFOread2_P8_Size_b
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T FIFOread2_P8_g;               /* Expression: enableout
                                        * Referenced by: '<S47>/FIFO read 2'
                                        */
  real_T Setup1_P1_Size_m[2];          /* Computed Parameter: Setup1_P1_Size_m
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P1_e;                  /* Expression: addr
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P2_Size_c[2];          /* Computed Parameter: Setup1_P2_Size_c
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P2_d;                  /* Expression: baud
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P3_Size_c[2];          /* Computed Parameter: Setup1_P3_Size_c
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P3_e;                  /* Expression: width
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P4_Size_k[2];          /* Computed Parameter: Setup1_P4_Size_k
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P4_l;                  /* Expression: nstop
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P5_Size_m[2];          /* Computed Parameter: Setup1_P5_Size_m
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P5_d;                  /* Expression: parity
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P6_Size_o[2];          /* Computed Parameter: Setup1_P6_Size_o
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P6_a;                  /* Expression: fmode
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P7_Size_c[2];          /* Computed Parameter: Setup1_P7_Size_c
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P7_h;                  /* Expression: ctsmode
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P8_Size_l[2];          /* Computed Parameter: Setup1_P8_Size_l
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup1_P8_d;                  /* Expression: rlevel
                                        * Referenced by: '<S47>/Setup1'
                                        */
  real_T Setup2_P1_Size_e[2];          /* Computed Parameter: Setup2_P1_Size_e
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P1_m;                  /* Expression: addr
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P2_Size_b[2];          /* Computed Parameter: Setup2_P2_Size_b
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P2_k;                  /* Expression: baud
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P3_Size_k[2];          /* Computed Parameter: Setup2_P3_Size_k
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P3_i;                  /* Expression: width
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P4_Size_g[2];          /* Computed Parameter: Setup2_P4_Size_g
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P4_n;                  /* Expression: nstop
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P5_Size_o[2];          /* Computed Parameter: Setup2_P5_Size_o
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P5_h;                  /* Expression: parity
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P6_Size_m[2];          /* Computed Parameter: Setup2_P6_Size_m
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P6_f;                  /* Expression: fmode
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P7_Size_c[2];          /* Computed Parameter: Setup2_P7_Size_c
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P7_a;                  /* Expression: ctsmode
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P8_Size_k[2];          /* Computed Parameter: Setup2_P8_Size_k
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T Setup2_P8_f;                  /* Expression: rlevel
                                        * Referenced by: '<S47>/Setup2'
                                        */
  real_T constant3_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/constant3'
                                        */
  real_T constant4_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/constant4'
                                        */
  real_T constant5_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/constant5'
                                        */
  uint32_T Constant_Value_f;           /* Computed Parameter: Constant_Value_f
                                        * Referenced by: '<S37>/Constant'
                                        */
  uint32_T Constant1_Value_b;          /* Computed Parameter: Constant1_Value_b
                                        * Referenced by: '<S39>/Constant1'
                                        */
  uint32_T Constant_Value_j;           /* Computed Parameter: Constant_Value_j
                                        * Referenced by: '<S38>/Constant'
                                        */
  uint32_T Constant2_Value_a;          /* Computed Parameter: Constant2_Value_a
                                        * Referenced by: '<S40>/Constant2'
                                        */
  uint32_T Constant_Value_d;           /* Computed Parameter: Constant_Value_d
                                        * Referenced by: '<S52>/Constant'
                                        */
  uint32_T Constant1_Value_m;          /* Computed Parameter: Constant1_Value_m
                                        * Referenced by: '<S54>/Constant1'
                                        */
  uint32_T Constant_Value_ba;          /* Computed Parameter: Constant_Value_ba
                                        * Referenced by: '<S53>/Constant'
                                        */
  uint32_T Constant2_Value_i;          /* Computed Parameter: Constant2_Value_i
                                        * Referenced by: '<S55>/Constant2'
                                        */
  uint32_T Memory1_X0;                 /* Computed Parameter: Memory1_X0
                                        * Referenced by: '<S26>/Memory1'
                                        */
  uint16_T Memory_X0;                  /* Computed Parameter: Memory_X0
                                        * Referenced by: '<S26>/Memory'
                                        */
  uint16_T Gain1_Gain;                 /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S26>/Gain1'
                                        */
  uint8_T RateTransitionupsamplingtofunda;/* Computed Parameter: RateTransitionupsamplingtofunda
                                           * Referenced by: '<S10>/Rate Transition up-sampling to fundamental sample time'
                                           */
  uint8_T Constant4_Value_g;           /* Computed Parameter: Constant4_Value_g
                                        * Referenced by: '<S5>/Constant4'
                                        */
  uint8_T PreviousFlag_X0;             /* Computed Parameter: PreviousFlag_X0
                                        * Referenced by: '<S24>/Previous Flag'
                                        */
  uint8_T PreviousSOC_X0;              /* Computed Parameter: PreviousSOC_X0
                                        * Referenced by: '<S24>/Previous SOC'
                                        */
  uint8_T Constant2_Value_p;           /* Computed Parameter: Constant2_Value_p
                                        * Referenced by: '<Root>/Constant2'
                                        */
  uint8_T Constant3_Value_j;           /* Computed Parameter: Constant3_Value_j
                                        * Referenced by: '<Root>/Constant3'
                                        */
  boolean_T Constant7_Value;           /* Computed Parameter: Constant7_Value
                                        * Referenced by: '<S5>/Constant7'
                                        */
  boolean_T Constant5_Value;           /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S5>/Constant5'
                                        */
  boolean_T Constant_Value_m;          /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<S5>/Constant'
                                        */
  boolean_T Constant2_Value_b;         /* Computed Parameter: Constant2_Value_b
                                        * Referenced by: '<S5>/Constant2'
                                        */
  boolean_T Constant1_Value_n;         /* Computed Parameter: Constant1_Value_n
                                        * Referenced by: '<Root>/Constant1'
                                        */
  boolean_T constant2_Value;           /* Computed Parameter: constant2_Value
                                        * Referenced by: '<Root>/constant2'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_KitGewerk2_v14_T {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWLogInfo *rtwLogInfo;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[5];
    SimStruct childSFunctions[31];
    SimStruct *childSFunctionPtrs[31];
    struct _ssBlkInfo2 blkInfo2[31];
    struct _ssSFcnModelMethods2 methods2[31];
    struct _ssSFcnModelMethods3 methods3[31];
    struct _ssStatesInfo2 statesInfo2[31];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn3;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn4;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn5;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn6;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn7;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn8;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn9;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn10;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn11;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn12;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn13;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn14;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn15;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn16;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn17;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn18;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn19;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn20;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn21;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn22;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn23;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn24;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn25;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn26;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[2];
      uint_T attribs[5];
      mxArray *params[5];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn27;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssPortOutputs outputPortInfo[1];
      uint_T attribs[8];
      mxArray *params[8];
    } Sfcn28;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn29;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn30;
  } NonInlinedSFcns;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;

  /*
   * ModelData:
   * The following substructure contains information regarding
   * the data used in the model.
   */
  struct {
    void *blockIO;
    const void *constBlockIO;
    void *defaultParam;
    ZCSigState *prevZCSigState;
    real_T *contStates;
    real_T *derivs;
    void *zcSignalValues;
    void *inputs;
    void *outputs;
    boolean_T *contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T blkStateChange;
    void *dwork;
  } ModelData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    uint32_T clockTick3;
    uint32_T clockTickH3;
    time_T stepSize3;
    uint8_T rtmDbBufReadBuf3;
    uint8_T rtmDbBufWriteBuf3;
    boolean_T rtmDbBufLastBufWr3;
    uint32_T rtmDbBufClockTick3[2];
    uint32_T rtmDbBufClockTickH3[2];
    uint32_T clockTick4;
    uint32_T clockTickH4;
    time_T stepSize4;
    uint8_T rtmDbBufReadBuf4;
    uint8_T rtmDbBufWriteBuf4;
    boolean_T rtmDbBufLastBufWr4;
    uint32_T rtmDbBufClockTick4[2];
    uint32_T rtmDbBufClockTickH4[2];
    struct {
      uint8_T TID[3];
    } TaskCounters;

    struct {
      boolean_T TID1_2;
    } RateInteraction;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[3];
    time_T offsetTimesArray[3];
    int_T sampleTimeTaskIDArray[3];
    int_T sampleHitArray[3];
    int_T perTaskSampleHitsArray[9];
    time_T tArray[5];
  } Timing;
};

/* Block parameters (auto storage) */
extern P_KitGewerk2_v14_T KitGewerk2_v14_P;

/* Block signals (auto storage) */
extern B_KitGewerk2_v14_T KitGewerk2_v14_B;

/* Block states (auto storage) */
extern DW_KitGewerk2_v14_T KitGewerk2_v14_DW;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_KitGewerk2_v14_T KitGewerk2_v14_Y;

/* External function called from main */
extern time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
  ;

/* External data declarations for dependent source files */
extern const uint8_T KitGewerk2_v14_U8GND;/* uint8_T ground */
extern const uint16_T KitGewerk2_v14_U16GND;/* uint16_T ground */

/* Zero-crossing (trigger) state */
extern PrevZCX_KitGewerk2_v14_T KitGewerk2_v14_PrevZCX;

/* Model entry point functions */
extern void KitGewerk2_v14_initialize(void);
extern void KitGewerk2_v14_output(int_T tid);
extern void KitGewerk2_v14_update(int_T tid);
extern void KitGewerk2_v14_terminate(void);

/* Real-time Model object */
extern RT_MODEL_KitGewerk2_v14_T *const KitGewerk2_v14_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'KitGewerk2_v14'
 * '<S1>'   : 'KitGewerk2_v14/Begrenzung'
 * '<S2>'   : 'KitGewerk2_v14/Begrenzung1'
 * '<S3>'   : 'KitGewerk2_v14/Begrenzung2'
 * '<S4>'   : 'KitGewerk2_v14/Communication Block'
 * '<S5>'   : 'KitGewerk2_v14/Gewerk_2'
 * '<S6>'   : 'KitGewerk2_v14/Power Management Gewerk 4'
 * '<S7>'   : 'KitGewerk2_v14/Robotino'
 * '<S8>'   : 'KitGewerk2_v14/UDP interface'
 * '<S9>'   : 'KitGewerk2_v14/getRobotinoID'
 * '<S10>'  : 'KitGewerk2_v14/Communication Block/Robotino UDP transceiver'
 * '<S11>'  : 'KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 1'
 * '<S12>'  : 'KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 2'
 * '<S13>'  : 'KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 3'
 * '<S14>'  : 'KitGewerk2_v14/Communication Block/Robotino UDP transceiver/If Robotino 4'
 * '<S15>'  : 'KitGewerk2_v14/Gewerk_2/Ausg�nge Robotino'
 * '<S16>'  : 'KitGewerk2_v14/Gewerk_2/Ausg�nge UDP Interface1'
 * '<S17>'  : 'KitGewerk2_v14/Gewerk_2/Chart'
 * '<S18>'  : 'KitGewerk2_v14/Gewerk_2/Kollisionserkennung'
 * '<S19>'  : 'KitGewerk2_v14/Gewerk_2/MATLAB Function'
 * '<S20>'  : 'KitGewerk2_v14/Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn'
 * '<S21>'  : 'KitGewerk2_v14/Gewerk_2/Chart/Fahrt_zum_Warteplatz.simfcn/Subsystem'
 * '<S22>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Output_Flag-Comparison: Blei oder Li-ION'
 * '<S23>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging'
 * '<S24>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0'
 * '<S25>'  : 'KitGewerk2_v14/Power Management Gewerk 4/SOC-Comparison: Blei oder Li-ION'
 * '<S26>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging'
 * '<S27>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Compare To Zero'
 * '<S28>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Compare To Zero1'
 * '<S29>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Flag Communication Simulation'
 * '<S30>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/MATLAB Function'
 * '<S31>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/MATLAB Function1'
 * '<S32>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Relais ansteuern1'
 * '<S33>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 1 and 2: Simulation of Charging and Discharging/Simulation of Charging and Discharging/Unterscheidung Blei Gel Roboter an der virtuellen Ladestation'
 * '<S34>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2'
 * '<S35>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Microcontroller Data'
 * '<S36>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR'
 * '<S37>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 1'
 * '<S38>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Receive 2'
 * '<S39>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 1'
 * '<S40>'  : 'KitGewerk2_v14/Power Management Gewerk 4/Robotiono 3 and 4: Communication with Feature Pack 4.0/Baseboard Serial COM2/RS232 ISR/Transmit 2'
 * '<S41>'  : 'KitGewerk2_v14/Robotino/assemble robotino response'
 * '<S42>'  : 'KitGewerk2_v14/Robotino/distance converter'
 * '<S43>'  : 'KitGewerk2_v14/Robotino/light barrier & slider'
 * '<S44>'  : 'KitGewerk2_v14/Robotino/receive direction, unit & velocity converter'
 * '<S45>'  : 'KitGewerk2_v14/Robotino/serial communication'
 * '<S46>'  : 'KitGewerk2_v14/Robotino/transmit velocity, unit & direction converter'
 * '<S47>'  : 'KitGewerk2_v14/Robotino/serial communication/Baseboard Serial'
 * '<S48>'  : 'KitGewerk2_v14/Robotino/serial communication/error filter & protocol disassembler'
 * '<S49>'  : 'KitGewerk2_v14/Robotino/serial communication/protocol adder & optional velocity adaption'
 * '<S50>'  : 'KitGewerk2_v14/Robotino/serial communication/stop by bumper'
 * '<S51>'  : 'KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR'
 * '<S52>'  : 'KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 1'
 * '<S53>'  : 'KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Receive 2'
 * '<S54>'  : 'KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 1'
 * '<S55>'  : 'KitGewerk2_v14/Robotino/serial communication/Baseboard Serial/RS232 ISR/Transmit 2'
 * '<S56>'  : 'KitGewerk2_v14/UDP interface/stop signals'
 * '<S57>'  : 'KitGewerk2_v14/getRobotinoID/getIDfromFlash'
 */
#endif                                 /* RTW_HEADER_KitGewerk2_v14_h_ */
