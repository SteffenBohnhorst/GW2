/*
 * KitGewerk2_v14_private.h
 *
 * Code generation for model "KitGewerk2_v14".
 *
 * Model version              : 1.897
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Thu Sep 22 15:27:25 2016
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_KitGewerk2_v14_private_h_
#define RTW_HEADER_KitGewerk2_v14_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error "Code was generated for compiler with different sized uchar/char. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compiler's limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, which will disable the preprocessor word size checks."
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error "Code was generated for compiler with different sized ushort/short. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error "Code was generated for compiler with different sized uint/int. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif

#if ( ULONG_MAX != (0xFFFFFFFFU) ) || ( LONG_MAX != (0x7FFFFFFF) )
#error "Code was generated for compiler with different sized ulong/long. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif

/* Define interrupt functions for board 1 */
xpcPCIDevice xpcDev_1;

/* Done with interrupt functions for board 1 */

/* Define interrupt functions for board 2 */
xpcPCIDevice xpcDev_2;

/* Done with interrupt functions for board 2 */
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#endif                                 /* __RTWTYPES_H__ */

extern const serialfifoptr serialfifoground;
extern const bcmsglist1553 bcmsg1553ground;
extern const bcstatus1553 bcstatground;
extern const bmmsglist1553 bmmsg1553ground;
extern uint32_T MWDSP_EPH_R_B(boolean_T evt, uint32_T *sta);
extern void xpcudpbytereceive(SimStruct *rts);
extern void xpcudpbytesend(SimStruct *rts);
extern void bahnplaner_v22(SimStruct *rts);
extern void fifowrite(SimStruct *rts);
extern void fiforead(SimStruct *rts);
extern void xpcfromfile(SimStruct *rts);
extern void sersetupbase(SimStruct *rts);
extern void KitGewerk2_v14_RS232ISR_Start(void);
extern void KitGewerk2_v14_RS232ISR(void);
extern void KitGewerk2_v14_RS232ISR_f_Start(void);
extern void KitGewerk2_v14_RS232ISR_i(void);
extern void KitGewerk2_v14_RS232ISR_Term(void);
extern void KitGewerk2_v14_RS232ISR_k_Term(void);
void KitGewerk2_v14_output0(void);
void KitGewerk2_v14_update0(void);
void KitGewerk2_v14_output2(void);
void KitGewerk2_v14_update2(void);

#endif                                 /* RTW_HEADER_KitGewerk2_v14_private_h_ */
